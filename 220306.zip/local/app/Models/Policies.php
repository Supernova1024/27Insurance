<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Policies extends Model
{
    use HasFactory;

    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'policies';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = ['quot_id', 'cve', 'pol', 'owner', 'issuer', 'serie', 'motor', 'plates', 'reference', 'ASEGID', 'ASEGDIRID', 'PROPID', 'PROPDIRID', 'BENEFID', 'BENEFDIRID', 'status', 'cancel_date'];

    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = [];
}
