<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Quotations extends Model
{
    use HasFactory;

    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'quotations';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = ['cot_id', 'user_id', 'ver_id', 'cotinc_id', 'verinc_id', 'colonia', 'municipality', 'cveveh', 'marca', 'model', 'description', 'fp', 'paq', 'condition', 'DER', 'REC', 'DES', 'BON', 'iva', 'pneta', 'ptotal', 'company', 'start_date', 'end_date'];

    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = [];
}
