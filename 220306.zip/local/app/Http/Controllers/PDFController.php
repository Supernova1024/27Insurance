<?php
  
namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Quotations;
use App\Models\Policies;
use Illuminate\Http\Request;
use PDF;
use SoapClient;
  
class PDFController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function quotationPDF(Request $request)
    {
		$ids = $this->getId($request->id);
		if($ids[0] != 0){
			$ABA = Quotations::join('users', 'users.id', 'quotations.user_id')
				->where('quotations.id', $ids[0])
				->select('users.*', 'quotations.*')
				->first();
			if(isset($ids[1])){
				if($ids[1] != 0){
					$Qual = Quotations::join('users', 'users.id', 'quotations.user_id')
						->where('quotations.cot_id', $ids[1])
						->select('users.*', 'quotations.*')
						->first();
					$Qual_company = $Qual->company;
					$Qual_ptotal = $Qual->ptotal;
				} else{
					$Qual_company = 'Null';
					$Qual_ptotal = 'Null';
				}
			} else{
				$Qual_company = 'Null';
				$Qual_ptotal = 'Null';
			}
			$data = [
				'cot_id'=> $ABA->cot_id,
				'firstname'=> $ABA->firstname,
				'lastname'=> $ABA->lastname,
				'paternal'=> $ABA->paternal_surname,
				'maternal'=> $ABA->maternal_surname,
				'phone'=> $ABA->phone,
				'email'=> $ABA->email,
				'marca'=> $ABA->marca,
				'model'=> $ABA->model,
				'description'=> $ABA->description,
				'fp'=> $ABA->fp,
				'paq'=> $ABA->paq,
				'start_date' => $ABA->start_date,
				'ABA_company'=> $ABA->company,
				'ABA_ptotal'=> $ABA->ptotal,
				'Qual_company' => $Qual_company,
				'Qual_ptotal'=> $Qual_ptotal,
			];

			$pdf = PDF::loadView('PDF.quotation', $data);
			return $pdf->stream('Cotización # '. $ABA->cot_id .'.pdf');
		} else if($ids[0] == 0 && $ids[1] != 0){
			$Qual = Quotations::join('users', 'users.id', 'quotations.user_id')
				->where('quotations.cot_id', $ids[1])
				->select('users.*', 'quotations.*')
				->first();
			$data = [
				'cot_id'=> $Qual->cot_id,
				'firstname'=> $Qual->firstname,
				'lastname'=> $Qual->lastname,
				'paternal'=> $Qual->paternal_surname,
				'maternal'=> $Qual->maternal_surname,
				'phone'=> $Qual->phone,
				'email'=> $Qual->email,
				'marca'=> $Qual->marca,
				'model'=> $Qual->model,
				'description'=> $Qual->description,
				'fp'=> $Qual->fp,
				'paq'=> $Qual->paq,
				'start_date' => $Qual->start_date,
				'ABA_company'=> 'Null',
				'ABA_ptotal'=> 'Null',
				'Qual_company' => $Qual->company,
				'Qual_ptotal'=> $Qual->ptotal,
			];
			$pdf = PDF::loadView('PDF.quotation', $data);
			return $pdf->stream('Cotización # '. $Qual->cot_id .'.pdf');
		}
    }
	
	public function getId($value){
		$result = explode("-", $value);
		return $result;
	}
	
	public function policyPDF(Request $request)
    {
        $policy = Policies::join('quotations', 'quotations.id', 'policies.quot_id')
			->join('users', 'users.id', 'quotations.user_id')
			->where('policies.id', $request->id)
			->select('users.*', 'quotations.*', 'policies.*')->first();
		$data = [
			'company' => $policy->company,
			'cve'=> $policy->cve,
			'pol'=> $policy->pol,
			'start_date' => $policy->start_date,
			'end_date' => $policy->end_date,
			'paq' => $policy->paq,
			'insured' => $policy->firstname.' '.$policy->lastname.' '.$policy->paternal_surname.' '.$policy->maternal_surname,
			'cp' => $policy->postal_code,
			'telephone' => $policy->telephone,
			'rfc' => $policy->rfc,
			'fp' => $policy->fp,
			'description' => $policy->description,
			'marca' => $policy->marca,
			'model' => $policy->model,
			'serie' => $policy->serie,
			'motor' => $policy->motor,
			'plates' => $policy->plates,
			'pneta' => $policy->pneta,
			'DER' => $policy->DER,
			'iva' => $policy->iva,
			'ptotal' => $policy->ptotal,
		];
		$title = $policy->cve.''.$policy->pol;
		$pdf = PDF::loadView('PDF.policy', $data);
		return $pdf->stream($title .'.pdf');
    }
	
	public function test(){
		$data = ['name'=>'Andrey'];
		$pdf = PDF::loadView('PDF.test_policy', $data);
		return $pdf->stream('test.pdf');
	}
}