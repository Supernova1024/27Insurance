<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Quotations;
use App\Models\Policies;
use App\Models\Notifications;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use SoapClient;
use SoapHeader;
use Mail;

class PolicyController extends Controller
{
	public function __construct()
	{
		$this->middleware(['auth' => 'verified']);
	}

	public function policyList(Request $request)
	{

		$breadcrumbs = [
			['link' => "/", 'name' => "Bussiness"], ['link' => "javascript:void(0)", 'name' => "Policy"], ['name' => "List"],
		];
		//Pageheader set true for breadcrumbs
		$pageConfigs = ['pageHeader' => true, 'isFabButton' => false, 'bodyCustomClass' => 'menu-collapse'];

		$data = array();
		$data['user'] = $request->user();
		$data['key'] = 'policy-list';
		$data['year'] = $request->year;
		$old_policy = Quotations::orderBy('start_date', 'asc')->first();
		if(isset($old_policy))
			$data['old'] = $this->getYear($old_policy->start_date);
		else
			$data['old'] = date('Y');
			
		$data['years'] = array();
		$x = date('Y') - $data['old'];
		$year = date('Y');
		for ($i = 0; $i <= $x; $i++) {
			array_push($data['years'], $year);
			$year = $year - 1;
		}
		$query = Policies::join('quotations', 'policies.quot_id', 'quotations.id')
			->join('users', 'quotations.user_id', 'users.id')
			->where('quotations.start_date', 'like', '%'. $data['year'] .'%');
		
		if($data['user']->role != 'client'){
			$data['policies'] = $query->select('quotations.*', 'users.*', 'policies.*')->get();
		} else{
			$data['policies'] = $query->where('quotations.user_id', $data['user']->id)
				->select('quotations.*', 'users.*', 'policies.*')->get(); 
		}

		return view('pages.policy-list', ['pageConfigs' => $pageConfigs], ['breadcrumbs' => $breadcrumbs])->with('data', $data);
	}
	public function policyEdit(Request $request)
	{
		$breadcrumbs = [
            ['link' => "/", 'name' => "Bussiness"], ['link' => "javascript:void(0)", 'name' => "Policy"], ['name' => "Edit"]];
        //Pageheader set true for breadcrumbs
        $pageConfigs = ['pageHeader' => true, 'isFabButton' => false];
		
		$data = array();
		$data['user'] = $request->user();
		$data['policy'] = Policies::join('quotations', 'policies.quot_id', 'quotations.id')
			->join('users', 'quotations.user_id', 'users.id')
			->where('policies.id', $request->id)->select('quotations.*', 'users.*', 'policies.*')->first();
        return view('pages.policy-edit', ['pageConfigs' => $pageConfigs], ['breadcrumbs' => $breadcrumbs])->with('data', $data);
	}
	
	public function policyUpdate(Request $request)
	{
		$policy = Policies::join('quotations', 'quotations.id', 'policies.quot_id')
			->where('policies.id', $request->id)->select('quotations.*', 'policies.*')->first();
		
		if($policy->status == 1 && $request->status == 0){
			$users = User::where('role', '!=', 'client')->orwhere('id', $policy->user_id)->get();
			foreach($users as $user){
				$notification = new Notifications();
				$notification->message = $policy->id;
				$notification->recipient_id = $user->id;
				$notification->status = "sent";
				$notification->kind = "canceled";
				$notification->taget = "Policy";
				$notification->save();
			}
			$to = User::where('id', $policy->user_id)->first();
			$toMail = $to->email;
			$mail_data = array('name' => $to->firstname, 'policy_id' => $policy->id, 'date' => date("Y-m-d"),);
			Mail::send('mail.cancel_mail', $mail_data, function($message) use ($toMail, $policy) {
				$message->from('contacto@segurosacv.com', 'Seguros ACV');
				$message->to($toMail)->subject('Su póliza'. $policy->cve.''.$policy->pol.'ha sido cancelada');
			  });
		}
		$policy_id = $policy->cve .''. $policy->pol;
		$policy->serie = $request->serie;
		$policy->motor = $request->motor;
		$policy->plates = $request->plates;
		$policy->reference = $request->ref;
		$policy->serie = $request->serie;
		$policy->status = $request->status;
		if($policy->status == 0){
			$policy->cancel_date = $request->cancel_date;
		}
		$policy->save();
		$quot = Quotations::where('id', $policy->quot_id)->first();
		$quot->colonia = $request->colonia;
		$quot->municipality = $request->muni;
		$quot->marca = $request->brand;
		$quot->model = $request->model;
		$quot->description = $request->des;
		$quot->fp = $request->fp;
		$quot->paq = $request->paq;
		$quot->DER = $request->DER;
		$quot->REC = $request->REC;
		$quot->DES = $request->DES;
		$quot->BON = $request->BON;
		$quot->iva = $request->iva;
		$quot->pneta = $request->pneta;
		$quot->ptotal = $request->ptotal;
		$quot->company = $request->company;
		$quot->start_date = $request->start_date;
		if($policy->status == 1){
			$quot->end_date = $request->end_date;
		}
		$quot->save();
		
		$client = User::where('id', $quot->user_id)->first();
		$client->postal_code = $request->cp;
		$client->save();
		
		return redirect()->back()->with(session()->flash('success', 'Update'));
	}
	public function policyNew(Request $request)
	{
		$breadcrumbs = [
			['link' => "/", 'name' => "Bussiness"], ['link' => "javascript:void(0)", 'name' => "Policy"], ['name' => "Issuing"],
		];
		//Pageheader set true for breadcrumbs
		$pageConfigs = ['pageHeader' => true, 'isFabButton' => false];

		$data = array();
		$data['user'] = $request->user();
		$data['quot'] = Quotations::where('id', $request->id)->first();
		$data['client'] = User::where('id', $data['quot']->user_id)->first();

		return view('pages.policy-new', ['breadcrumbs' => $breadcrumbs], ['pageConfigs' => $pageConfigs])->with('data', $data);
	}
	public function policyIssuing(Request $request)
	{
		$user = $request->user();
		$birthday = $this->getDate($request->birthday);
		$quote = Quotations::where('id', $request->quot_id)->first();
		$client = User::where('id', $quote->user_id)->first();
		$camis = $quote->cveveh;
		if($camis != 0)
			$verify = $this->getVerify($camis);
		$sex = 0;
		if($request->sex == 'male'){
			$sex = 1;
		}
		$fp = $quote->fp;
		$paq = $quote->paq;
		$current_date = date('Y-m-d'); 
		$end_date = date("Y-m-d",strtotime("+1 year"));
		if($quote->company == "ABA" && $user->role != "client"){
			$xml = '<XML><DP><TP>0</TP><FISICA><RFC>' . $request->rfc . '</RFC><HCVE></HCVE><PNOM>'. $request->firstname .'</PNOM>
				   <SNOM>'. $request->lastname .'</SNOM><APP>'. $request->paternal .'</APP><APM>'. $request->maternal .'</APM>
				   <SEXO>'. $sex .'</SEXO><EDOCIVIL>'. $request->marital .'</EDOCIVIL></FISICA><DOMICILIO><TIPODIR>1</TIPODIR>
				   <CALLE>'. $request->address .'</CALLE><NUMEXT>'. $request->ext_num .'</NUMEXT><NUMINT></NUMINT><COL>PARQUES DE LA CA-ADA</COL>
				   <CP>'. $request->cp .'</CP><POB>SALTILLO</POB></DOMICILIO><TELEFONO><LADA>'. substr($request->telephone, 0, 2) .'</LADA>
				   <NUMERO>'. substr($request->telephone, -8) .'</NUMERO></TELEFONO><CELULAR><LADA>'. substr($request->phone, 0, 2) .'</LADA>
				   <NUMERO>'. substr($request->phone, -8) .'</NUMERO></CELULAR><CORREO>'. $request->email .'</CORREO></DP></XML>';
			$insured_json = $this->getInsuredData($xml, "register_insured");
			if ($insured_json['status'] == 'failed') {
				return json_encode(array('status'=>'failed', 'type'=>'register insured', 'message'=>$insured_json['data']));
			}
			$tranid      = $insured_json['data']['TRANSACCION']['TRANID'];
			$tpid        = '';
			if (array_key_exists('PID', $insured_json['data']['PERSONA'])) {
				$tpid        = $insured_json['data']['PERSONA']['PID'];
			} else {
				$tpid        = $insured_json['data']['PERSONA']['TPID'];
			}
			$tdirid          = '';
			if (array_key_exists('TDIRID', $insured_json['data']['DIRECCION'])) {
				$tdirid        = $insured_json['data']['DIRECCION']['TDIRID'];
			} else {
				$tdirid        = $insured_json['data']['DIRECCION']['DIRID'];
			}

			$xml = '<EMI><COTID>' . $quote->cot_id . '</COTID><VERID>' . $quote->ver_id . '</VERID><INCISOS><INCISO>
					<COTINCID>' . $quote->cotinc_id . '</COTINCID><VERINCID>' . $quote->verinc_id . '</VERINCID>
					<DE><ASEGID>' . $tpid . '</ASEGID><ASEGDIRID>' . $tdirid . '</ASEGDIRID><ASEGTRANID>' . $tranid . '</ASEGTRANID>
					</DE><SERIE>' . $request->serie . '</SERIE><REF>' . $request->ref . '</REF><MOTOR>' . $request->motor . '</MOTOR>
					<PLACAS>' . $request->plates . '</PLACAS></INCISO></INCISOS></EMI>';
			$issue_json = $this->getIssuing($xml);
			if ($issue_json['status'] == 'failed') {
				//return json_encode(array('status'=>'failed', 'type'=>'issuing a policy', 'message'=>$issue_json['data']));
				return redirect()->back()->with(session()->flash('error', $issue_json['data']));
			} else{
				$policy = new Policies();
				$policy->quot_id = $request->quot_id;
				$policy->cve = $issue_json['data']['POL']['CVE'];
				$policy->pol = $issue_json['data']['POL']['POL'];
				$policy->owner = $client->id; 
				$policy->issuer = $user->id;
				$policy->serie = $request->serie;
				$policy->motor = $request->motor;
				$policy->plates = $request->plates;
				$policy->reference = $request->ref;
				$policy->ASEGID    = $issue_json['data']['POL']['ASEGID'];
				$policy->ASEGDIRID = $issue_json['data']['POL']['ASEGDIRID'];
				$policy->PROPID    = $issue_json['data']['POL']['PROPID'];
				$policy->PROPDIRID = $issue_json['data']['POL']['PROPDIRID'];
				$policy->BENEFID   = $issue_json['data']['POL']['BENEFID'];
				$policy->BENEFDIRID= $issue_json['data']['POL']['BENEFDIRID'];
				$policy->save();
				$new_policy = Policies::where('quot_id', $request->quot_id)->first();
				$quote = Quotations::where('id', $request->quot_id)->first();
				$quote->condition = '1';
				$quote->save();
				$users = User::where('role', '!=', 'client')->orwhere('id', $client->id)->get();
				foreach($users as $_user){
					$notification = new Notifications();
					$notification->message = $new_policy->id;
					$notification->recipient_id = $_user->id;
					$notification->status = "sent";
					$notification->kind = "new";
					$notification->taget = "Policy";
					$notification->save();
				}
				return redirect()->back()->with(session()->flash('success', 'Issuing Success.'));
			}
		} else if($quote->company == "QUA" && $user->role != "client"){
			if($paq == 3)
				$PAQ = 4;
			elseif($paq == 2)
				$PAQ = 3;
			elseif($paq == 1)
				$PAQ = 2;
			else
				$PAQ = 1;
			if($fp == 12)
				$FP = 'C';
			elseif($fp == 27)
				$FP = 'M';
			elseif($fp == 28)
				$FP = 'S';
			else
				$FP = 'T';
			$XML = '<?xml version="1.0" encoding="utf-8"?><Movimientos><Movimiento TipoMovimiento="3" NoPoliza="" NoCotizacion="'. $quote->cot_id .'" NoEndoso="" TipoEndoso="" NoOTra="" NoNegocio="06850"><DatosAsegurado NoAsegurado=""><Nombre>'. $request->paternal .' '. $request->maternal .' '. $request->firstname .' '. $request->lastname .'</Nombre><Direccion>'. $request->address .'</Direccion><Colonia>'. $request->colonia .'</Colonia><Poblacion>'. $request->municipality .'</Poblacion><Estado>14</Estado><CodigoPostal>'. $request->cp .'</CodigoPostal><NoEmpleado/><Agrupador/><ConsideracionesAdicionalesDA NoConsideracion="40"><TipoRegla>4</TipoRegla><ValorRegla>'. $request->firstname .' '. $request->lastname .'</ValorRegla></ConsideracionesAdicionalesDA><ConsideracionesAdicionalesDA NoConsideracion="40"><TipoRegla>5</TipoRegla><ValorRegla>'. $request->paternal .'</ValorRegla></ConsideracionesAdicionalesDA><ConsideracionesAdicionalesDA NoConsideracion="40"><TipoRegla>6</TipoRegla><ValorRegla>'. $request->maternal .'</ValorRegla></ConsideracionesAdicionalesDA><ConsideracionesAdicionalesDA NoConsideracion="40"><TipoRegla>7</TipoRegla><ValorRegla>'. $request->municipality .'</ValorRegla></ConsideracionesAdicionalesDA><ConsideracionesAdicionalesDA NoConsideracion="40"><TipoRegla>8</TipoRegla><ValorRegla>'. $request->colonia .'</ValorRegla></ConsideracionesAdicionalesDA><ConsideracionesAdicionalesDA NoConsideracion="40"><TipoRegla>11</TipoRegla><ValorRegla>'. $request->cp .'</ValorRegla></ConsideracionesAdicionalesDA><ConsideracionesAdicionalesDA NoConsideracion="40"><TipoRegla>19</TipoRegla><ValorRegla>'. $request->person .'</ValorRegla></ConsideracionesAdicionalesDA><ConsideracionesAdicionalesDA NoConsideracion="40"><TipoRegla>20</TipoRegla><ValorRegla>'. $birthday .'</ValorRegla></ConsideracionesAdicionalesDA><ConsideracionesAdicionalesDA NoConsideracion="40"><TipoRegla>21</TipoRegla><ValorRegla>'. $request->nationality .'</ValorRegla></ConsideracionesAdicionalesDA><ConsideracionesAdicionalesDA NoConsideracion="40"><TipoRegla>23</TipoRegla><ValorRegla>'. $request->occupation .'</ValorRegla></ConsideracionesAdicionalesDA><ConsideracionesAdicionalesDA NoConsideracion="40"><TipoRegla>24</TipoRegla><ValorRegla>'. $request->business .'</ValorRegla></ConsideracionesAdicionalesDA><ConsideracionesAdicionalesDA NoConsideracion="40"><TipoRegla>25</TipoRegla><ValorRegla>'. $request->profession .'</ValorRegla></ConsideracionesAdicionalesDA><ConsideracionesAdicionalesDA NoConsideracion="40"><TipoRegla>70</TipoRegla><ValorRegla>'. $request->telephone .'</ValorRegla></ConsideracionesAdicionalesDA><ConsideracionesAdicionalesDA NoConsideracion="40"><TipoRegla>64</TipoRegla><ValorRegla>001</ValorRegla></ConsideracionesAdicionalesDA></DatosAsegurado><DatosVehiculo NoInciso="1"><ClaveAmis>'. $camis .'</ClaveAmis><Modelo>'. $quote->model .'</Modelo><DescripcionVehiculo/><Uso>01</Uso><Servicio>01</Servicio><Paquete>'. $PAQ .'</Paquete><Motor>'. $request->motor .'</Motor><Serie>'. $request->serie .'</Serie><Coberturas NoCobertura="01"><SumaAsegurada>0</SumaAsegurada><TipoSuma>0</TipoSuma><Deducible>5</Deducible><Prima>0</Prima></Coberturas><Coberturas NoCobertura="03"><SumaAsegurada>0</SumaAsegurada><TipoSuma>0</TipoSuma><Deducible>10</Deducible><Prima>0</Prima></Coberturas><Coberturas NoCobertura="04"><SumaAsegurada>3000000</SumaAsegurada><TipoSuma>0</TipoSuma><Deducible>0</Deducible><Prima>0</Prima></Coberturas><Coberturas NoCobertura="05"><SumaAsegurada>500000</SumaAsegurada><TipoSuma>0</TipoSuma><Deducible>0</Deducible><Prima>0</Prima></Coberturas><Coberturas NoCobertura="06"><SumaAsegurada>100000</SumaAsegurada><TipoSuma>0</TipoSuma><Deducible>0</Deducible><Prima>0</Prima></Coberturas><Coberturas NoCobertura="07"><SumaAsegurada>0</SumaAsegurada><TipoSuma>0</TipoSuma><Deducible>0</Deducible><Prima>0</Prima></Coberturas><Coberturas NoCobertura="14"><SumaAsegurada>0</SumaAsegurada><TipoSuma>0</TipoSuma><Deducible>0</Deducible><Prima>0</Prima></Coberturas></DatosVehiculo><DatosGenerales><FechaEmision>2021-04-30</FechaEmision><FechaInicio>'. $current_date .'</FechaInicio><FechaTermino>'. $end_date .'</FechaTermino><Moneda>00</Moneda><Agente>14697</Agente><FormaPago>'. $FP .'</FormaPago><TarifaValores>LINEA</TarifaValores><TarifaCuotas>LINEA</TarifaCuotas><TarifaDerechos>LINEA</TarifaDerechos><Plazo/><Agencia/><Contrato/><PorcentajeDescuento>35</PorcentajeDescuento><ConsideracionesAdicionalesDG NoConsideracion="01"><TipoRegla>1</TipoRegla><ValorRegla>'. $verify .'</ValorRegla></ConsideracionesAdicionalesDG><ConsideracionesAdicionalesDG NoConsideracion="4"><TipoRegla>1</TipoRegla><ValorRegla>0</ValorRegla>
</ConsideracionesAdicionalesDG><ConsideracionesAdicionalesDG NoConsideracion="05"><TipoRegla>0</TipoRegla><ValorRegla>14</ValorRegla></ConsideracionesAdicionalesDG></DatosGenerales><Primas><PrimaNeta/><Derecho>520</Derecho><Recargo/><Impuesto/>
<PrimaTotal/><Comision/></Primas><CodigoError/></Movimiento></Movimientos>';
			try {
				   $client = new SoapClient('http://sio.qualitas.com.mx/WsEmision/WsEmision.asmx?WSDL');
				   try {
					   $params = array('xmlEmision'=>$XML);
					   $result = $client->obtenerNuevaEmision($params);
					   $xml_result = $result->obtenerNuevaEmisionResult;
				   } catch (Exception $e){
					   $xml_result=$e->getMessage();
				   }
			   } catch (Exception $e){
				   $xml_result=preg_replace('/\'/','', $e->getMessage());
			   }
			$xml_qual = simplexml_load_string($xml_result);
			$qualitas = json_decode(json_encode($xml_qual), TRUE);
			if(isset($qualitas)){
				if(json_encode($qualitas['Movimiento']['Primas']['PrimaTotal']) != '[]'){
					$policy = new Policies();
					$policy->quot_id = $request->quot_id;
					//$policy->cve = ;
					$policy->pol = $qualitas['Movimiento']['@attributes']['NoPoliza'];
					$policy->owner = $client->id; 
					$policy->issuer = $user->id;
					$policy->serie = $request->serie;
					$policy->motor = $request->motor;
					$policy->save();
					$quote = Quotations::where('id', $request->quot_id)->first();
					$quote->condition = '1';
					$quote->save();
					$users = User::where('role', '!=', 'client')->orwhere('id', $client->id)->get();
					foreach($users as $_user){
						$notification = new Notifications();
						$notification->message = $new_policy->id;
						$notification->recipient_id = $_user->id;
						$notification->status = "sent";
						$notification->kind = "new";
						$notification->taget = "Policy";
						$notification->save();
					}
				}
			} 
			return $qualitas;
			//return redirect()->back()->with(session()->flash('error', 'Qualitas quotation is updating...'));
		} else{
			// custome class and customizer remove
			$pageConfigs = ['bodyCustomClass' => 'bg-full-screen-image', 'isCustomizer' => false];
			return view('pages.page-404', ['pageConfigs' => $pageConfigs]);
		}
	}
	
	public function getInsuredData(String $xml, String $case) 
	{
        $headers = array();
        $TokenHeader = array(
          'usuario'=> "WSEMPJALISCO",
          'password'=> "AU77O$21"
        );
        $headers[] = new SOAPHeader('http://tempuri.org/', 'Token', $TokenHeader);

        $headers[] =   new SOAPHeader('http://tempuri.org/', 'strEntrada', $xml);
        $providerConsultas = "http://www5.abaseguros.com/PersonaConnect/PCRegistro.svc?wsdl";
        $_clientConsultas = new SoapClient($providerConsultas, array('trace' => true, 'exceptions' => true));
        $_clientConsultas->__setSoapHeaders($headers);

        try {     // Abrimos un try..catch para obtener los mensajes de error
            if( $case == "register_insured"){
                $result = $_clientConsultas->ConsultaRegistraPersona(array('strEntrada' => ""));
            } elseif($case == "register_insured_address"){
                $result = $_clientConsultas->RegistraDireccionPersona(array('strEntrada' => "")); // $xml 
            } else {
                echo "No case";
                die();
            }
            // Results are obtained 
            $data = $result->strSalida;
            $xml_file = simplexml_load_string($data);
            $json = json_encode($xml_file);
            $array_Data = json_decode($json, TRUE);

            return array("status" => "success", "data" => $array_Data);

        } catch (SoapFault $fault) {
            return array("status" => "failed", "data" => $fault->getMessage());
        } catch (SoapFaultException $e) {
            return array("status" => "failed", "data" => $e->getMessage());
        } catch (Exception $e) { // En caso de producirse un error
            return array("status" => "failed", "data" => $e->getMessage());
        } catch(\Throwable $e){
            return array("status" => "failed", "data" => $e->getMessage());
        }
    }

    public function getIssuing(String $xml)
	{
        $TokenHeader = array(
          'usuario'=> "WSEMPJALISCO",
          'password'=> "AU77O$21",
        );
        $providerEmision = 'http://www5.abaseguros.com/AutoConnect/ACEmision.svc?wsdl';
        try {
            $_clientEmision = new SoapClient($providerEmision, array('trace' => true, 'exceptions' => true));
            $header = new SoapHeader('http://tempuri.org/', 'Token', $TokenHeader);

            // Headers are added to the WS object
            $_clientEmision->__setSoapHeaders($header);

            $result = $_clientEmision->EmitePoliza(array('strEntrada' => $xml)); // $xml variable con el XML requerido
            // Results are obtained 
            $data = $result->strSalida;

            $xml_file = simplexml_load_string($data);
            $json = json_encode($xml_file );
            $array_Data = json_decode($json,TRUE);

            return array("status" => "success", "data" => $array_Data);

        } catch (SoapFault $fault) {
            // return array("status" => "failed", "data" => $fault->getMessage());
            Log::error($fault);
            error_clear_last(); // The solution.
        } catch (SoapFaultException $e) {
            return array("status" => "failed", "data" => $e->getMessage());
        } catch (Exception $e) { // En caso de producirse un error
            return array("status" => "failed", "data" => $e->getMessage());
        } catch(\Throwable $e){
            return array("status" => "failed", "data" => $e->getMessage());
        }
    }
	
	public function getYear($date){
		$data = explode("-", $date);
		return $data[0];
	}
	
	public function getVerify($value){
		$val = ((substr($value, 0, 1)+substr($value, 2, 1)+substr($value, 4, 1))*3 + (substr($value, 1, 1)+substr($value, 3, 1))) % 10;
		$result = (10 - $val);
		if($result == 10)
			$result = 0;
		return $result;
	}
	
	public function getDate($value){
		$val = explode("-", $value);
		$result = $val[2] .'/'. $val[1] .'/'. $val[0];
		return $result;
	}
	
}
