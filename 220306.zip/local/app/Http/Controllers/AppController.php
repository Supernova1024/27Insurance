<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Mail;

use Webklex\IMAP\Facades\Client;
/** @var \Webklex\IMAP\Client $oClient */

class AppController extends Controller
{

	public function __construct()
    {
        $this->middleware(['auth' => 'verified']);
    }

    public function get_date_day($date)
    {
    	
    	$date = date_create($date);
    	$date_format = date_format($date, 'D \, F d \, g:i A');
    	$receive_date = date_format($date, 'Y-m-d');
    	$now = time();
    	$diff = $now - strtotime((string)$receive_date);
    	$days = round($diff / (60 * 60 * 24));

		$year1 = date('Y', strtotime((string)$receive_date));
		$year2 = date('Y', $now);

		$month1 = date('m', strtotime((string)$receive_date));
		$month2 = date('m', $now);

		$months = (($year2 - $year1) * 12) + ($month2 - $month1);
		$years = $year2 - $year1;
    	$date_day =  $date_format . '(' . $days . ' days ago)';
    	if ($years != 0) {
    		$date_day =  $date_format . '(' . $years . ' years ago)';
    	} else {
    		if ($months != 0) {
    			$date_day =  $date_format . '(' . $months . ' months ago)';
    		} else {
    			if($days != 0) {
    				$date_day =  $date_format . '(' . $days . ' days ago)';
    			} else {
    				$date_day =  $date_format;
    			}
    			
    		}
    	}
		return $date_day;
    }

    public function get_date_2month_ago()
    {
    	
    	$months_ago_date = date('d.m.Y', strtotime('-2 months'));
		return $months_ago_date;
    }
	
	public function sendEmail(Request $request){
		
		$data = array(
			'sms' => $request->content,
			'date' => date("Y-m-d")
		);
		if( !isset($request->subject)){
			Mail::send('mail.send_email', $data, function($message) use ($request) {
				$message->from($request->from, 'Seguros ACV');
				$message->to($request->to)->subject('Reply Message');
			  });
		} else{
			Mail::send('mail.send_email', $data, function($message) use ($request) {
				$message->from($request->from, 'Seguros ACV');
				$message->to($request->to)->subject($request->subject);
				if ($request->hasFile('attach')){
					$file = $request->file('attach');
					$filename = $file->getClientOriginalName();
					$file->move("attached",$filename);
					$filePath = "https://dreamy-montalcini.74-208-200-19.plesk.page/attached/".$filename;
					$message->attach($filePath);
				}
			});
		}
		return redirect()->back()->with(session()->flash('success', 'sent_mail'));
		
	}
	
    public function emailApp(Request $request)
    {
        // custom body class
        $pageConfigs = ['bodyCustomClass' => 'app-page'];

        ## Get emails of users
        $user = User::select('email')->get();

		$data = array();
		$data['user'] = $request->user();
		$data['all_message_data'] = array();
		$mesag_data = array();
		//Connect to the IMAP Server
		$oClient = Client::account('default');
		$oClient->connect();
		$folder = $oClient->getFolder('INBOX');

		$aMessage = $folder->query()->all()->setFetchFlags(false)->setFetchBody(false)->limit(40, 1)->get();
		// $aMessage = $folder->query()->all()->setFetchFlags(false)->setFetchBody(false)->get();
		// $aMessage = $folder->query()->all()->setFetchFlags(false)->limit(30, 1)->get();
		foreach($aMessage as $oMessage){
			$mesag_data['from'] = $oMessage->getFrom()[0]->mail;
			$oMessage->setFlag('Seen');
			foreach($user as $email){
				if ($mesag_data['from'] == (string)$email->email) {
					$user_data = User::select('firstname', 'lastname', 'image')->where('email', $mesag_data['from'])->first();
					$mesag_data['header'] = $oMessage->getHeader();
					$mesag_data['id'] =  $oMessage->getUid();
					$mesag_data['subject'] = (string)$oMessage->getSubject();
					$mesag_data['user_name'] = $user_data->firstname . ' ' . $user_data->lastname;
					$mesag_data['user_img'] = $user_data->image;
					$mesag_data['folder'] = 'inbox';
					$mesag_data['received_date'] = date_format(date_create((string)$oMessage->getDate()), 'g:i A');
					array_push($data['all_message_data'], $mesag_data);
					// echo $oMessage->getHTMLBody(true);
				}
			}
		}
		// die();
		## Get the count of new unseen messages
		$data['all_message_data'] = array_reverse($data['all_message_data']);

		$data['folder'] = 'inbox';

		return view('pages.app-email', ['pageConfigs' => $pageConfigs])->with('data', $data);
    }

    public function emailApp_post(Request $request)
    {
        // custom body class
        $pageConfigs = ['bodyCustomClass' => 'app-page'];

        ## Get emails of users
        $user = User::select('email')->get();

		$data = array();
		$data['user'] = $request->user();
		$data['all_message_data'] = array();
		$mesag_data = array();
		//Connect to the IMAP Server
		$oClient = Client::account('default');
		$oClient->connect();
		$folder_name = $request->folder;
		switch ($folder_name) {
			case 'inbox':
				$folder = $oClient->getFolder('INBOX');
				break;

			case 'sent':
				// $folder = $oClient->getFolder('Enviados');
				$folder = $oClient->getFolder('Elementos enviados');
				break;

			case 'draft':
				$folder = $oClient->getFolder('Borradores');
				break;

			case 'spam':
				$folder = $oClient->getFolder('Spam');
				break;

			case 'trash':
				$folder = $oClient->getFolder('Papelera');
				break;
		}
		if ($folder_name == 'trash') {
			$aMessage = $folder->query()->whereSince($this->get_date_2month_ago())->get();
		} else {
			$aMessage = $folder->query()->all()->setFetchFlags(false)->setFetchBody(false)->limit(40, 1)->get();
		}
		
		// $aMessage = $folder->query()->all()->setFetchFlags(false)->setFetchBody(false)->get();
		if ($folder_name == 'inbox' or  $folder_name == 'trash' or $folder_name == 'spam') {
			foreach($aMessage as $oMessage){
				$mesag_data['from'] = $oMessage->getFrom()[0]->mail;
				$oMessage->setFlag('Seen');
				foreach($user as $email){
					if ($mesag_data['from'] == (string)$email->email) {
						$user_data = User::select('firstname', 'lastname', 'image')->where('email', $mesag_data['from'])->first();
						$mesag_data['header'] = $oMessage->getHeader();
						$mesag_data['id'] =  $oMessage->getUid();
						$mesag_data['subject'] = (string)$oMessage->getSubject();
						$mesag_data['user_name'] = $user_data->firstname . ' ' . $user_data->lastname;
						$mesag_data['user_img'] = $user_data->image;
						$mesag_data['folder'] = $folder_name;
						$mesag_data['received_date'] = date_format(date_create((string)$oMessage->getDate()), 'g:i A');

						array_push($data['all_message_data'], $mesag_data);
					}
				}
			}
		} else {
			foreach($aMessage as $oMessage){
				if ($oMessage->getTo()) {
					$mesag_data['to'] = $oMessage->getTo()[0]->mail;
					$oMessage->setFlag('Seen');
					foreach($user as $email){
						if ($mesag_data['to'] == (string)$email->email) {
							$user_data = User::select('firstname', 'lastname', 'image')->where('email', $mesag_data['to'])->first();
							$mesag_data['header'] = $oMessage->getHeader();
							$mesag_data['id'] =  $oMessage->getUid();
							$mesag_data['subject'] = (string)$oMessage->getSubject();
							$mesag_data['user_name'] = $user_data->firstname . ' ' . $user_data->lastname;
							$mesag_data['user_img'] = $user_data->image;
							$mesag_data['folder'] = $folder_name;
							$mesag_data['received_date'] = date_format(date_create((string)$oMessage->getDate()), 'g:i A');

							array_push($data['all_message_data'], $mesag_data);
						}
					}
				}
			}
		}

		$data['all_message_data'] = array_reverse($data['all_message_data']);
		$data['folder_name'] = $folder_name;
		// $data1 = ['pp', $folder_name, $data['all_message_data'][0]['subject']];
		return $data; 
    }

    public function delMail_post(Request $request)
    {
        // custom body class
        $pageConfigs = ['bodyCustomClass' => 'app-page'];
		
		$data = array();
		$data['user'] = $request->user();
		$del_mesag_ids = $request->del_mesag_ids;

		$oClient = Client::account('default');
		$oClient->connect();
		
		foreach ($del_mesag_ids as $id_folder) {
			$mesag_id = explode('&', $id_folder)[0];
			$folder_name_low = explode('&', $id_folder)[1];
			switch ($folder_name_low) {
				case 'inbox':
					$folder_name = 'INBOX';
					break;

				case 'sent':
					// $folder_name = 'Enviados';
					$folder_name = 'Elementos enviados';
					break;

				case 'draft':
					$folder_name = 'Borradores';
					break;

				case 'spam':
					$folder_name = 'Spam';
					break;

				case 'trash':
					$folder_name = 'Papelera';
					break;
			}
			
			if ($folder_name == 'Papelera') {
				$folder = $oClient->getFolder('Papelera');
				$oMessage = $folder->query()->getMessageByUid($mesag_id)->delete();
			} else {
				$folder = $oClient->getFolder($folder_name);
				$oMessage = $folder->query()->getMessageByUid($mesag_id)->move('Papelera');
			}
			
		}

        // return view('pages.app-email-content', ['pageConfigs' => $pageConfigs])->with('data', $data);
        $data['status'] = 'delete';
        // $data1 = ['delMail_post', $mesag_id, $folder_name];
        return $data; 
    }
	
    public function emailContentApp(Request $request)
    {
        // custom body class
        $pageConfigs = ['bodyCustomClass' => 'app-page'];
		
		$data = array();
		$data['user'] = $request->user();
		$e_uid = $request->mesag_id;
		$folder_name = $request->folder;

		$oClient = Client::account('default');
		$oClient->connect();
		switch ($folder_name) {
			case 'inbox':
				$folder = $oClient->getFolder('INBOX');
				break;

			case 'sent':
				// $folder = $oClient->getFolder('Enviados');
				$folder = $oClient->getFolder('Elementos enviados');
				break;

			case 'draft':
				$folder = $oClient->getFolder('Borradores');
				break;

			case 'spam':
				$folder = $oClient->getFolder('Spam');
				break;

			case 'trash':
				$folder = $oClient->getFolder('Papelera');
				break;
		}

		$oMessage = $folder->query()->getMessageByUid($e_uid);

		$mesag_data = array();
		$mesag_data['header'] = $oMessage->getHeader();
		$mesag_data['subject'] = (string)$oMessage->getSubject();
		$mesag_data['attachments'] = $oMessage->getAttachments();
		$mesag_data['attach_count'] = $oMessage->getAttachments()->count();
		// $mesag_data['body'] = $oMessage->getHTMLBody(true);
		$mesag_data['body'] = $oMessage->mask()->getHTMLBodyWithEmbeddedBase64Images();
		
		// $mesag_data['received_date'] = explode(";", explode("Received: from", $mesag_data['header']->raw)[1])[1];
		$mesag_data['received_date'] = $this->get_date_day((string)$oMessage->getDate());
		
		if ($folder_name == 'inbox' or  $folder_name == 'trash' or $folder_name == 'spam') {
			$mesag_data['from'] = $oMessage->getFrom()[0]->mail;
			$user_data = User::select('firstname', 'lastname', 'image')->where('email', $mesag_data['from'])->first();
			$mesag_data['who'] = $mesag_data['from'];
			$mesag_data['user_name'] = "From: " . $user_data->firstname . ' ' . $user_data->lastname;
		} else {
			$mesag_data['to'] = $oMessage->getTo()[0]->mail;
			$user_data = User::select('firstname', 'lastname', 'image')->where('email', $mesag_data['to'])->first();
			$mesag_data['who'] = $mesag_data['to'];
			$mesag_data['user_name'] = "To: " . $user_data->firstname . ' ' . $user_data->lastname;
		}
		
		$mesag_data['user_img'] = $user_data->image;

		$data['mesag_data'] = $mesag_data;
		$data['folder'] = $folder_name;
		
		// var_dump($mesag_data['body']);
		// die();
		
        return view('pages.app-email-content', ['pageConfigs' => $pageConfigs])->with('data', $data);
        // return $data; 
    }
	
}
