<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Quotations;
use App\Models\Policies;
use Illuminate\Http\Request;

class ReportController extends Controller
{
	
	public function __construct()
	{
		$this->middleware(['auth' => 'verified']);
	}
	
    public function report(Request $request)
    {
		$data = array();
		$user = $request->user();
		$breadcrumbs = [
			['link' => "/", 'name' => "Bussiness"], ['link' => "javascript:void(0)", 'name' => "Report"]];
		//Pageheader set true for breadcrumbs
		$pageConfigs = ['pageHeader' => true, 'isFabButton' => false];
		
		if($user->role != 'client'){
			$data['key'] = 'report';
			$data['year'] = $request->year;
			$data['years'] = array();
			$old_quot = Quotations::orderBy('start_date', 'asc')->first();
			$old_year = explode("-", $old_quot->start_date);
			$x = date('Y') - $old_year[0];
			$year = date('Y');
			for ($i = 0; $i <= $x; $i++) {
				array_push($data['years'], $year);
				$year = $year - 1;
			}

			return view('/pages/report', ['breadcrumbs' => $breadcrumbs], ['pageConfigs' => $pageConfigs])->with('data', $data);
		} else{
			return view('/client/report', ['breadcrumbs' => $breadcrumbs], ['pageConfigs' => $pageConfigs])->with('data', $data);
		}
		
    }
	
	public function getChart(Request $request)
	{
		$data = array();
		$year = $request->year;
		$last_year = $year - 1;
		$this_year = Quotations::where('start_date', 'like', '%'. $year .'%')
			->orderBy('start_date', 'desc')->first();
		$last_month = explode("-", $this_year);
		$months = array('01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12');
		$data['quot_val'] = array();	
		$data['quot_last'] = array();
		$data['val'] = array();	
		$data['last'] = array();
		$data['this_ptotal'] = array();
		$data['last_ptotal'] = array();
		$data['last_flag'] = Quotations::where('condition', '1')->where('start_date', 'like', '%'. $last_year .'%')->count();
		$i = 0;
		$flag = 0;
		foreach ($months as $month) {
			$this_premium = 0;
			$last_premium = 0;
			$i = $i + 1;
			if($flag == 0){
				$val = Quotations::where('condition', '1')->where('start_date', 'like', '%'. $year .'-'. $month .'%')->count();
				array_push($data['val'], $val);
				$last = Quotations::where('condition', '1')->where('start_date', 'like', '%'. $last_year .'-'. $month .'%')->count();
				array_push($data['last'], $last);
				$quot_val = Quotations::where('condition', '0')->where('start_date', 'like', '%'. $year .'-'. $month .'%')->count();
				array_push($data['quot_val'], $quot_val);
				$quot_last = Quotations::where('condition', '0')->where('start_date', 'like', '%'. $last_year .'-'. $month .'%')->count();
				array_push($data['quot_last'], $quot_last);
				$this_ptotals = Quotations::where('condition', '1')->where('start_date', 'like', '%'. $year .'-'. $month .'%')->get();
				foreach($this_ptotals as $ptotal){
					$this_premium = $this_premium + $ptotal->ptotal;
				}
				array_push($data['this_ptotal'], $this_premium);
				$last_ptotals = Quotations::where('condition', '1')->where('start_date', 'like', '%'. $last_year .'-'. $month .'%')->get();
				foreach($last_ptotals as $ptotal){
					$last_premium = $last_premium + $ptotal->ptotal;
				}
				array_push($data['last_ptotal'], $last_premium);
			}
			if($month == $last_month[1]){
				$data['count'] = $i;
				$flag = 1;
			}
		}
		// get min val
		$this_min = min($data['val']);
		$last_min = min($data['last']);
		$data['min'] = min($this_min, $last_min);
		
		// get max val
		$this_min = max($data['val']);
		$last_min = max($data['last']);
		$data['max'] = max($this_min, $last_min);
		
		$companys = array('ABA', 'QUA', 'AXA', 'ANA', 'BAN', 'HDI', 'MAP');
		$data['this_company'] = array();
		foreach($companys as $company){
			$count = $this->countCompany($company, $year);
			array_push($data['this_company'], $count);
		}
		
		$data['last_company'] = array();
		foreach($companys as $company){
			$count = $this->countCompany($company, $last_year);
			array_push($data['last_company'], $count);
		}
		
		return $data;
	}
	
	public function countCompany($company, $year){
		$count = Quotations::where('condition', '1')
			->where('company', $company)
			->where('start_date', 'like', '%'. $year .'%')->count();
		return $count;
	}
}
