<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Quotations;
use App\Models\Notifications;
use Illuminate\Http\Request;
use SoapClient;
use SoapHeader;
use Mail;

class QuotController extends Controller
{
	public function __construct()
	{
		$this->middleware(['auth' => 'verified']);
	}

	public function quotList(Request $request)
	{
		$data = array();
		$data['user'] = $request->user();
		$data['key'] = 'quot-list';
		$data['year'] = $request->year;
		$data['years'] = array();
		$old_quot = Quotations::orderBy('start_date', 'asc')->first();
		$old_year = explode("-", $old_quot->start_date);
		$x = date('Y') - $old_year[0];
		$year = date('Y');
		for ($i = 0; $i <= $x; $i++) {
			array_push($data['years'], $year);
			$year = $year - 1;
		}
		$query = Quotations::join('users', 'quotations.user_id', 'users.id')
			->where('quotations.start_date', 'like', '%'. $data['year'] .'%')
			->where('quotations.condition', '0');
		
		if($data['user']->role != 'client'){
			$data['quotes'] = $query->orderBy('quotations.created_at', 'desc')->select('users.*', 'quotations.*')->get();
		} else{
			$data['quotes'] = $query->where('users.id', $data['user']->id)->orderBy('quotations.created_at', 'desc')
				->select('users.*', 'quotations.*')->get();
		}
		
		$breadcrumbs = [
			['link' => "/", 'name' => "Bussiness"], ['link' => "javascript:void(0)", 'name' => "Quotation"], ['name' => "List"],
		];
		//Pageheader set true for breadcrumbs
		$pageConfigs = ['pageHeader' => true, 'isFabButton' => false, 'bodyCustomClass' => 'menu-collapse'];

		return view('pages.quot-list', ['pageConfigs' => $pageConfigs], ['breadcrumbs' => $breadcrumbs])->with('data', $data);
	}
	
	public function quotEdit(Request $request)
	{
		$breadcrumbs = [
            ['link' => "/", 'name' => "Bussiness"], ['link' => "javascript:void(0)", 'name' => "Quotation"], ['name' => "Edit"]];
        //Pageheader set true for breadcrumbs
        $pageConfigs = ['pageHeader' => true, 'isFabButton' => false];
		
		$data = array();
		$data['user'] = $request->user();
		$data['quotes'] = Quotations::join('users', 'quotations.user_id', 'users.id')
			->where('quotations.id', $request->id)->select('users.*', 'quotations.*')->first();
		
        return view('pages.quot-edit', ['pageConfigs' => $pageConfigs], ['breadcrumbs' => $breadcrumbs])->with('data', $data);
	}
	
	public function quotUpdate(Request $request)
	{
		$quot = Quotations::where('id', $request->id)->first();
		$quot->fp = $request->fp;
		$quot->DES = $request->DES;
		$quot->BON = $request->BON;
		$quot->DER = $request->DER;
		$DES = $quot->ptotal/100*$request->DES;
		$BON = $quot->ptotal/100*$request->BON;
		$BON = $quot->pneat/100*$request->BON;
		$quot->ptotal = $quot->pneta + $quot->DER + $quot->iva - $DES - $BON;
		$quot->save();
		return redirect()->back()->with(session()->flash('success', 'Update'));
	}

	public function newQuot(Request $request)
	{
		$breadcrumbs = [
			['link' => "/", 'name' => "Bussiness"], ['link' => "javascript:void(0)", 'name' => "Quotation"], ['name' => "New"],
		];
		//Pageheader set true for breadcrumbs
		$pageConfigs = ['pageHeader' => true, 'isFabButton' => false];
		$data = array();
		$data['user'] = $request->user();
		$xml = '<CAT><NEG>7190</NEG></CAT>';
		$brands = $this->get_Data($xml, "get_brands");
		$data['brands'] = $brands["MARCAS"]["MARCA"];
		return view('pages.quot-new', ['breadcrumbs' => $breadcrumbs], ['pageConfigs' => $pageConfigs])->with('data', $data);
	}

	public function getSubBrands(Request $request) 
	{
		$id = $request->id;
		$xml = '<CAT><NEG>7190</NEG><ID>'. $id .'</ID></CAT>';
		$subBrands = $this->get_Data($xml, "get_sub_brands");
		$data = $subBrands['SUBMARCAS']['SUBMARCA'];
		return $data;
	}

	public function getModels(Request $request) 
	{

		$mod = $request->date;
		$marca = $request->marca_id;
		$submarca = $request->submarca_id;
		$xml = '<CAT><NEG>7190</NEG><MOD>'. $mod .'</MOD><TAR>201</TAR><MARCA>'. $marca .'</MARCA>
                  <SUBMARCA>'. $submarca .'</SUBMARCA></CAT>';
		$models = $this->get_Data($xml, "get_vehicle_type");
		$data = $models['TIPOS']['TIPO'];
		return $data;
	}

	public function getDescription(Request $request) {

		$mod = $request->date;
		$tipoveh = $request->tipoveh;
		$tipo = $request->tipo;
		$marca = $request->marca;

		$xml = '<CAT><NEG>7190</NEG><MOD>'. $mod .'</MOD><TAR>201</TAR><TIPOVEH>'. $tipoveh .'</TIPOVEH></CAT>';
		$data = $this->get_Data($xml, "get_vehicle_description");
		$qualitas = $this->get_qualitas($marca, $mod, $tipo);

		return array_merge($data['DESCRIPCIONES'], $qualitas['datos']);
	}
	
	public function getPerson(Request $request) {

		$rfc = $request->rfc;
		$xml = '<XML><DP><TP>1</TP><RFC>DIOJ771220</RFC></DP></XML>';
		$data = $this->get_Persons($xml, "consult_person");

		return $data;
	}
	
	public function get_Persons(String $xml, String $case)
	{
		$headers = array();
        $TokenHeader = array(
          'usuario'=> 'WSEMPJALISCO',
          'password'=> 'AU77O$21'
        );
        $headers[] = new SOAPHeader('http://tempuri.org/', 'Token', $TokenHeader);

        $headers[] = new SOAPHeader('http://tempuri.org/', 'strEntrada', $xml);
        $providerConsultas = 'http://www5.abaseguros.com/PersonaConnect/PCRegistro.svc?wsdl';
        $_clientConsultas = new SoapClient($providerConsultas, array('trace' => true, 'exceptions' => true));
        $_clientConsultas->__setSoapHeaders($headers);

        try {     // Abrimos un try..catch para obtener los mensajes de error
            if( $case == "consult_person"){
                $result = $_clientConsultas->ConsultaPersonas(array('strEntrada' => ""));
			} elseif( $case == "consult_person_address"){
                $result = $_clientConsultas->ConsultaDireccionesPersona(array('strEntrada' => ""));
            } elseif( $case == "register_insured"){
                $result = $_clientConsultas->ConsultaRegistraPersona(array('strEntrada' => ""));
            } elseif($case == "register_insured_address"){
                $result = $_clientConsultas->RegistraDireccionPersona(array('strEntrada' => "")); // $xml 
            } else {
                echo "No case";
                die();
            }
          
            // Results are obtained 
            $data = $result->strSalida;
            $xml_file = simplexml_load_string($data);
            $json = json_encode($xml_file);
            $array_Data = json_decode($json, TRUE);

            return array("status" => "success", "data" => $array_Data);

        } catch (SoapFault $fault) {
            return array("status" => "failed", "data" => $fault->getMessage());
        } catch (SoapFaultException $e) {
            return array("status" => "failed", "data" => $e->getMessage());
        } catch (Exception $e) { // En caso de producirse un error
            return array("status" => "failed", "data" => $e->getMessage());
        } catch(\Throwable $e){
            return array("status" => "failed", "data" => $e->getMessage());
        }
	} 
	
	
	public function get_Data(String $xml, String $case)
	{
		$TokenHeader = array(
			'usuario'=> 'WSEMPJALISCO',
			'password'=> 'AU77O$21',
		);
		$providerCatalogo = 'http://www5.abaseguros.com/AutoConnect/ACCatalogos.svc?wsdl';
		try {

			$_clientCatalogo = new SoapClient($providerCatalogo, array('trace' => true));

			$header = new SoapHeader('http://tempuri.org/', 'Token', $TokenHeader);

			// Headers are added to the WS object
			$_clientCatalogo->__setSoapHeaders($header);

			if( $case == "get_business"){
				$result = $_clientCatalogo->ObtenerNegocios(array('strEntrada' => $xml));
			} elseif($case == "get_brands"){
				$result = $_clientCatalogo->ObtenerMarcas(array('strEntrada' => $xml));
			} elseif($case == "get_catalogs"){
				$result = $_clientCatalogo->ObtenerCatalogos(array('strEntrada' => $xml));
			} elseif($case == "get_conduits"){
				$result = $_clientCatalogo->ObtenerConductos(array('strEntrada' => $xml));
			} elseif($case == "get_sub_brands"){
				$result = $_clientCatalogo->ObtenerSubmarcas(array('strEntrada' => $xml));
			} elseif($case == "get_municipalityByCP"){
				$result = $_clientCatalogo->ObtenerMunicipioPorCP(array('strEntrada' => $xml));
			} elseif($case == "get_type_sum_insured"){
				$result = $_clientCatalogo->ObtenerTipoSumaAsegurada(array('strEntrada' => $xml));
			} elseif($case == "get_vehicle_description"){
				$result = $_clientCatalogo->ObtenerDescripcionVehiculos(array('strEntrada' => $xml));
			} elseif($case == "get_vehicle_type"){
				$result = $_clientCatalogo->ObtenerTipoVehiculos(array('strEntrada' => $xml));
			} else{
				echo "No case";
				die();
			}
			// Results are obtained 
			$data = $result->strSalida;
			$xml_file = simplexml_load_string($data);
			$array_Data = json_decode(json_encode($xml_file),TRUE);
			return $array_Data;
		} catch (SoapFault $fault) {
			// catches soap faults
		} catch (Exception $e) {
			echo 'Caught exception: ',  $e->getMessage(), "\n";
		}
	}
	public function get_qualitas($marca, $mod, $tipo){
		// Prepare SoapHeader parameters
		$sh_param = array(
			'cUsuario'   =>    'LINEA',
			'cTarifa'    =>    'LINEA',
			'cMarca'    =>    $marca,
			'cModelo'    =>    $mod,
			'cTipo'    =>    $tipo);
		$result = $this->qualitas($sh_param);
		return $result;
	}

	public function qualitas($sh_param)
	{
		$soapClient = new SoapClient('http://qbcenter.qualitas.com.mx/wsTarifa/wsTarifa.asmx?wsdl');   //Se agregaron comillas

		$headers = new SoapHeader('http://soapserver.example.com/webservices', 'UserCredentials', $sh_param);

		// Prepare Soap Client
		$soapClient->__setSoapHeaders(array($headers));

		// Setup the RemoteFunction parameters
		$ap_param = array();

		// Call RemoteFunction ()
		$error = 0;
		try {
			$info = $soapClient->__call("listaTarifas", array($sh_param));  //Se cambia la variable que estamos llenando no la que está vacía.
		} catch (SoapFault $fault) {
			$error = 1;
			print("alert('Sorry, blah returned the following ERROR: ".$fault->faultcode."-".$fault->faultstring.". We will now take you back to our home page.');
				window.location = 'main.php';
				");
		}

		if ($error == 0) {
			$xml_file = simplexml_load_string($info->listaTarifasResult->any);
			$array_Data = json_decode(json_encode($xml_file ),TRUE);
			return $array_Data;
		}
	}
	
	public function getQuot(Request $request) 
	{
		$resultData = array();
		$user = $request->user();
		$id = $user->id;
		$marca = $request->brand;
        $fp = $request->fp;
        $paq = $request->paq;
        $cveveh = $request->Cveveh;
        $mod = $request->mod;
		$_year = date("Y") - 1;
		if($mod < $_year)
			$condition = 1;
		else
			$condition = 0;
        $description = $request->description;
        $cp = $request->postal_code;
        $current_date = date('Y-m-d'); 
		$DES = $request->DES;
        $end_date = date("Y-m-d",strtotime("+1 year"));
		$camis = $request->camis;
		if($camis != 0)
			$verify = $this->getVerify($camis);
		$qual = $request->qual;
		if($paq == 3)
			$PAQ = 4;
		elseif($paq == 2)
			$PAQ = 3;
		elseif($paq == 1)
			$PAQ = 2;
		else
			$PAQ = 1;
		if($fp == 12)
			$FP = 'C';
		elseif($fp == 27)
			$FP = 'M';
		elseif($fp == 28)
			$FP = 'S';
		else
			$FP = 'T';
		
        $xml1 = '<CAT><NEG>7190</NEG><CP>'. $cp .'</CP></CAT>';
        $view_data1 = $this->get_Data($xml1, "get_municipalityByCP");
        $edo = $view_data1['EDO'];
        $mun = $view_data1['MPO'];
		$municipality = $view_data1['MPODSC'];

		if($cveveh != 0){
			$xml2 = '<COT> <DG><NEG>7190</NEG><AGE>141909</AGE><CON>1</CON><TAR>201</TAR><INIVIG>'. $current_date .'</INIVIG>
					 <FINVIG>'. $end_date .'</FINVIG><TS>2</TS><AGRUPA>71797</AGRUPA><TC>1</TC><FP>'. $fp .'</FP></DG>
					 <INCISOS><INCISO><CVEVEH>'. $cveveh .'</CVEVEH><DESC>'. $description .'</DESC><MOD>'. $mod .'</MOD>
					 <CONDICION>'. $condition .'</CONDICION><PAQ>'. $paq .'</PAQ><EDO>'. $edo .'</EDO><MUN>'. $mun .'</MUN><SERV>1</SERV>
					 <USO>1</USO><TDED>1</TDED><TSA>1</TSA><PD>0</PD><PB>0</PB></INCISO></INCISOS></COT>';
			$data = $this->get_Policy($xml2, "quote_policy");
			$resultData['aba'] = $data;
			if(isset($data)){
				$quotation = new Quotations();
				$quotation->cot_id = $data['COTID'];
				$quotation->user_id = $id;
				$quotation->ver_id = $data['VERID'];
				$quotation->cotinc_id = $data['INCISOS']['INCISO']['COTINCID'];
				$quotation->verinc_id = $data['INCISOS']['INCISO']['VERINCID'];
				$quotation->municipality = $municipality;
				$quotation->cveveh = $cveveh;
				$quotation->DER = $data['INCISOS']['INCISO']['DER'];
				$quotation->REC = $data['INCISOS']['INCISO']['REC'];
				$quotation->DES = $data['INCISOS']['INCISO']['DES'];
				//$quotation->DES = $DES;
				$quotation->BON = $data['INCISOS']['INCISO']['BON'];
				$quotation->iva = $data['IVA'];
				$quotation->pneta = $data['PNETA'];
				if(count($data['INCISOS']['INCISO']['RECIBOS']['RECIBO']) != 11)
					$quotation->ptotal = $data['INCISOS']['INCISO']['RECIBOS']['RECIBO']['0']['PTOTAL'];
				else
					$quotation->ptotal = $data['INCISOS']['INCISO']['RECIBOS']['RECIBO']['PTOTAL'];
				$quotation->model = $mod;
				$quotation->marca = $marca;
				$quotation->condition = '0';
				$quotation->fp = $fp;
				$quotation->paq = $paq;
				$quotation->description = $description;
				$quotation->company = "ABA";
				$quotation->start_date = $current_date;
				$quotation->end_date = $end_date;
				$quotation->save();
			}
		}
		
		if($camis != 0){
			$XML = '<?xml version="1.0" encoding="utf-8"?><Movimientos><Movimiento TipoMovimiento="2" NoPoliza="" NoCotizacion="" NoEndoso="" TipoEndoso="" NoOTra="" NoNegocio="06850"><DatosAsegurado NoAsegurado=""><Nombre/><Direccion/><Colonia/><Poblacion/><Estado>14</Estado><CodigoPostal>'. $cp .'</CodigoPostal><NoEmpleado/><Agrupador/></DatosAsegurado><DatosVehiculo NoInciso="1"><ClaveAmis>'. $camis .'</ClaveAmis><Modelo>'. $mod .'</Modelo><DescripcionVehiculo/><Uso>01</Uso><Servicio>01</Servicio><Paquete>'. $PAQ .'</Paquete><Motor/><Serie/><Coberturas NoCobertura="01"><SumaAsegurada>0</SumaAsegurada><TipoSuma>0</TipoSuma><Deducible>5</Deducible><Prima>0</Prima></Coberturas><Coberturas NoCobertura="03"><SumaAsegurada>0</SumaAsegurada><TipoSuma>0</TipoSuma><Deducible>10</Deducible><Prima>0</Prima></Coberturas><Coberturas NoCobertura="04"><SumaAsegurada>3000000</SumaAsegurada><TipoSuma>0</TipoSuma><Deducible>0</Deducible><Prima>0</Prima>
	</Coberturas><Coberturas NoCobertura="05"><SumaAsegurada>500000</SumaAsegurada><TipoSuma>0</TipoSuma><Deducible>0</Deducible><Prima>0</Prima>
	</Coberturas><Coberturas NoCobertura="06"><SumaAsegurada>100000</SumaAsegurada><TipoSuma>0</TipoSuma><Deducible>0</Deducible><Prima>0</Prima>
	</Coberturas><Coberturas NoCobertura="07"><SumaAsegurada>0</SumaAsegurada><TipoSuma>0</TipoSuma><Deducible>0</Deducible><Prima>0</Prima></Coberturas><Coberturas NoCobertura="14"><SumaAsegurada>0</SumaAsegurada><TipoSuma>0</TipoSuma><Deducible>0</Deducible><Prima>0</Prima></Coberturas></DatosVehiculo><DatosGenerales><FechaEmision>2021-04-30</FechaEmision><FechaInicio>'. $current_date .'</FechaInicio><FechaTermino>'. $end_date .'</FechaTermino><Moneda>00</Moneda><Agente>14697</Agente><FormaPago>'. $FP .'</FormaPago><TarifaValores>LINEA</TarifaValores><TarifaCuotas>LINEA</TarifaCuotas><TarifaDerechos>LINEA</TarifaDerechos><Plazo/><Agencia/><Contrato/><PorcentajeDescuento>35</PorcentajeDescuento><ConsideracionesAdicionalesDG NoConsideracion="1"><TipoRegla>1</TipoRegla><ValorRegla>'. $verify .'</ValorRegla></ConsideracionesAdicionalesDG><ConsideracionesAdicionalesDG NoConsideracion="5"><TipoRegla>0</TipoRegla><ValorRegla>14</ValorRegla></ConsideracionesAdicionalesDG></DatosGenerales><Primas><PrimaNeta/><Derecho>520</Derecho><Recargo/><Impuesto/>
	<PrimaTotal/><Comision/></Primas><CodigoError/></Movimiento></Movimientos>';
			try {
				   $client = new SoapClient('http://sio.qualitas.com.mx/WsEmision/WsEmision.asmx?WSDL');
				   try {
					   $params = array('xmlEmision'=>$XML);
					   $result = $client->obtenerNuevaEmision($params);
					   $xml_result = $result->obtenerNuevaEmisionResult;
				   } catch (Exception $e){
					   $xml_result=$e->getMessage();
				   }
			   } catch (Exception $e){
				   $xml_result=preg_replace('/\'/','', $e->getMessage());
			   }
			$xml_qual = simplexml_load_string($xml_result);
			$qualitas = json_decode(json_encode($xml_qual), TRUE);
			$Items = array();
			$Items['1'] = "Daños Materiales";
			$Items['2'] = "DM Sólo pérdida total";
			$Items['3'] = "Robo Total";
			$Items['4'] = "Responsabilidad Civil";
			$Items['5'] = "Gastos Médicos";
			$Items['6'] = "Accidentes Ocupantes/Muerte del Conductor X Accidente (SA)";
			$Items['7'] = "Gastos Legales";
			$Items['8'] = "Equipo Especial";
			$Items['9'] = "Adaptaciones Daños Materiales";
			$Items['10'] = "Adaptaciones Robo Total";
			$Items['11'] = "Extensión de RCs";
			$Items['12'] = "Exención de Deducible";
			$Items['13'] = "RC Pasajero";
			$Items['14'] = "Asistencia Vial";
			$Items['15'] = "Robo Parcial";
			$Items['16'] = "Ajuste Automático";
			$Items['17'] = "Gastos de transporte";
			$Items['18'] = "Responsabilidad Civil Personas";
			$Items['19'] = "Responsabilidad Civil Bienes";
			$Items['20'] = "Responsabilidad Civil Catastrófica";
			$Items['21'] = "Responsabilidad Civil Ecológica";
			$Items['22'] = "Responsabilidad Civil Legal";
			$Items['23'] = "CIVA DM";
			$Items['24'] = "CIVA RT";
			$Items['25'] = "Asistencia Satelital";
			$Items['26'] = "Excencion de deducible por vuelco o colision";
			$Items['27'] = "AVC";
			$Items['28'] = "Gastos X Perdida de Uso X Perdidas Parciales";
			$Items['29'] = "PEUG EG";
			$Items['30'] = "PEUG SM";
			$Items['31'] = "Daños por la carga";
			$Items['32'] = "ADAP SPT";
			$Items['33'] = "Exención de deducible por prima nivelada";
			$Items['40'] = "Exención de Deducible";
			$Items['41'] = "AVERIA MECANICA Y/O ELECTRICA";
			$Items['47'] = "RC COMPLEMENTARIA";
			$Items['50'] = "Extensión de garantía";
			$Items['51'] = "Servicios de asistencia";
			$Items['52'] = "Carnét de Mantenimiento";
			$resultData['Item'] = $Items;
			
			if(isset($qualitas)){
				$resultData['qual'] = $qualitas;
				if(json_encode($qualitas['Movimiento']['Primas']['PrimaTotal']) != '[]'){
				$quotation = new Quotations();
				$quotation->cot_id = $qualitas['Movimiento']['@attributes']['NoCotizacion'];
				$quotation->user_id = $id;
				$quotation->municipality = $municipality;
				$quotation->cveveh = $camis;
				$quotation->DER = $qualitas['Movimiento']['Primas']['Derecho'];
				$quotation->REC = $qualitas['Movimiento']['Primas']['Recargo'];
				$quotation->iva = $qualitas['Movimiento']['Primas']['Impuesto'];
				$quotation->pneta = $qualitas['Movimiento']['Primas']['PrimaNeta'];
				$quotation->ptotal =  $qualitas['Movimiento']['Primas']['PrimaTotal'];
				$quotation->model = $mod;
				$quotation->marca = $marca;
				$quotation->condition = '0';
				$quotation->fp = $fp;
				$quotation->paq = $paq;
				$quotation->description = $qual;
				$quotation->company = "QUA";
				$quotation->start_date = $current_date;
				$quotation->end_date = $end_date;
				$quotation->save(); 
				}
			} 
		}
		$resultData['flag'] = "success";
        return $resultData;
    }
	
	public function get_Policy(String $xml, String $case){

        $TokenHeader = array(
          'usuario'=> "WSEMPJALISCO",
          'password'=> "AU77O$21",
        );
        //Variable de la URL del WS de Cotizacion
        $providerCotizaciones = 'http://www5.abaseguros.com/AutoConnect/ACCotizacion.svc?wsdl';
            
        //Se inicializa el objeto del WS para cotizar
        $_clientCotiza = new SoapClient($providerCotizaciones, array('trace' => true));

        //Se crea un objeto especial para SoapCliente con los encabezados
        $header = new SOAPHeader('http://tempuri.org/', 'Token', $TokenHeader);

        //Se agregan los encabezados al objeto del WS
        $_clientCotiza->__setSoapHeaders($header);

        try{
            if( $case == "quote_policy"){
                $result = $_clientCotiza->CotizaAuto(array('strEntrada' => $xml));
            } elseif($case == "subsequent_policy"){
                $result = $_clientCotiza->CotizaAuto_AS(array('strEntrada' => $xml));
            } else{
                echo "No case";
                die();
            }
            // Results are obtained 
            $data = $result->strSalida;

            $xml_file = simplexml_load_string($data);
            $json = json_encode($xml_file );
            $array_Data = json_decode($json,TRUE);

            return $array_Data;
        } catch (SoapFault $fault) {
            // catches soap faults
        } catch (Exception $e) {
            echo 'Caught exception: ',  $e->getMessage(), "\n";
        }
    }
	
	public function sendEmail(Request $request) {
        $toMail = $request->email;
        $description = $request->description;
		$customer = User::where('email', $toMail)->first();
		$name = $customer->firstname .' '. $customer->lastname;
		
		$new_quot = Quotations::where('cot_id', $request->cot_id)->orderBy('created_at', 'desc')->first();
		$new_quot->user_id = $customer->id;
		$new_quot->save();
		$users = User::where('role', '!=', 'client')->orwhere('email', $toMail)->get();
		foreach($users as $user){
			$notification = new Notifications();
			$notification->message = $new_quot->id;
			$notification->recipient_id = $user->id;
			$notification->status = "sent";
			$notification->kind = "new";
			$notification->taget = "Quotation";
			$notification->save();
		}
		$ids = $new_quot->id ."-". $request->qual_id;
        $customer_data = array('name' => $customer->firstname, 'quot_id' => $ids);
		
        Mail::send('mail.customer_mail', $customer_data, function($message) use ($toMail) {
            $message->from('contacto@segurosacv.com', 'Seguros ACV');
            $message->to($toMail)->subject('Cotización Mail de Seguros ACV');
          });
		
		$mails = array("leonardo.caro@acarov.com", "robert.caro@acarov.com", "elizabeth.aleman@acarov.com", "contacto@segurosacv.com");
		foreach($mails as $mail){
			if($mail == "contacto@segurosacv.com"){
				$staff_name = "Seguros ACV";
			} else{
				$staff = User::where('email', $mail)->first();
				$staff_name = $staff->firstname;
			}
			
			$staff_data = array(
				'first_name' => $staff_name,
				'name' => $name,
				'description' => $description,
				'phone_num' => $customer->phone, 
				'quot_id' => $ids,
				'client_id'=> $customer->id
			);
			Mail::send('mail.staff_mail', $staff_data, function($message) use ($mail) {
				$message->from('contacto@segurosacv.com', 'Seguros ACV');
				$message->to($mail)->subject('Mail from Seguros ACV');
			 });
		}
		return "Success";
    }
	
	public function getVerify($value){
		$val = ((substr($value, 0, 1)+substr($value, 2, 1)+substr($value, 4, 1))*3 + (substr($value, 1, 1)+substr($value, 3, 1))) % 10;
		$result = (10 - $val);
		if($result == 10)
			$result = 0;
		return $result;
	}
}
