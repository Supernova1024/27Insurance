<?php

namespace App\Http\Controllers;

use DB;
use Excel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Import\ImportData;

class ImportController extends Controller
{
	
	public function __construct()
	{
		$this->middleware(['auth' => 'verified']);
	}
	
    public function fileUploads(Request $request)
    {
		$data = array();
		$data['user'] = $request->user();
		
		if($data['user']->role == 'super'){
			$breadcrumbs = [
				['link' => "/", 'name' => "Bussiness"], ['link' => "javascript:void(0)", 'name' => "Tools"], ['name' => "Import"],
			];
			//Pageheader set true for breadcrumbs
			$pageConfigs = ['pageHeader' => true, 'isFabButton' => false];
			return view('pages.import', ['breadcrumbs' => $breadcrumbs], ['pageConfigs' => $pageConfigs])->with('data', $data);
			//return view('mail.user_mail', ['name' => 'Andrey'], ['quot_id' => "1121212"])->with('data', $data);
		} else{
			// custome class and customizer remove
			$pageConfigs = ['bodyCustomClass' => 'bg-full-screen-image', 'isCustomizer' => false];

			return view('pages.page-404', ['pageConfigs' => $pageConfigs]);
		}
    }
	public function import(Request $request)
	{
		if ($request->hasFile('csv')){

		  $file = $request->file('csv');

		  // File Details 
		  $filename = $file->getClientOriginalName();
		  $extension = $file->getClientOriginalExtension();
		  $tempPath = $file->getRealPath();
		  $fileSize = $file->getSize();
		  $mimeType = $file->getMimeType();
		  // $filename = date("Y-m-d-h-m").'.'. str_replace('xlsx', 'xlsx', $request->file('csv')->guessExtension());

		  // Valid File Extensions
		  $valid_extension = array("xlsx");

		  // 2MB in Bytes(16MB)
		  //$maxFileSize = 2097152; 
		  $maxFileSize = 16777216; 

		  // Check file extension
		  if(in_array(strtolower($extension),$valid_extension)){
			
			// Check file size
			if($fileSize <= $maxFileSize){

			  // File upload location
			  $location = 'datas';

			  // Upload file
			  $file->move($location,$filename);

			  // Import CSV to Database
			  $filepath = $location."/".$filename;			
				
			  // Reading file
			  // $allData = Excel::load($filepath, function($reader) {})->get(); // only Maatwebsite/excel 2.1.0
			  $importData = new ImportData;
			  Excel::import($importData, $filepath);
			  $importData->getArray();
				
			  return redirect()->back()->with(session()->flash('success', 'Success'));
			} else{
				return redirect()->back()->with(session()->flash('size-error', 'Size_error'));
			}
		  } else{
			  return redirect()->back()->with(session()->flash('type-error', 'Type_error'));
		  }

		} else{
			return redirect()->back()->with(session()->flash('error', 'Error'));
		}
	}
}
