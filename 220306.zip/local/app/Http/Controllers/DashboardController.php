<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Policies;
use App\Models\Quotations;
use App\Models\Notifications;
use App\Models\User;
use Illuminate\Http\Request;
use Mail;

class DashboardController extends Controller
{
    public function __construct()
    {
        $this->middleware(['auth' => 'verified']);
    }

    public function dashboard(Request $request)
    {
		$set_day = 5;
		$set = "+". $set_day ." days";
		$expired_date = date("Y-m-d", strtotime($set));
		$test = Policies::join('quotations', 'policies.quot_id', '=', 'quotations.id')
			->where('policies.status', '1')
			->where('quotations.end_date', $expired_date)->select('quotations.*', 'policies.*')->first();
		if(isset($test)){
			$is_expired = Notifications::where('message', $test->id)->where('kind', 'expired')->count();
		} else{
			$is_expired = 2;
		}
		if($is_expired < 1){
			$expireds = Policies::join('quotations', 'quotations.id', 'policies.quot_id')
				->where('policies.status', '1')
				->where('quotations.end_date', $expired_date)
				->select('quotations.*', 'policies.*')->get();
			foreach($expireds as $expired){
				$users = User::where('role', '!=', 'client')->orwhere('id', $expired->user_id)->get();
				foreach($users as $user){
					$notification = new Notifications();
					$notification->message = $expired->id;
					$notification->recipient_id = $user->id;
					$notification->status = "sent";
					$notification->kind = "expired";
					$notification->taget = "Policy";
					$notification->save();
				}
				$client = User::where('id', $expired->user_id)->first();
				$data = array('name' => $client->firstname, 'pol_id' =>  $expired->id, 'pol' =>  $expired->cve, 'pol_num' => $expired->pol, 'endDate' => $expired->end_date, 'set_day'=> $set_day,);
				Mail::send('mail.expired_mail', $data, function($message) use ($client, $expired, $set_day) {
					$message->from('contacto@segurosacv.com', 'Seguros ACV');
					$message->to($client->email)->subject($expired->cve.''.$expired->pol.' caducará después de '. $set_day .' días');
				  });
				Mail::send('mail.expired_mail', $data, function($message) use ($expired, $set_day) {
					$message->from('contacto@segurosacv.com', 'Seguros ACV');
					$message->to('cobranza@segurosacv.com')->subject($expired->cve.''.$expired->pol.' caducará después de '. $set_day .' días');
				  });
			}
		}
		
		$data = array();
		$user = $request->user();
		$data['year'] = date('Y');
		$data['last'] = $data['year'] - 1;
		if($user->role != 'client'){
			$data['total_pol'] = Quotations::where('condition', '1')->count();
			$data['new_pol'] = Quotations::where('condition', '1')->where('start_date', 'like', '%'. $data['year'] .'%')->count();
			$data['last_pol'] = Quotations::where('condition', '1')->where('start_date', 'like', '%'. $data['last'] .'%')->count();
			$data['total_client'] = User::where('role', 'client')->count(); 
			$data['active_client'] = User::where('role', 'client')->where('is_verified', 1)->count(); 
			$data['status'] = $data['new_pol'] - $data['last_pol']; 
			$this_month = date("Y-m");
			$earning = Quotations::where('condition', '1')
				->where('start_date', 'like', '%'. $this_month .'%')->get();
			$data['earning'] = 0;
			foreach($earning as $value){
				$data['earning'] = $data['earning'] + $value['pneta']*0.1;
			}
			$data['week_earning'] = 0;
			// navbar large
			$pageConfigs = ['navbarLarge' => false];
			return view('/pages/dashboard', ['pageConfigs' => $pageConfigs])->with('data', $data);
		} else{
			$data['total_quot'] = Quotations::where('condition', '0')->where('user_id', $user->id)->count();
			$data['new_quot'] = Quotations::where('condition', '0')
				->where('user_id', $user->id)->where('start_date', 'like', '%'. $data['year'] .'%')->count();
			$data['total_pol'] = Quotations::where('condition', '1')->where('user_id', $user->id)->count();
			$data['new_pol'] = Quotations::where('condition', '1')
				->where('user_id', $user->id)->where('start_date', 'like', '%'. $data['year'] .'%')->count();
			$this_month = date("Y-m");
			$earning = Quotations::where('condition', '1')->where('user_id', $user->id)
				->where('start_date', 'like', '%'. $this_month .'%')->get();
			$data['payed'] = 0;
			foreach($earning as $value){
				$data['payed'] = $data['payed'] + $value['ptotal'];
			}
			$data['payed'] = 0;
			
			$data['quotes'] = Quotations::where('condition', '0')->where('user_id', $user->id)->orderBy('start_date', 'desc')->get();
			$data['policies'] = Policies::join('quotations', 'quotations.id', 'policies.quot_id')
				->where('quotations.user_id', $user->id)->orderBy('quotations.start_date', 'desc')
				->select('quotations.*', 'policies.*')->get();
			// navbar large
			$pageConfigs = ['navbarLarge' => false, 'isFabButton' => true];
			return view('/client/dashboard', ['pageConfigs' => $pageConfigs])->with('data', $data);
		}
    }
	
	public function getData(Request $request)
	{
		$data = array();
		$year = $request->year;
		$last_year = $year - 1;
		$this_year = Quotations::where('condition', '1')
			->where('start_date', 'like', '%'. $year .'%')
			->orderBy('start_date', 'desc')->first();
		if(isset($this_year))
			$last_month = explode("-", $this_year);
		
		$months = array('01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12');
		$data['val'] = array();	
		$data['last'] = array();
		$i = 0;
		$flag = 0;
		if(isset($last_month)){
			foreach ($months as $month) {
				$i = $i + 1;
				if($flag == 0){
					$val = Quotations::where('condition', '1')->where('start_date', 'like', '%'. $year .'-'. $month .'%')->count();
					array_push($data['val'], $val);
					$last = Quotations::where('condition', '1')->where('start_date', 'like', '%'. $last_year .'-'. $month .'%')->count();
					array_push($data['last'], $last);
				}
				if($month == $last_month[1]){
					$data['count'] = $i;
					$flag = 1;
				}
			}
			// get min val
			$this_min = min($data['val']);
			$last_min = min($data['last']);
			$data['min'] = min($this_min, $last_min);

			// get max val
			$this_min = max($data['val']);
			$last_min = max($data['last']);
			$data['max'] = max($this_min, $last_min);
		} else{ 
			$data['count'] = 0; 
			$data['min'] = 0;
			$data['max'] = 100;
		}
		
		$week = array('monday', 'tuesday', 'wednesday', 'tursday', 'friday', 'saturday', 'sunday');
		$data['mon'] = date('d', strtotime('monday this week'));
		$data['sun'] = date('d', strtotime('sunday this week'));
		$data['week'] = array();
		foreach($week as $day){
			$week_day = date('Y-m-d', strtotime($day .' this week'));
			$week_val = Quotations::where('condition', '1')->where('start_date', $week_day)->get();
			$earning = 0;
			foreach($week_val as $value){
				$earning = $earning + $value->pneta* (10 - $value->BON)/100;
			}
			array_push($data['week'], $earning);
		}
		$data['sum'] = 0;
		foreach($data['week'] as $value){
			$data['sum'] = $data['sum'] + $value;
		}
		
		return $data;
	}
	
	public function javascript() {
        session()->reflash();
        return response(view('js.live'), 200)->header('Content-Type', 'text/javascript');
    }
	
	public function test(Request $request){
		$pageConfigs = ['bodyCustomClass' => 'app-page'];
		$data = array('name' => 'Andrey');
		return view('/PDF/policy', ['pageConfigs' => $pageConfigs])->with('data', $data);
	}
}
