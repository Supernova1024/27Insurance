<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Chats;
use App\Models\Policies;
use App\Models\Quotations;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\StreamedResponse;

class ChatController extends Controller
{
	public function __construct()
    {
        $this->middleware(['auth' => 'verified']);
    }
	
	public function filter(Request $request)
    {
		$user = $request->user();
		$result = array();
		if($request->name != ''){
			$name = str_word_count($request->name, 1);
			if( count($name) == 1){
				$firstname = $name[0];
				$lastname = '';
			} else{
				$firstname = $name[0];
				$lastname = $name[1];
			}
			$clients = User::where('users.firstname', 'like', '%'. $firstname .'%')
				->where('users.lastname', 'like', '%'. $lastname .'%')
				->get();
			foreach($clients as $client){
				if($client->id != $user->id){
					$chat = array();
					$chat_message = Chats::where('recipient_id', $user->id)->where('sender_id', $client->id)
						->orderBy('created_at', 'desc')->first();
					$new_count = Chats::where('recipient_id', $user->id)->where('sender_id', $client->id)
						->where('status', '!=', 'seen')->count();

					if(!isset($chat_message)){
						$last_message = "Null";
					} else{
						$last_message = $chat_message->message;
					}
					array_push($chat, $client);
					array_push($chat, $last_message);
					array_push($chat, $new_count);
					array_push($result, $chat);
				}
			}
		} else{
			$new_users = Chats::where('recipient_id', $user->id)->where('flag', '0')->orderBy('created_at', 'desc')->get();
			if($user->role != 'client'){
				foreach($new_users as $new_user){
					$_chat = array();
					$user_val = User::where('id', $new_user->sender_id)->first();
					$message_count = Chats::where('recipient_id', $user->id)->where('sender_id', $new_user->sender_id)
						->where('status', '!=', 'seen')->count();
					array_push($_chat, $user_val);
					array_push($_chat, $new_user->message);
					array_push($_chat, $message_count);
					array_push($result, $_chat);
				}
			}
			$chat_list = User::where('role', '!=', 'client')->where('email', '!=', $user->email)->get();
			foreach($chat_list as $value){
				$flag = 0;
				if(isset($new_users)){
					foreach($new_users as $new_user){
						if($new_user->sender_id == $value->id){
							$flag = 1;
						}
					}
				}
				if($flag != 1){
					$chat = array();
					$message = Chats::where('recipient_id', $user->id)->where('sender_id', $value->id)
						->orderBy('created_at', 'desc')->first();
					if(isset($message)){
						$last_message = $message->message;
						$new_count = Chats::where('recipient_id', $user->id)->where('sender_id', $value->id)
						->where('status', '!=', 'seen')->count();
					} else{
						$last_message = "";
						$new_count = 0;
					}
					array_push($chat, $value);
					array_push($chat, $last_message);
					array_push($chat, $new_count);
					array_push($result, $chat);
				}
			}
		}
        return $result;
    }
	
	public function chatContent(Request $request)
	{
		$result = array();
		$user = $request->user();
		$result['user'] = $user->email;
		$result['to_mail'] = $request->email;
		$result['to_user'] = User::where('email', $request->email)->first();
		$result['id'] = $user->id;
		$chats =Chats::where('sender_id', $result['to_user']->id)->where('recipient_id', $user->id)
			->where('status', '!=', 'seen')->get();
		foreach($chats as $val){
			$chat = Chats::where('id', $val->id)->first();
			$chat->status = 'seen';
			$chat->save();
		}
		$result['chat'] = Chats::where(function($query1) use ($result, $user) {
			$query1->where('recipient_id', $result['to_user']->id)->Where('sender_id', $user->id);})
			->orwhere(function($query2) use ($result, $user) {
			$query2->where('sender_id', $result['to_user']->id)->where('recipient_id', $user->id);})->get();
		return $result;
	}
	
	public function sendMessage(Request $request)
    {
		$user = $request->user();
		$recipient = User::where('email', $request->to)->first();
		$previous = Chats::where('recipient_id', $recipient->id)->where('sender_id', $user->id)
			->where('flag', '0')->first();
		if(isset($previous)){
			$previous->flag = '1';
			$previous->save();
		}
		$old = Chats::where('recipient_id', $user->id)->where('sender_id', $recipient->id)->orderBy('created_at', 'desc')->first();
		if(isset($old)){
			$old->status = 'seen';
			$old->save();
		}
		if ($request->hasFile('file')){
			$file = $request->file('file');
            // File Details 
			$filename = $file->getClientOriginalName();
			$file->move("local/storage/attached",$filename);
		}
		$chat = new Chats();
		if(isset($filename))
			$chat->type = $this->getType($filename);
		$chat->message = $request->message;
		$chat->recipient_id = $recipient->id;
		$chat->sender_id = $user->id;
		$chat->status = 'sent';
		$chat->flag = '0';
		$chat->save();
		return "Success";
    }
	
	public function chatApp(Request $request)
    {
        // custom body class
        $pageConfigs = ['bodyCustomClass' => 'app-page'];
		
		$data = array();
		$user = $request->user();
		$data['staffs'] = array();
		$key = 0;
		if($user->role != 'client'){
			$new_users = Chats::where('recipient_id', $user->id)->where('flag', '0')->orderBy('created_at', 'desc')->get();
			foreach($new_users as $chat){
				if($key == 0){
					$data['messages'] = Chats::where(function($query1) use ($chat, $user) {
						$query1->where('recipient_id', $user->id)->Where('sender_id', $chat->sender_id);})
						->orwhere(function($query2) use ($chat, $user) {
						$query2->where('recipient_id', $chat->sender_id)->where('sender_id', $user->id);})->get();
					$data['client'] = User::where('id', $chat->sender_id)->first();
					$key = 1;
				}
				$_user = User::where('id', $chat->sender_id)->first();
				$val = array();
				$val['id'] = $_user->id;
				$val['firstname'] = $_user->firstname;
				$val['lastname'] = $_user->lastname;
				$val['email'] = $_user->email;
				$val['image'] = $_user->image;
				$val['role'] = $_user->role;
				$val['message'] = $chat->message;
				$val['count'] = Chats::where('recipient_id', $user->id)->where('sender_id', $chat->sender_id)
					->where('status', '!=', 'seen')->count();
				array_push($data['staffs'], $val);
			}
			$count = count($data['staffs']);
		} else{
			$count = 0;
		}
		if( $count < 8){
			$chat_list = User::where('role', '!=', 'client')->where('email', '!=', $user->email)->get();
			foreach($chat_list as $value){
				if($key == 0){
					$data['messages'] = Chats::where(function($query1) use ($value, $user) {
						$query1->where('recipient_id', $user->id)->Where('sender_id', $value['id']);})
						->orwhere(function($query2) use ($value, $user) {
						$query2->where('recipient_id', $value['id'])->where('sender_id', $user->id);})->get();
					$data['client'] = User::where('id', $value['id'])->first();
					$key = 1;
				}
				$flag = 0;
				foreach($data['staffs'] as $staff){
					if($value->id == $staff['id'])
						$flag = 1;
				}
				if($flag == 0){
					$val = array();
					$val['id'] = $value->id;
					$val['firstname'] = $value->firstname;
					$val['lastname'] = $value->lastname;
					$val['email'] = $value->email;
					$val['image'] = $value->image;
					$val['role'] = $value->role;
					$message = Chats::where('recipient_id', $user->id)
						->where('sender_id', $value['id'])->orderBy('created_at', 'desc')->first();
					if(isset($message)){
						$val['message'] = $message->message;
						$val['count'] = Chats::where('recipient_id', $user->id)
							->where('sender_id', $value['id'])->where('status', '!=', 'seen')->count();
					} else{
						$val['message'] = "";
						$val['count'] = 0;
					}
					array_push($data['staffs'], $val);
				}
			}
		}
        return view('pages.app-chat', ['pageConfigs' => $pageConfigs])->with('data', $data);
    }
	
	public function live(Request $request) 
	{
		$user = $request->user();
		$new_messages = Chats::where('recipient_id', $user->id)->where('status', '!=', 'seen')->orderBy('created_at', 'asc')->get();
		$messages = json_encode($new_messages);
		if(!$request->ajax()) {
			if($new_messages->count() > 0) {
				// Receive the messages
				$new_messages->transform(function($message) {
					$message->status = 'received';
					$message->save();
					return $message;
				});
			}
			$response = new StreamedResponse();
			$response->headers->set('Content-Type', 'text/event-stream');
			$response->headers->set('Cache-Control', 'no-cache');
			$response->sendHeaders();
			$response->setCallback(function() use($request, $new_messages, $messages) {
				echo "data: {$messages}\n\n";
				ob_flush();
				flush();
			});
			$response->send();
		}
	}
	
	public function getType($value){
		$val = explode(".", $value);
		return $val[1];
	}
	
	public function download(Request $request)
	{
		$file = storage_path("/attached/". $request->id);
		//return $file;
		
		$headers = ['Content-Type: image/jpeg'];
		return \Response::download($file, $request->id, $headers);
	}
}