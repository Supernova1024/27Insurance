<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Quotations;
use App\Models\Policies;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;

class UserController extends Controller
{
	public function __construct()
    {
        $this->middleware(['auth' => 'verified']);
    }
	
	public function lockScreen(Request $request)
	{
		$pageConfigs = ['bodyCustomClass' => 'forgot-bg', 'isCustomizer' => false];
		
		$data = array();
		$data['user'] = $request->user();

        return view('pages.lock-screen', ['pageConfigs' => $pageConfigs])->with('data', $data);
	}
	
	public function unlock(Request $request)
	{
		$check = Hash::check($request->input('password'), $request->user()->password);

		if(!$check){
			return redirect()->back()->with(session()->flash('error', 'Password is not correct.'));
		}

		return redirect("/");
	} 
	
	public function changePassword(Request $request)
	{
		$user = User::where('email', $request->user()->email)->first();
		if($request->newpswd == $request->repswd){
			if(!(Hash::check($request->get('old_password'), Auth::user()->password))){
				$user->password = Hash::make($request->newpswd);
				$user->save();
				return redirect()->back()->with(session()->flash('success', 'Update'));
			} else{
				return redirect()->back()->with(session()->flash('error', 'Change_txt1'));
			}
		} else{
			return redirect()->back()->with(session()->flash('error', 'Change_txt2'));
		}
		
	}
	
	// Clients Management
    public function clientsList(Request $request)
    {
		if($request->user()->role != 'client'){
			$breadcrumbs = [
				['link' => "/", 'name' => "Bussiness"], ['link' => "javascript:void(0)", 'name' => "Client"], ['name' => "List"]];
			//Pageheader set true for breadcrumbs
			$pageConfigs = ['pageHeader' => true, 'isFabButton' => false];

			$data = array();
			$data['clients'] = array();
			$clients = User::where('role', 'client')->get();
			foreach($clients as $client){
				$flag = User::join('quotations', 'quotations.user_id', 'users.id')
					->join('policies', 'policies.quot_id', 'quotations.id')
					->where('quotations.end_date', '>', date('Y-m-d'))
					->where('policies.status', '1')
					->where('users.id', $client->id)->count();
				if($flag > 0){
					$active = User::where('id', $client->id)->first();
					array_push($data['clients'], $active);
				}
			}

			return view('pages.clients-list', ['pageConfigs' => $pageConfigs], ['breadcrumbs' => $breadcrumbs])->with('data', $data);
		} else{
			// custome class and customizer remove
			$pageConfigs = ['bodyCustomClass' => 'bg-full-screen-image', 'isCustomizer' => false];

			return view('pages.page-404', ['pageConfigs' => $pageConfigs]);
		}
    }
	
    public function clientView(Request $request)
    {
		if($request->user()->role != 'client'){
			$breadcrumbs = [
				['link' => "/", 'name' => "Bussiness"], ['link' => "javascript:void(0)", 'name' => "Client"], ['name' => "View"]];
			//Pageheader set true for breadcrumbs
			$pageConfigs = ['pageHeader' => true, 'isFabButton' => false];

			$data = array();
			$data['client'] = User::where('id', $request->id)->first();
			//var_dump($data['client']);
			//die();
			$data['policies'] = Policies::join('quotations', 'quotations.id', 'policies.quot_id')
				->where('quotations.user_id', $request->id)
				->orderBy('quotations.start_date', 'desc')
				->select('quotations.*', 'policies.*')->get();
			$data['quotes'] = Quotations::where('user_id', $request->id)
				->where('condition', 0)->get();

			return view('pages.client-view', ['pageConfigs' => $pageConfigs], ['breadcrumbs' => $breadcrumbs])->with('data', $data);
		} else{
			// custome class and customizer remove
			$pageConfigs = ['bodyCustomClass' => 'bg-full-screen-image', 'isCustomizer' => false];

			return view('pages.page-404', ['pageConfigs' => $pageConfigs]);
		}
    }
	
    public function clientEdit(Request $request)
    {
		if($request->user()->role != 'client'){
			$breadcrumbs = [
				['link' => "/", 'name' => "Bussiness"], ['link' => "javascript:void(0)", 'name' => "Client"], ['name' => "Edit"]];
			//Pageheader set true for breadcrumbs
			$pageConfigs = ['pageHeader' => true, 'isFabButton' => false];

			$data = array();
			$data['user'] = $request->user();
			$data['client'] = User::where('id', $request->id)->first();
			
			return view('pages.client-edit', ['pageConfigs' => $pageConfigs], ['breadcrumbs' => $breadcrumbs])->with('data', $data);
		} else{
			// custome class and customizer remove
			$pageConfigs = ['bodyCustomClass' => 'bg-full-screen-image', 'isCustomizer' => false];

			return view('pages.page-404', ['pageConfigs' => $pageConfigs]);
		}
    }
	
	public function clientUpdate(Request $request, User $user )
	{
		$user = User::where('id', $request->id)->first();
		$user->firstname      = $request->firstname;
		$user->lastname       = $request->lastname;
		$user->paternal_surname       = $request->paternal;
		$user->maternal_surname       = $request->maternal;
		$user->email          = $request->email;
		$user->birthday       = $request->birthday;
		$user->sex            = $request->sex;
		$user->marital        = $request->marital;
		$user->address        = $request->address;
		$user->phone          = $request->phone;
		$user->telephone      = $request->telephone;
		$user->save();
		
		return redirect()->route('client-list');
	}
	
	// Staffs management
	public function staffsList(Request $request)
    {
		if($request->user()->role == 'super'){
			$breadcrumbs = [
				['link' => "/", 'name' => "Setting"], ['link' => "javascript:void(0)", 'name' => "Staff"], ['name' => "List"]];
			//Pageheader set true for breadcrumbs
			$pageConfigs = ['pageHeader' => true, 'isFabButton' => false];

			$data = array();
			$data['user'] = $request->user();
			$data['staffs'] = User::where('role', 'staff')->get();

			return view('pages.staffs-list', ['pageConfigs' => $pageConfigs], ['breadcrumbs' => $breadcrumbs])->with('data', $data);
		} else{
			// custome class and customizer remove
			$pageConfigs = ['bodyCustomClass' => 'bg-full-screen-image', 'isCustomizer' => false];

			return view('pages.page-404', ['pageConfigs' => $pageConfigs]);
		}
    }
    public function staffView(Request $request)
    {
		if($request->user()->role == 'super'){
			$breadcrumbs = [
				['link' => "/", 'name' => "Setting"], ['link' => "javascript:void(0)", 'name' => "Staff"], ['name' => "View"]];
			//Pageheader set true for breadcrumbs
			$pageConfigs = ['pageHeader' => true, 'isFabButton' => false];

			$data = array();
			$data['user'] = $request->user();
			$data['year'] = date("Y");
			$data['staff'] = User::where('id', $request->id)->first();
			if($data['staff']->firstname == 'Roberto')
				$key = "RC";
			else if($data['staff']->firstname == 'Elizabeth')
				$key = "EA";
			else $key = "";
			$data['policies'] = Policies::join('quotations', 'policies.quot_id', '=', 'quotations.id')
				->join('users', 'quotations.user_id', '=', 'users.id')
				->where('quotations.start_date', 'like', '%'. $data['year'] .'%')
				->where('policies.issuer', $key)
				->select('quotations.*', 'users.*', 'policies.*')->get();

			return view('pages.staff-view', ['pageConfigs' => $pageConfigs], ['breadcrumbs' => $breadcrumbs])->with('data', $data);
		} else{
			// custome class and customizer remove
			$pageConfigs = ['bodyCustomClass' => 'bg-full-screen-image', 'isCustomizer' => false];

			return view('pages.page-404', ['pageConfigs' => $pageConfigs]);
		}
    }
    public function staffEdit(Request $request)
    {
		if($request->user()->role == 'super'){
			$breadcrumbs = [
				['link' => "/", 'name' => "Setting"], ['link' => "javascript:void(0)", 'name' => "Staff"], ['name' => "Edit"]];
			//Pageheader set true for breadcrumbs
			$pageConfigs = ['pageHeader' => true, 'isFabButton' => false];

			$data = array();
			$data['user'] = $request->user();
			$data['staff'] = User::where('id', $request->id)->first();

			return view('pages.staff-edit', ['pageConfigs' => $pageConfigs], ['breadcrumbs' => $breadcrumbs])->with('data', $data);
		} else{
			// custome class and customizer remove
			$pageConfigs = ['bodyCustomClass' => 'bg-full-screen-image', 'isCustomizer' => false];

			return view('pages.page-404', ['pageConfigs' => $pageConfigs]);
		}
    }
	
	public function staffUpdate(Request $request, User $user )
	{
		$user = User::where('id', $request->id)->first();
		$user->firstname      = $request->firstname;
		$user->lastname       = $request->lastname;
		$user->email          = $request->email;
		$user->birthday       = $request->birthday;
		$user->rfc            = $request->department;
		$user->address        = $request->address;
		$user->phone          = $request->phone;
		$user->telephone      = $request->telephone;
		$user->save();
		
		return redirect()->route('staff-list');
	}
	
	public function accountSetting(Request $request)
	{
		$breadcrumbs = [
            ['link' => "/", 'name' => "Setting"], ['link' => "javascript:void(0)", 'name' => "Account"], ['name' => "Setting"],
        ];
        //Pageheader set true for breadcrumbs
        $pageConfigs = ['pageHeader' => true];
		
		$data = array();
		$data['user'] = $request->user();

        return view('pages.account-settings', ['pageConfigs' => $pageConfigs], ['breadcrumbs' => $breadcrumbs])->with('data', $data);
	}
	
	public function accountGeneral(Request $request)
	{
		$user = User::where('id', $request->user()->id)->first();
		$user->firstname = $request->firstname;
		$user->lastname = $request->lastname;
		$user->paternal_surname = $request->paternal_surname;
		$user->maternal_surname = $request->maternal_surname;
		$user->birthday = $request->birthday;
		$user->sex    = $request->sex;
		$user->marital    = $request->marital;
		$user->address = $request->address;
		$user->phone = $request->phone;
		$user->telephone = $request->tele;
		$user->postal_code = $request->postal_code;
		if ($request->hasFile('image') && $request->file('image')->isValid()){
			$file = $request->file('image');
			$filename = date("Y-m-d-h-m").'.'. str_replace('jpg', 'jpg', $request->file('image')->guessExtension());
			
			$file->move("images/user/",$filename);
			$user->image = $filename;
		}
		$user->save();
		
		return redirect()->back()->with(session()->flash('success', 'Update'));
	}

}
