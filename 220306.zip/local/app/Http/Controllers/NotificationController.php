<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Notifications;
use Illuminate\Http\Request;

class NotificationController extends Controller
{
	public function __construct()
    {
        $this->middleware(['auth' => 'verified']);
    }
	
	public function newQuot(Request $request)
    {
		$id = $request->user()->id;
		$messages_to_see = Notifications::where('recipient_id', $id)
			->where('status', 'sent')->where('kind', 'new')->where('taget', 'Quotation')->get();
		$messages_to_see->each(function($message) {
			$message->status = 'received';
			$message->save();
		});
		$data = array();
		$data['news'] = Notifications::join('quotations', 'quotations.id', '=', 'notifications.message')
			->join('users', 'users.id', 'quotations.user_id')
			->where('notifications.recipient_id', $id)
			->where('notifications.kind', 'new')
			->where('notifications.taget', 'Quotation')
			->orderBy('notifications.created_at', 'desc')
			->select('users.*', 'quotations.*', 'notifications.*')
			->get();
		
        // custom body class
        $pageConfigs = ['bodyCustomClass' => 'app-page'];

		return view('pages.notifi-quot_new', ['pageConfigs' => $pageConfigs])->with('data', $data);
    }
	
	public function new(Request $request)
    {
		$id = $request->user()->id;
		$messages_to_see = Notifications::where('recipient_id', $id)
			->where('status', 'sent')->where('kind', 'new')->where('taget', 'Policy')->get();
		$messages_to_see->each(function($message) {
			$message->status = 'received';
			$message->save();
		});
		$data = array();
		$data['news'] = Notifications::join('policies', 'policies.id', '=', 'notifications.message')
			->join('quotations', 'quotations.id', '=', 'policies.quot_id')
			->join('users', 'users.id', 'quotations.user_id')
			->where('notifications.recipient_id', $id)
			->where('notifications.kind', 'new')
			->where('notifications.taget', 'Policy')
			->orderBy('notifications.created_at', 'desc')
			->select('users.*', 'quotations.*', 'policies.*', 'notifications.*')
			->get();
		
        // custom body class
        $pageConfigs = ['bodyCustomClass' => 'app-page'];

		return view('pages.notifi-new', ['pageConfigs' => $pageConfigs])->with('data', $data);
    }
	public function canceled(Request $request)
    {
		$id = $request->user()->id;
		$messages_to_see = Notifications::where('recipient_id', $id)
			->where('status', 'sent')->where('kind', 'canceled')->where('taget', 'Policy')->get();
		$messages_to_see->each(function($message) {
			$message->status = 'received';
			$message->save();
		});
		$data = array();
		$data['news'] = Notifications::join('policies', 'policies.id', '=', 'notifications.message')
			->join('quotations', 'quotations.id', '=', 'policies.quot_id')
			->join('users', 'users.id', 'quotations.user_id')
			->where('notifications.recipient_id', $id)
			->where('notifications.kind', 'canceled')
			->where('notifications.taget', 'Policy')
			->orderBy('notifications.created_at', 'desc')
			->select('users.*', 'quotations.*', 'policies.*', 'notifications.*')
			->get();
		
        // custom body class
        $pageConfigs = ['bodyCustomClass' => 'app-page'];

		return view('pages.notifi-canceled', ['pageConfigs' => $pageConfigs])->with('data', $data);
    }
	public function expired(Request $request)
    {
		$id = $request->user()->id;
		$messages_to_see = Notifications::where('recipient_id', $id)
			->where('status', 'sent')->where('kind', 'expired')->where('taget', 'Policy')->get();
		$messages_to_see->each(function($message) {
			$message->status = 'received';
			$message->save();
		});
		$data = array();
		$data['news'] = Notifications::join('policies', 'policies.id', '=', 'notifications.message') 
			->join('quotations', 'quotations.id', '=', 'policies.quot_id')
			->join('users', 'users.id', 'quotations.user_id')
			->where('notifications.recipient_id', $id)
			->where('notifications.kind', 'expired')
			->where('notifications.taget', 'Policy')
			->orderBy('notifications.created_at', 'desc')
			->select('users.*', 'quotations.*', 'policies.*', 'notifications.*')
			->get();
		
        // custom body class
        $pageConfigs = ['bodyCustomClass' => 'app-page'];

		return view('pages.notifi-expired', ['pageConfigs' => $pageConfigs])->with('data', $data);
    }
}