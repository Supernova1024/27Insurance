<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\LanguageController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\QuotController;
use App\Http\Controllers\PolicyController;
use App\Http\Controllers\ImportController;
use App\Http\Controllers\ChartController;
use App\Http\Controllers\ReportController;
use App\Http\Controllers\AppController;
use App\Http\Controllers\ChatController;
use App\Http\Controllers\NotificationController;
use App\Http\Controllers\PDFController;

use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Auth\RegisterController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Auth::routes(['verify' => true]);

Route::get('verify', 'Auth\RegisterController@verifyUser')->name('verify.user');

// locale route
Route::get('lang/{locale}', 'LanguageController@swap');

// Dynamic JS asset route
Route::get('assets/js/live.js', 'DashboardController@javascript');

// test
// Route::get('test', 'DashboardController@test');
// Route::get('test', 'PDFController@test');

// Dashboard Route
Route::get('/', 'DashboardController@dashboard');
Route::post('data', 'DashboardController@getData');
Route::post('active', 'DashboardController@activeCustomer');

// Client Route
Route::get('client-list', 'UserController@clientsList')->name('client-list');
Route::get('client-view/{id}', 'UserController@clientView')->name('client-view');
Route::get('client-edit/{id}', 'UserController@clientEdit')->name('client-edit');
Route::post('client/{id}', 'UserController@clientUpdate');

// Staff Route
Route::get('staff-list', 'UserController@staffsList')->name('staff-list');
Route::get('staff-view/{id}', 'UserController@staffView')->name('staff-view');
Route::get('staff-edit/{id}', 'UserController@staffEdit')->name('staff-edit');
Route::post('staff/{id}', 'UserController@staffUpdate');

// CSV Import
Route::get('import', 'ImportController@fileUploads');
Route::post('import', 'ImportController@import')->name('import');

// Quotation

Route::get('quot-list/{year}', 'QuotController@quotList');
Route::post('quot-update', 'QuotController@quotUpdate');
Route::get('quot-edit/{id}', 'QuotController@quotEdit')->name('quot-edit');
Route::get('quot-create', 'QuotController@newQuot');
Route::post('quot-create/subBrands', 'QuotController@getSubBrands');
Route::post('quot-create/models', 'QuotController@getModels');
Route::post('quot-create/description', 'QuotController@getDescription');
Route::post('quot-create/person', 'QuotController@getPerson');
Route::post('quot-create/quot', 'QuotController@getQuot');
Route::post('quot-create/sendEmail', 'QuotController@sendEmail');
Route::post('quot-create/submitQuot', 'QuotController@submitQuot');
Route::post('quot-create/register_insured', 'QuotController@registerInsured');
Route::get('quot-pdf/{id}', 'QuotController@quotPdf')->name('quot-pdf');


// Policy
Route::get('policy-list/{year}', 'PolicyController@policyList')->name('policy-list');
Route::post('policy-update', 'PolicyController@policyUpdate')->name('policy-update');
Route::get('policy-new/{id}', 'PolicyController@policyNew')->name('policy-new');
Route::get('policy-edit/{id}', 'PolicyController@policyEdit')->name('policy-edit');
Route::post('policy-issuing', 'PolicyController@policyIssuing');

// Report Route
Route::get('report/{year}', 'ReportController@report');
Route::post('report/chart', 'ReportController@getChart');

// Notifications
Route::get('quot_notify', 'NotificationController@newQuot');
Route::get('new', 'NotificationController@new');
Route::get('expired', 'NotificationController@expired');
Route::get('canceled', 'NotificationController@canceled');

// Mail Route
Route::get('app-email', 'AppController@emailApp');
Route::post('app-email', 'AppController@emailApp_post');
Route::get('app-email/content/{mesag_id}/{folder}', 'AppController@emailContentApp');
Route::post('app-email/delete', 'AppController@delMail_post');
Route::post('send-email', 'AppController@sendEmail')->name('send-email');

// Chat Route
Route::get('chat', 'ChatController@chatApp');
Route::get('chats/live', 'ChatController@live')->name('Chatlive');
Route::post('chats/see', 'ChatController@see')->name('Chatsee');
Route::post('chats', 'ChatController@send')->name('Chatsend');
Route::post('filter', 'ChatController@filter');
Route::post('send_message', 'ChatController@sendMessage');
Route::post('chat-content', 'ChatController@chatContent');
Route::get('download/{id}', [ChatController::class, 'download']);

// Account Route
Route::get('account', 'UserController@accountSetting');
Route::post('account-general', 'UserController@accountGeneral')->name('account-general');
Route::post('change-password', 'UserController@changePassword');
Route::get('lock', 'UserController@lockScreen');
Route::post('unlock', 'UserController@unlock');


// Form Route
Route::get('form-elements', 'FormController@formElement');
Route::get('form-select2', 'FormController@formSelect2');
Route::get('form-validation', [FormController::class, 'formValidation']);
Route::get('form-masks', [FormController::class, 'masksForm']);
Route::get('form-editor', [FormController::class, 'formEditor']);
Route::get('form-file-uploads', [FormController::class, 'fileUploads']);
Route::get('form-layouts', [FormController::class, 'formLayouts']);
Route::get('/form-wizard', [FormController::class, 'formWizard']);

// PDF
Route::get('quot-pdf/{id}', [PDFController::class, 'quotationPDF'])->name('quot-pdf');
Route::get('policy-pdf/{id}', [PDFController::class, 'policyPDF'])->name('policy-pdf');
Route::get('quote', 'PDFController@qualitas');
