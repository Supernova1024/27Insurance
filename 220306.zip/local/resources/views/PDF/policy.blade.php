<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
    <title>{{ $cve }}{{ $pol }}</title>
	<style>
		table {
			font-family: arial, sans-serif;
			border-collapse: collapse;
			width: 100%;
		}

		td, th {
			border: 1px solid #dddddd;
			text-align: left;
			padding: 8px;
		}
		.left{
			float: left;
		}
		
		.right{
			float: right;
		}
		
		.both{
			display: table;
			clear: both;
		}

	</style>
</head>
<body>
	@if($company == 'ABA')
	<img src="{{ public_path('ABA.svg') }}" style="width: 210px; height: 70px">
	@elseif($company == 'QUA')
	<img src="{{ public_path('Qual.svg') }}" style="width: 210px; height: 70px">
	@elseif($company == 'ANA')
	<img src="{{ public_path('ANA.svg') }}" style="width: 210px; height: 70px">
	@elseif($company == 'HDI')
	<img src="{{ public_path('HDI.png') }}" style="width: 210px; height: 70px">
	@elseif($company == 'AXA')
	<img src="{{ public_path('AXA.png') }}" style="width: 210px; height: 70px">
	@endif
	<table>
		<tr>
			<td style = "width:30%;"><h2>Póliza:&nbsp;{{ $cve }}{{ $pol }}</h2></td>
			<td style = "width:70%;">Vigencia:&nbsp;{{ $start_date }} 12:00 horas al {{ $end_date }} 12:00 horas</td>
		</tr>
		<tr>
			<td style = "width:50%;">Paquete:&nbsp;
				@if($paq == 1)
					AMPLIA
				@elseif($paq == 2)
					LIMITADA
				@elseif($paq == 3)
					RC
				@else
					INTEGRAL
				@endif
			</td>
			<td style = "width:50%;">Forma de pago:&nbsp;
				@if($fp == 12)
					Counted
				@elseif($fp == 28)
					SEMESTRAL S / R PRSP
				@elseif($fp == 29)
					QUARTERLY S / R DERP
				@elseif($fp == 27)
					MONTHLY S / R DERP
				@elseif($fp == 31)
					QUINCENAL S / R DERP
				@else
					QUINCENAL EXACT
				@endif
			</td>
		</tr>
	</table>
	<h3>Datos del asegurado y/o propietario</h3>
	<p>Asegurado:&nbsp;{{$insured}}</p>
	<p>Propietario/Contratante:&nbsp;{{$insured}}</p>
	<p>Domicilio: CONCORDIA EXT. 212, ESPERANZA, GUADALAJARA, JALISCO, MEXICO</p>
	<p>CP.:&nbsp;{{$cp}}</p>
	<p>Teléfono:&nbsp;{{$telephone}}</p>
	<p>R.F.C.:&nbsp;{{$rfc}}</p>
	<h3>Descripción del vehículo</h3>
	<p>Descripción del vehículo*: {{$description}}</p>
	<p>Marca: {{$marca}}</p>
	<p>Model: {{$model}}</p>
	<p>Capacidad: 5</p>
	<p>Servicio: PARTICULAR</p>
	<p>Uso: PRIVADO</p>
	<p>Serie: {{$serie}}</p>
	<p>Motor: {{$motor}}</p>
	<p>Placas: {{$plates}}</p>
	<h3>Desglose de coberturas</h3>
	<p>Prima neta: ${{$pneta}}|MXN</p>
	<p>Gastos de expedición: ${{$DER}}|MXN</p>
	<p>I.V.A.: ${{$iva}}|MXN</p>
	<p>Prima total: ${{$ptotal}}|MXN</p>
</body>
</html>