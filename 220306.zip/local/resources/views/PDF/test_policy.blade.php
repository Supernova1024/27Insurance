<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
    <title>Test</title>
</head>
<body>
	<img src="{{ public_path('test.jpg') }}" style="width: 200px; height: 200px">
	<h1>Póliza:&nbsp;Andrey</h1>
</body>
</html>