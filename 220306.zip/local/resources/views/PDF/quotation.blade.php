<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
    <title>Cotización{{ $cot_id }}</title>
	<link rel="apple-touch-icon" href="{{asset('images/favicon/apple-touch-icon-152x152.png')}}">
  	<link rel="shortcut icon" type="image/x-icon" href="{{asset('images/favicon/favicon-32x32.png')}}">
	<style>
		table {
			font-family: arial, sans-serif;
			border-collapse: collapse;
			width: 100%;
		}

		td, th {
			border: 1px solid #dddddd;
			text-align: left;
			padding: 8px;
		}
		
		.title{
			width: 70%;
		}
		
		.left{
			float: left;
		}
		
		.right{
			float: right;
		}
		
		.both{
			display: table;
			clear: both;
		}

	</style>
</head>
<body>
    <h1>ACV</h1>
    <strong>{{ $firstname}} {{ $lastname}} {{ $paternal}} {{ $maternal}}</strong>
    <p>Teléfono: {{ $phone}}</p>
    <p>E-mail: {{ $email}}</p>
	<div class="both">
		<h3 class="left">Cotización # {{ $cot_id}}</h3> 
		<strong class="right">Girada el: {{ $start_date}}</strong>
	</div>
	<p style="clear: left;">{{ $marca}} {{ $description}}</p>
	<p>{{ $model}}</p>
	<table>
		<tr>
			<th class="title">Compañía de Seguros</th>
			<th>Costo</th>
		</tr>
		@if($ABA_company != 'Null')
		<tr>
			<td class="title">{{ $ABA_company}} SEGUROS</td>
			<td>$ {{ $ABA_ptotal}}|MXN</td>
		</tr>
		@endif
		@if($Qual_company != 'Null')
		<tr>
			<td class="title">{{$Qual_company}} SEGUROS</td>
			<td>$ {{ $Qual_ptotal}}|MXN</td>
		</tr>
		@endif
	</table>
	<p>Notas:</p>
	<p>PARA ASEGURAR SU AUTO requisitos: IFE/INE (o equivalente), Gafete/Identificación Laboral, Factura/Pedimento o Tarjeta de Circulación, Datos bancarios. Esta cotización tiene una vigencia de 15 días naturales, sujeta a cambio sin previo aviso por la naturaleza cambiante de la siniestralidad. Ingrese a la siguiente liga para iniciar la emisión de su póliza:</p>
	<a herf="https://segurosacv.com/alta-auto">https://segurosacv.com/alta-auto</a>
	<p>*En caso de contratar su Póliza en modalidad DOMICILIAR, el 1er recibo será cargado a inicio de vigencia en su cuenta bancaria ***Usted como empleado de GOBIERNO tiene derecho a ingresar los vehículos que desee a nuestra FLOTILLA DE GOBIERNO (amigos y familiares). ***El primer recibo líquida en 1 sola exhibición prima por cobertura RC (seguro obligatorio Art.40,145,150) ****CLÁUSULA DESCUENTO POR NÓMINA O DOMICILIACIÓN BANCARIA El contratante de un seguro bajo el esquema de “Descuento por Nómina o Domiciliación Bancaria” (cuenta de cheques, débito o crédito), tiene la obligación de vigilar que en su estados de cuenta se haya realizado la retención de la prima del seguro, dentro de los 30 días naturales siguientes al inicio de la vigencia. En caso de que no aparezca dicha retención/descuento en su cuenta bancaria, deberá de inmediato reportarlo. Si dentro de 30 días naturales posteriores al inicio de vigencia de la póliza, no se ha realizado la primera retención, se aplicará la CANCELACIÓN por falta de pago, de acuerdo a la cláusula “Prima y obligaciones de Pago”, descrita en las condiciones Generales de su póliza.</p>
	<p>Mas información: </p>
	<p>WhatsApp:<a href="https://api.whatsapp.com/send?phone=5213335876688&text=Hola%20CAROV%20Asesores%20en%20Seguros%2C%20tengo%20una%20consulta.%20Me%20pueden%20ayudar%20por%20favor%3F" target="_blank"> 33 3587 6688 </p>
	<p><a href="https://segurosacv.com/">segurosacv.com</a></p>
	
</body>
</html>