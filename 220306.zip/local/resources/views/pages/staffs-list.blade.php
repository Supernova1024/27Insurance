{{-- layout extend --}}
@extends('layouts.contentLayoutMaster')

{{-- page title --}}
@section('title','Staff List')

{{-- vendor styles --}}
@section('vendor-style')
<link rel="stylesheet" type="text/css" href="{{asset('fonts/fontawesome/css/all.min.css')}}">

@endsection

{{-- page content --}}
@section('content')
<!--Gradient Card-->
<div id="cards-extended">
  <div class="card">
    <div class="card-content">
      <h4 class="card-title">{{ __('locale.Staff')}} {{ __('locale.List')}}</h4>
    </div>
  </div>
  <!--Social Card-->
  <div id="card-panel-type1" class="section">
    <div class="row">
	  <?php  $id = 1; ?>
      @foreach ($data['staffs'] as $staff)
      <div class="col s12 m6 l4 card-width">
		@if(fmod($id, 2) == 1)
        <div class="card card-border center-align gradient-45deg-indigo-purple">
		@else
		<div class="card card-border center-align gradient-45deg-purple-deep-orange">
		@endif
          <div class="card-content white-text">
            <img class="responsive-img circle z-depth-4" style="width:100px; height:100px;"src="{{asset('images/user/' . $staff['image'])}}" alt="" />
            <h5 class="white-text mb-1">{{$staff['firstname']}} {{$staff['lastname']}}</h5>
            <p class="m-0">{{$staff['rfc']}}</p>
			@if(fmod($id, 2) == 1)
            <a class="waves-effect waves-light btn gradient-45deg-deep-orange-orange border-round mt-7 z-depth-4" href="{{asset('staff-view/' . $staff['id'])}}">{{ __('locale.Details')}}</a>
			@else
			<a class="waves-effect waves-light btn gradient-45deg-green-teal border-round mt-7 z-depth-4" href="{{asset('staff-view/' . $staff['id'])}}">{{ __('locale.Details')}}</a>
			@endif
          </div>
        </div>
		<?php $id = $id + 1; ?>
      </div>
      @endforeach
    </div>
  </div>

</div>
@endsection

{{-- vendor scripts --}}
@section('vendor-script')
<script src="{{asset('fonts/fontawesome/js/all.min.js')}}"></script>
@endsection

{{-- page scripts --}}
@section('page-script')
<script src="{{asset('js/custom/custom-script.js')}}"></script>
@endsection