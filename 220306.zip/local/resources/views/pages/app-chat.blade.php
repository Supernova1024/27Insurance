{{-- layout extend --}}
@extends('layouts.contentLayoutMaster')

{{-- Page title --}}
@section('title','Chat')

{{-- page styles --}}
@section('page-style')
<link rel="stylesheet" type="text/css" href="{{asset('css/pages/app-chat.css')}}">
@endsection

{{-- main page content --}}
@section('content')
<div class="chat-application">
  <div class="chat-content-head">
    <div class="header-details">
      <h5 class="m-0 sidebar-title"><i class="material-icons app-header-icon text-top">mail_outline</i> Chat</h5>
    </div>
  </div>
  <div class="app-chat">
    <div class="content-area content-right">
      <div class="app-wrapper">
        <!-- Sidebar menu for small screen -->
        <a data-target="chat-sidenav" class="sidenav-trigger hide-on-large-only">
          <i class="material-icons">menu</i>
        </a>
        <!--/ Sidebar menu for small screen -->

        <div class="card card card-default scrollspy border-radius-6 fixed-width">
          <div class="card-content chat-content p-0">
            <!-- Sidebar Area -->
            <div class="sidebar-left sidebar-fixed animate fadeUp animation-fast">
              <div class="sidebar animate fadeUp">
                <div class="sidebar-content">
                  <div id="sidebar-list" class="sidebar-menu chat-sidebar list-group position-relative">
                    <div class="sidebar-list-padding app-sidebar sidenav" id="chat-sidenav">
                      <!-- Sidebar Header -->
                      <div class="sidebar-header">
                        <div class="row valign-wrapper">
                          <div class="col s2 media-image pr-0">
                            <img src="{{asset('images/user/'. $user->image)}}" alt="" class="circle z-depth-2 responsive-img">
                          </div>
                          <div class="col s10">
							<p class="user_id" id="{{ $user->id}}" style="display:none;"></p>
							<p class="user_img" id="{{ $user->image}}" style="display:none;"></p>
                            <p class="m-0 blue-grey-text text-darken-4 font-weight-700">{{ $user->firstname}} {{ $user->lastname}}</p>
                            <p class="m-0 info-text">{{ $user->role}}</p>
                          </div>
                        </div>
                      </div>
                      <!--/ Sidebar Header -->

                      <!-- Sidebar Search -->
                      <div class="sidebar-search animate fadeUp">
                        <div class="search-area">
                          <i class="material-icons search-icon">search</i>
                          <input type="text" placeholder="{{ __('locale.Search')}}" class="app-filter">
                        </div>
                      </div>
                      <!--/ Sidebar Search -->

                      <!-- Sidebar Content List -->
                      <div class="sidebar-content sidebar-chat">
                        <div class="chat-list" id="chat-list">
						  @foreach($data['staffs'] as $staff)
						  <div class="chat-user animate fadeUp delay" id={{ $staff['email'] }}>
                            <div class="user-section">
                              <div class="row valign-wrapper">
                                <div class="col s2 media-image online pr-0">
                                  <img src="{{asset('images/user/'. $staff['image'])}}" alt="" class="circle z-depth-2 responsive-img">
                                </div>
                                <div class="col s10">
                                  <p class="m-0 blue-grey-text text-darken-4 font-weight-700">{{ $staff['firstname']}} {{ $staff['lastname']}}</p>
								  @if(strlen($staff['message']) < 30)
                                  <p class="m-0 info-text">{{ $staff['message']}}</p>
								  @else
								  <p class="m-0 info-text">{{ substr($staff['message'], 0, 30);}}...</p>
								  @endif
                                </div>
                              </div>
                            </div>
                            <div class="info-section">
                              <div class="star-timing">
                                <div class="time">
								  @if($staff['count'] != 0)
								  <span id="count" class="badge badge pill red">{{ $staff['count']}}</span>
								  @endif
                                </div>
                              </div>
                              <!-- <span>2.38 pm</span> -->
                            </div>
                          </div>
					      @endforeach
                        </div>
                        <div class="no-data-found">
                          <h6 class="center">No Results Found</h6>
                        </div>
                      </div>
                      <!--/ Sidebar Content List -->
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!--/ Sidebar Area -->

            <!-- Content Area -->
            <div class="chat-content-area animate fadeUp">
              <!-- Chat header -->
              <div class="chat-header">
                <div class="row valign-wrapper" id="chat_header">
                  <div class="col media-image online pr-0">
                    <img src="{{asset('images/user/'. $data['client']['image'])}}" alt="" class="circle z-depth-2 responsive-img">
					<p id="img" style="display:none;">{{asset('images/user/'. $data['client']['image'])}}</p>
                  </div>
                  <div class="col">
                    <p class="m-0 blue-grey-text text-darken-4 font-weight-700">{{$data['client']['firstname']}} {{$data['client']['lastname']}}</p>
                    <p class="m-0 chat-text truncate">{{$data['client']['role']}}</p>
					<p id="to_user" style="display:none;">{{$data['client']['id']}}</p>
					<p id="to_email" style="display:none;">{{$data['client']['email']}}</p>
                  </div>
                </div>
              </div>
              <!--/ Chat header -->

              <!-- Chat content area -->
              <div class="chat-area">
                <div class="chats">
					<div class="chats" id="chat_content">
						@foreach($data['messages'] as $message)
						  @if($user->id != $message['recipient_id'])
							<div class="chat chat-right">
							  <div class="chat-avatar">
								<a class="avatar">
								  <img src="{{asset('images/user/'. $user->image)}}" class="circle" alt="avatar" />
								</a>
							  </div>
							  <div class="chat-body">
								<div class="chat-text">
								  @if($message['type'] != "Str")
									<div class="img-box grey lighten-4 border-radius-6">
										<div class="card-image">
											<img src="{{asset('local/storage/attached/'. $message['message'])}}" class="responsive-img" data-xblocker="passed">
										</div>
										<div class="card-content">
											<span class="left"> {{$message['message']}}</span>
											<a href="{{asset('download/'. $message['message'])}}" class="Right">
												<i class="material-icons">file_download</i>
											</a>
										</div>
									</div>
								   @else
								  	<p>{{$message['message']}}</p>
								   @endif
								</div>
							  </div>
							</div>
						  @else
							<div class="chat">
							  <div class="chat-avatar">
								<a class="avatar">
								  <img src="{{asset('images/user/'. $data['client']['image'])}}" class="circle" alt="avatar" />
								</a>
							  </div>
							  <div class="chat-body">
								<div class="chat-text">
									@if($message['type'] != "Str")
									<div class="img-box grey lighten-4 border-radius-6">
										<div class="card-image">
											<img src="{{asset('local/storage/attached/'. $message['message'])}}" class="responsive-img" data-xblocker="passed"> 
										</div>
										<div class="card-content">
											<span class="left"> {{$message['message']}}</span>
											<a href="{{asset('download/'. $message['message'])}}" class="Right">
												<i class="material-icons">file_download</i>
											</a>
										</div>
									</div>
								   @else
								  	<p>{{$message['message']}}</p>
								   @endif
								</div>
							  </div>
							</div>
						  @endif
					    @endforeach
					</div>
                </div>
              </div>
              <!--/ Chat content area -->

              <!-- Chat footer <-->
              <div class="chat-footer">
				<form id="chat_message" enctype="multipart/form-data">
				{{ csrf_field() }}
                <div class="chat-input">
				  <!--<i class="material-icons mr-2">face</i> -->
                  <i id="attach" class="material-icons mr-2">attachment</i>
				  <input type="text" id="to" name="to" value="{{$data['client']['id']}}" style="display:none">
				  <input type="file" id="attach" name="attach" style="display:none">
                  <input type="text" placeholder="Type message here.." class="message mb-0">
                  <a class="btn waves-effect waves-light send" id="submit">{{ __('locale.Send')}}</a>
                </div>
				</form>
              </div>
              <!--/ Chat footer -->
            </div>
            <!--/ Content Area -->
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
@endsection

{{-- page scripts --}}
@section('page-script')
<script src="{{asset('js/scripts/app-chat.js')}}"></script>
@endsection