{{-- layout --}}
@extends('layouts.contentLayoutMaster')

{{-- page title --}}
@section('title','Staff View')

{{-- vendor styles --}}
@section('vendor-style')
<link rel="stylesheet" type="text/css" href="{{asset('vendors/flag-icon/css/flag-icon.min.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('vendors/data-tables/css/jquery.dataTables.min.css')}}">
<link rel="stylesheet" type="text/css"
  href="{{asset('vendors/data-tables/extensions/responsive/css/responsive.dataTables.min.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('vendors/data-tables/css/select.dataTables.min.css')}}">
@endsection

{{-- page style --}}
@section('page-style')
<link rel="stylesheet" type="text/css" href="{{asset('css/pages/data-tables.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('css/pages/page-users.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('css/pages/app-sidebar.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('css/pages/app-email.css')}}">
@endsection

{{-- page content  --}}
@section('content')
<!-- users view start -->
<div class="section users-view">
  <!-- users view media object start -->
  <div class="card-panel">
    <div class="row">
      <div class="col s12 m12">
		<div class="display-flex media">
          <a class="avatar">
            <img src="{{asset('images/user/'. $data['staff']['image'])}}" alt="users view avatar" class="z-depth-4 circle"
              height="64" width="64">
          </a>
		  <div class="media-body">
            <h6 class="media-heading">
              <span class="users-view-name">{{ $data['staff']['firstname'] }} {{ $data['staff']['lastname'] }} {{$data['staff']['maternal_surname']}} {{$data['staff']['paternal_surname']}}</span>
            </h6>
            <span class="users-view-id">{{$data['staff']['email']}}</span>
          </div>
        </div>
      </div>
      <div class="col s12 m12 quick-action-btns display-flex justify-content-end align-items-center pt-2">
        <a class="btn-small btn-light-indigo compose-email-trigger"><i
            class="material-icons">mail_outline</i></a>
        <a href="{{asset('chat')}}" class="btn-small btn-light-indigo"><i 
		    class="material-icons">chat_bubble_outline</i></a>
        <a href="{{asset('staff-edit/' . $data['staff']['id'])}}" class="btn-small indigo">{{ __('locale.Edit')}}</a>
      </div>
    </div>
  </div>
  <!-- users view media object ends -->

  <!-- users view card details start -->
  <div class="card">
    <div class="card-content">
      <div class="row">
        <div class="col s12">
          <table class="striped">
            <tbody>
              <tr>
                <td>{{ __('locale.Department')}}:</td>
                <td>{{ $data['staff']['rfc'] }}</td>
              </tr>
              <tr>
                <td>{{ __('locale.Birthday')}}:</td>
                <td>{{ $data['staff']['birthday'] }}</td>
              </tr>
              <tr>
                <td>{{ __('locale.Address')}}:</td>
                <td>{{ $data['staff']['address'] }}</td>
              </tr>
              <tr>
                <td>{{ __('locale.Phone')}}:</td>
                <td>{{ $data['staff']['phone'] }}</td>
              </tr>
              <tr>
                <td>{{ __('locale.Telephone')}}:</td>
                <td>{{ $data['staff']['telephone'] }}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
  <!-- users view card details ends -->
	
</div>
@if($data['staff']['rfc'] == 'Sales Departament')
<div class="section section-data-tables">
  <div class="card">
	  <div class="card-content">
		  <div class="row">
			  <div class="col s12">
				  <table id="page-length-option" class="display">
					  <thead>
						  <tr>
							  <th>{{ __('locale.ID')}}</th>
							  <th>{{ __('locale.Start_date')}}</th>
							  <th>{{ __('locale.End_date')}}</th>
							  <th>{{ __('locale.Brand')}}</th>
							  <th>{{ __('locale.Year')}}</th>
							  <th>{{ __('locale.Package')}}</th>
							  <th>{{ __('locale.Payment')}}</th>
							  <th>IVA</th>
							  <th>Pneta</th>
							  <th>Ptotal</th>
							  <th>{{ __('locale.Description')}}</th>
							  <th>{{ __('locale.Serie')}}</th>
							  <th>{{ __('locale.Motor')}}</th>
							  <th>{{ __('locale.Plates')}}</th>
							  <th>{{ __('locale.Reference')}}</th>
							  <th>{{ __('locale.Email')}}</th>
							  <th>{{ __('locale.Client')}}</th>
							  <th>{{ __('locale.Status')}}</th>
							  <th>{{ __('locale.Edit')}}</th>
							  <th>PDF</th>
						  </tr>
					  </thead>
					  <tbody>
						  @foreach ($data['policies'] as $policy)
						  <tr>
							  <td>{{ $policy['cve'] }}{{ $policy['pol'] }}</td>
							  <td>{{ $policy['start_date'] }}</td>
							  @if($policy['status'] == 1)
							  @if($policy['end_date'] > date('Y-m-d'))
							  <td><span class="task-cat cyan">{{ $policy['end_date'] }}</span></td>
							  @else
							  <td><span class="task-cat deep-orange accent-2">{{ $policy['end_date'] }}</span></td>
							  @endif
							  @else
							  <td><span class="task-cat red accent-2">{{ $policy['cancel_date'] }}</span></td>
							  @endif
							  <td>{{ $policy['marca'] }}</td>
							  <td>{{ $policy['model'] }}</td>
							  @if($policy['paq'] == 1)
							  <td>{{ __('locale.Wide')}}</td>
							  @elseif($policy['paq'] == 2)
							  <td>{{ __('locale.Limited')}}</td>
							  @elseif($policy['paq'] == 3)
							  <td>{{ __('locale.RC')}}</td>
							  @else
							  <td>{{ __('locale.INTEGRAL')}}</td>
							  @endif
							  @if($policy['fp'] == 12)
							  <td>{{ __('locale.Annual')}}</td>
							  @elseif($policy['fp'] == 28)
							  <td>{{ __('locale.Semi-annual')}}</td>
							  @elseif($policy['fp'] == 29)
							  <td>{{ __('locale.Quarterly')}}</td>
							  @elseif($policy['fp'] == 27)
							  <td>{{ __('locale.Monthly')}}</td>
							  @else
							  <td>{{ __('locale.Biweekly')}}</td>
							  @endif
							  <td>$ {{ $policy['iva'] }} |MXN</td>
							  <td>$ {{ $policy['pneta'] }} |MXN</td>
							  <td>$ {{ $policy['ptotal'] }} |MXN</td>
							  <td>{{ $policy['description'] }}</td>
							  <td>{{ $policy['serie'] }}</td>
							  <td>{{ $policy['motor'] }}</td>
							  <td>{{ $policy['plates'] }}</td>
							  <td>{{ $policy['reference'] }}</td>
							  <td>{{ $policy['email'] }}</td>
							  <td>{{ $policy['firstname'] }} {{ $policy['lastname'] }} {{ $policy['paternal_surname'] }} {{ $policy['maternal_surname'] }}</td>
							  @if($policy['status'] == 1)
							  @if($policy['end_date'] > date('Y-m-d'))
							  <td><span class="task-cat cyan">{{ __('locale.Valid')}}</span></td>
							  @else
							  <td><span class="task-cat deep-orange accent-2">{{ __('locale.Expired')}}</span></td>
							  @endif
							  @else
							  <td><span class="task-cat red accent-2">{{ __('locale.Canceled')}}</span></td>
							  @endif
							  <td><a href="{{ route('policy-edit', $policy['id']) }}"><i class="material-icons">mode_edit</i></a></td>  
							  <td><a href="{{ route('policy-pdf', $policy['id']) }}" target="_blank"><i class="material-icons">picture_as_pdf</i></a></td>
						  </tr>
						  @endforeach
					  </tbody>
					  <tfoot>
						  <tr>
							  <th>{{ __('locale.ID')}}</th>
							  <th>{{ __('locale.Start_date')}}</th>
							  <th>{{ __('locale.End_date')}}</th>
							  <th>{{ __('locale.Brand')}}</th>
							  <th>{{ __('locale.Year')}}</th>
							  <th>{{ __('locale.Package')}}</th>
							  <th>{{ __('locale.Payment')}}</th>
							  <th>IVA</th>
							  <th>Pneta</th>
							  <th>Ptotal</th>
							  <th>{{ __('locale.Description')}}</th>
							  <th>{{ __('locale.Serie')}}</th>
							  <th>{{ __('locale.Motor')}}</th>
							  <th>{{ __('locale.Plates')}}</th>
							  <th>{{ __('locale.Reference')}}</th>
							  <th>{{ __('locale.Email')}}</th>
							  <th>{{ __('locale.Client')}}</th>
							  <th>{{ __('locale.Status')}}</th>
							  <th>{{ __('locale.Edit')}}</th>
							  <th>PDF</th>
						  </tr>
					  </tfoot>
				  </table>
			  </div>
		  </div>
	  </div>
	</div>
</div>
@endif
<!-- users view ends -->

<!-- email compose sidebar -->
<div class="email-compose-sidebar">
  <div class="card quill-wrapper">
    <div class="card-content pt-0">
      <div class="card-header display-flex pb-2">
        <h3 class="card-title">NEW MESSAGE</h3>
        <div class="close close-icon">
          <i class="material-icons">close</i>
        </div>
      </div>
      <div class="divider"></div>
      <!-- form start -->
      <form class="edit-email-item mt-10 mb-10">
        <div class="input-field">
          <input type="email" class="edit-email-item-title validate" id="edit-item-from" value="{{$user->email}}" disabled>
          <label for="edit-item-from">From</label>
        </div>
        <div class="input-field">
          <input type="email" class="edit-email-item-date" id="edit-item-to" value="{{ $data['staff']['email'] }}"  disabled>
          <label for="edit-item-to">To</label>
        </div>
        <div class="input-field">
          <input type="text" class="edit-email-item-date" id="edit-item-subject">
          <label for="edit-item-subject">Subject</label>
        </div>
        <div class="input-field">
          <input type="email" class="edit-email-item-date" id="edit-item-CC">
          <label for="edit-item-CC">CC</label>
        </div>
        <div class="input-field">
          <input type="email" class="edit-email-item-date" id="edit-item-BCC">
          <label for="edit-item-BCC">BCC</label>
        </div>
        <!-- Compose mail Quill editor -->
        <div class="input-field">
          <div class="snow-container mt-2">
            <div class="compose-editor"></div>
            <div class="compose-quill-toolbar">
            </div>
          </div>
        </div>
      </form>
      <div class="card-action pl-0 pr-0 right-align">
        <button type="reset" class="btn-small waves-effect waves-light cancel-email-item mr-1">
          <i class="material-icons left">close</i>
          <span>Cancel</span>
        </button>
        <button class="btn-small waves-effect waves-light send-email-item">
          <i class="material-icons left">send</i>
          <span>Send</span>
        </button>
      </div>
      <!-- form start end-->
    </div>
  </div>
</div>
@endsection

{{-- vendor scripts --}}
@section('vendor-script')
<script src="{{asset('vendors/data-tables/js/jquery.dataTables.min.js')}}"></script>
<script src="{{asset('vendors/data-tables/extensions/responsive/js/dataTables.responsive.min.js')}}"></script>
<script src="{{asset('vendors/data-tables/js/dataTables.select.min.js')}}"></script>
@endsection

{{-- page script --}}
@section('page-script')
<script src="{{asset('js/scripts/data-tables.js')}}"></script>
<script src="{{asset('vendors/sortable/jquery-sortable-min.js')}}"></script>
<script src="{{asset('vendors/quill/quill.min.js')}}"></script>
<script src="{{asset('js/scripts/app-email.js')}}"></script>
@endsection