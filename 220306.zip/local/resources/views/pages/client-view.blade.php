{{-- layout --}}
@extends('layouts.contentLayoutMaster')

{{-- page title --}}
@section('title','Client View')

{{-- page style --}}
@section('page-style')
<link rel="stylesheet" type="text/css" href="{{asset('css/pages/page-users.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('css/pages/app-sidebar.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('css/pages/app-email.css')}}">
@endsection

{{-- page content  --}}
@section('content')
<!-- users view start -->
<div class="section users-view">
  <!-- users view media object start -->
  <div class="card-panel">
    <div class="row">
      <div class="col s12 m12">
        <div class="display-flex media">
          <a class="avatar">
            <img src="{{asset('images/user/'. $data['client']['image'])}}" alt="users view avatar" class="z-depth-4 circle"
              height="64" width="64">
          </a>
		  <div class="media-body">
            <h6 class="media-heading">
              <span class="users-view-name">{{$data['client']['firstname']}} {{$data['client']['lastname']}} {{$data['client']['maternal_surname']}} {{$data['client']['paternal_surname']}}</span>
            </h6>
            <span class="users-view-id">{{$data['client']['email']}}</span>
          </div>
        </div>
      </div>
      <div class="col s12 m12 quick-action-btns display-flex justify-content-end align-items-center pt-2">
        <a class="btn-small btn-light-indigo compose-email-trigger"><i
            class="material-icons">mail_outline</i></a>
        <a href="{{asset('user-profile-page')}}" class="btn-small btn-light-indigo"><i 
		    class="material-icons">chat_bubble_outline</i></a>
        <a href="{{asset('client-edit/' . $data['client']['id'])}}" class="btn-small indigo">{{ __('locale.Edit')}}</a>
      </div>
	  <!-- <div class="col s12 m12" style="margin-top: 20px;">
		  <table class="striped">
            <tbody>
              <tr>
                <td>{{ __('locale.Birthday')}}:</td>
                <td>{{ $data['client']['birthday'] }}</td>
              </tr>
              <tr>
                <td>{{ __('locale.Address')}}:</td>
                <td>{{ $data['client']['address'] }}</td>
              </tr>
              <tr>
                <td>{{ __('locale.Phone')}}:</td>
                <td>{{ $data['client']['phone'] }}</td>
              </tr>
			  <tr>
                <td>{{ __('locale.Telephone')}}:</td>
                <td>{{ $data['client']['telephone'] }}</td>
              </tr>
            </tbody>
          </table>
	  </div> -->
    </div>
  </div>
  <!-- users view media object ends -->
	
  <!-- users view card data start -->
  <div class="card">
    <div class="card-content">
	  <div class="row indigo lighten-5 border-radius-4 mb-2">
        <div class="col s12 m6 users-view-timeline">
          <h6 class="indigo-text m-0">Quotation: <span>{{ $data['quotes']->count()}}</span></h6>
        </div>
        <div class="col s12 m6 users-view-timeline">
          <h6 class="indigo-text m-0">Policy: <span>{{ $data['policies']->count()}}</span></h6>
        </div>
      </div>
      <div class="row">
        <div class="col s12">
          <table class="responsive-table">
            <thead>
              <tr>
                <th>{{ __('locale.Policy')}} {{ __('locale.ID')}}</th>
                <th>{{ __('locale.Start_date')}}</th>
                <th>{{ __('locale.End_date')}}</th>
                <th>{{ __('locale.Brand')}}</th>
                <th>{{ __('locale.Year')}}</th>
                <th>{{ __('locale.Package')}}</th>
                <th>{{ __('locale.Payment')}}</th>
                <th>Ptotal</th>
                <th>{{ __('locale.Description')}}</th>
                <th>{{ __('locale.Status')}}</th>
                <th>{{ __('locale.Edit')}}</th>
                <th>PDF</th>
              </tr>
            </thead>
            <tbody>
			@foreach($data['policies'] as $policy)
              <tr>
                <td>{{$policy['cve']}}{{$policy['pol']}}</td>
                <td>{{$policy['start_date']}}</td>
                @if($policy['status'] == 1)
				  @if($policy['end_date'] > date('Y-m-d'))
				  <td><span class="task-cat cyan">{{ $policy['end_date'] }}</span></td>
				  @else
				  <td><span class="task-cat deep-orange accent-2">{{ $policy['end_date'] }}</span></td>
				  @endif
				  @else
				  <td><span class="task-cat red accent-2">{{ $policy['cancel_date'] }}</span></td>
				@endif
                <td>{{$policy['marca']}}</td>
                <td>{{$policy['model']}}</td>
                @if($policy['paq'] == 1)
				  <td>{{ __('locale.Wide')}}</td>
				  @elseif($policy['paq'] == 2)
				  <td>{{ __('locale.Limited')}}</td>
				  @elseif($policy['paq'] == 3)
				  <td>{{ __('locale.RC')}}</td>
				  @else
				  <td>{{ __('locale.INTEGRAL')}}</td>
				@endif
				@if($policy['fp'] == 12)
				  <td>{{ __('locale.Annual')}}</td>
				  @elseif($policy['fp'] == 28)
				  <td>{{ __('locale.Semi-annual')}}</td>
				  @elseif($policy['fp'] == 29)
				  <td>{{ __('locale.Quarterly')}}</td>
				  @elseif($policy['fp'] == 27)
				  <td>{{ __('locale.Monthly')}}</td>
				  @else
				  <td>{{ __('locale.Biweekly')}}</td>
				@endif
                <td>${{$policy['ptotal']}} |MXN</td>
                <td>{{$policy['description']}}</td>
				@if($policy['status'] == 1)
				  @if($policy['end_date'] > date('Y-m-d'))
				  <td><span class="task-cat cyan">{{ __('locale.Valid')}}</span></td>
				  @else
				  <td><span class="task-cat deep-orange accent-2">{{ __('locale.Expired')}}</span></td>
				  @endif
				  @else
				  <td><span class="task-cat red accent-2">{{ __('locale.Canceled')}}</span></td>
				@endif
				<td><a href="{{ route('policy-edit', $policy['id']) }}"><i class="material-icons">mode_edit</i></a></td>  
				<td><a href="{{ route('policy-pdf', $policy['id']) }}" target="_blank"><i class="material-icons">picture_as_pdf</i></a></td>
              </tr>
			@endforeach
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
  <!-- users view card data ends -->

</div>
<!-- users view ends -->
<!-- email compose sidebar -->
<div class="email-compose-sidebar">
  <div class="card quill-wrapper">
    <div class="card-content pt-0">
      <div class="card-header display-flex pb-2">
        <h3 class="card-title"><i class="material-icons app-header-icon text-top">mail_outline</i></h3>
        <div class="close close-icon">
          <i class="material-icons">close</i>
        </div>
      </div>
      <div class="divider"></div>
      <!-- form start -->
      <form class="edit-email-item mt-10 mb-10">
        <div class="input-field">
          <input type="email" id="edit-item-from" value="{{$user->email}}" disabled>
          <label for="edit-item-from">From</label>
        </div>
        <div class="input-field">
          <input type="email" id="edit-item-to" value="{{$data['client']['email']}}" disabled>
          <label for="edit-item-to">To</label>
        </div>
        <div class="input-field">
          <input type="text" class="edit-email-item-date" id="edit-item-subject">
          <label for="edit-item-subject">Subject</label>
        </div>
        <div class="input-field">
          <input type="email" class="edit-email-item-date" id="edit-item-CC">
          <label for="edit-item-CC">CC</label>
        </div>
        <div class="input-field">
          <input type="email" class="edit-email-item-date" id="edit-item-BCC">
          <label for="edit-item-BCC">BCC</label>
        </div>
        <!-- Compose mail Quill editor -->
        <div class="input-field" style="display:none;">
          <div class="snow-container mt-2">
            <div class="compose-editor"></div>
            <div class="compose-quill-toolbar">
            </div>
          </div>
        </div>
		<div class="input-field">
			<i class="material-icons prefix">mode_edit</i>
			<textarea id="forward_message" class="materialize-textarea" style="height: 62px;"></textarea>
			<label for="forward_message" class="active">Message</label>
		</div>
      </form>
      <div class="card-action pl-0 pr-0 right-align">
        <button type="reset" class="btn-small waves-effect waves-light cancel-email-item mr-1">
          <i class="material-icons left">close</i>
          <span>Cancel</span>
        </button>
        <button class="btn-small waves-effect waves-light send-email-item">
          <i class="material-icons left">send</i>
          <span>Send</span>
        </button>
      </div>
      <!-- form start end-->
    </div>
  </div>
</div>
@endsection

{{-- page script --}}
@section('page-script')
<script src="{{asset('vendors/sortable/jquery-sortable-min.js')}}"></script>
<script src="{{asset('vendors/quill/quill.min.js')}}"></script>
<script src="{{asset('js/scripts/app-email.js')}}"></script>
@endsection