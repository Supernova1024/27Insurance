{{-- layout --}}
@extends('layouts.contentLayoutMaster')

{{-- page title --}}
@section('title','Clients List')

{{-- vendors styles --}}
@section('vendor-style')
<link rel="stylesheet" type="text/css" href="{{asset('vendors/data-tables/css/jquery.dataTables.min.css')}}">
<link rel="stylesheet" type="text/css"
  href="{{asset('vendors/data-tables/extensions/responsive/css/responsive.dataTables.min.css')}}">
@endsection

{{-- page styles --}}
@section('page-style')
<link rel="stylesheet" type="text/css" href="{{asset('css/pages/data-tables.css')}}">
@endsection

{{-- page content --}}
@section('content')
<!-- users list start -->
<div class="section section-data-tables">
	<!-- Page Length Options -->
	<div class="row">
		<div class="col s12">
			<div class="card">
				<div class="card-content">
					<div class="row">
						<div class="col s12">
							<table id="page-length-option" class="display">
								<thead>
									<tr>
										<th>{{ __('locale.Client')}}</th>
										<th>{{ __('locale.Full_name')}}</th>
										<th>{{ __('locale.Address')}}</th>
										<th>{{ __('locale.Phone')}}</th>
										<th>{{ __('locale.Telephone')}}</th>
										<th>{{ __('locale.Status')}}</th>
										<th>{{ __('locale.Email')}}</th>
										<th>{{ __('locale.Edit')}}</th>
										<th>{{ __('locale.View')}}</th>
									</tr>
								</thead>
								<tbody>
									@foreach ($data['clients'] as $client)
									<tr>
										<td>
											<img src="{{ asset('images/user/' . $client['image']) }}" class="circle z-depth-2 responsive-img" width="40" height="40">
										</td>
										<td><a href="{{ route('client-view', $client['id']) }}">
											<span class="green-text">{{ $client['firstname'] }} {{ $client['lastname'] }} {{ $client['paternal_surname'] }} {{ $client['maternal_surname'] }}</span></a>
										</td>
										<td>{{ $client['address'] }}</td>
										<td>{{ $client['phone'] }}</td>
										<td>{{ $client['telephone'] }}</td>
										<td><span class="chip green lighten-5">
											<span class="green-text">Active</span>
											</span>
										</td>
										<td>{{ $client['email'] }}</td>
										<td><a href="{{ route('client-edit', $client['id']) }}"><i class="material-icons">edit</i></a></td>
										<td><a href="{{ route('client-view', $client['id']) }}"><i class="material-icons">remove_red_eye</i></a></td>
									</tr>
									@endforeach
								</tbody>
								<tfoot>
									<tr>
										<th>{{ __('locale.Client')}}</th>
										<th>{{ __('locale.Full_name')}}</th>
										<th>{{ __('locale.Address')}}</th>
										<th>{{ __('locale.Phone')}}</th>
										<th>{{ __('locale.Telephone')}}</th>
										<th>{{ __('locale.Status')}}</th>
										<th>{{ __('locale.Email')}}</th>
										<th>{{ __('locale.Edit')}}</th>
										<th>{{ __('locale.View')}}</th>
									</tr>
								</tfoot>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- users list ends -->
@endsection

{{-- vendor scripts --}}
@section('vendor-script')
<script src="{{asset('vendors/data-tables/js/jquery.dataTables.min.js')}}"></script>
<script src="{{asset('vendors/data-tables/extensions/responsive/js/dataTables.responsive.min.js')}}"></script>
<script src="{{asset('vendors/data-tables/js/dataTables.select.min.js')}}"></script>
@endsection

{{-- page script --}}
@section('page-script')
<script src="{{asset('js/scripts/data-tables.js')}}"></script>
@endsection