{{-- extend layout --}}
@extends('layouts.contentLayoutMaster')

{{-- page title --}}
@section('title','CSV Import')

{{-- vendor styles --}}
@section('vendor-style')
<link rel="stylesheet" type="text/css" href="{{asset('vendors/flag-icon/css/flag-icon.min.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('vendors/dropify/css/dropify.min.css')}}">
@endsection

{{-- page content --}}
@section('content')
<div class="section">
  <div class="card" id="comment">
    <div class="card-content">
	  <p class="caption">{{ __('locale.Note0')}}</p>
      <p class="caption">- {{ __('locale.Note1')}}</p>
	  <p class="caption">- {{ __('locale.Note2')}}</p>
    </div>
  </div>
  @if(session('success'))
  <div class="card-alert card green lighten-5">
	  <div class="card-content green-text">
		  <p>{{ __('locale.Success')}}</p>
	  </div>
	  <button type="button" class="close green-text" data-dismiss="alert" aria-label="Close">
		  <span aria-hidden="true">×</span>
	  </button>
	</div>
  @endif
  @if(session('error'))
  <div class="card-alert card red lighten-5">
	  <div class="card-content red-text">
		  <p>{{ __('locale.Error')}}</p>
	  </div>
	  <button type="button" class="close red-text" data-dismiss="alert" aria-label="Close">
		  <span aria-hidden="true">×</span>
	  </button>
	</div>
  @endif
  @if(session('size-error'))
  <div class="card-alert card orange lighten-5">
	  <div class="card-content orange-text">
		  <p>{{ __('locale.Size_error')}}</p>
	  </div>
	  <button type="button" class="close oragne-text" data-dismiss="alert" aria-label="Close">
		  <span aria-hidden="true">×</span>
	  </button>
	</div>
  @endif
  @if(session('type-error'))
  <div class="card-alert card orange lighten-5">
	  <div class="card-content orange-text">
		  <p>{{ __('locale.Type_error')}}</p>
	  </div>
	  <button type="button" class="close orange-text" data-dismiss="alert" aria-label="Close">
		  <span aria-hidden="true">×</span>
	  </button>
	</div>
  @endif
  <!--file-upload-->
  <div id="file-upload" class="section">
	<div class="row" id="preloader" style="display:none;">
		<div class="col s12">
		  <div id="indeterminate-linear" class="card card-tabs">
			<div class="card-content">
			  <div class="card-title">
				<div class="row">
				  <p class="card-title">Uploading...</p>
				</div>
			  </div>
			  <div id="view-indeterminate-linear">
				<div class="row">
				  <div class="col s12">
					<div class="progress">
					  <div class="indeterminate"></div>
					</div>
				  </div>
				</div>
			  </div>
			</div>
		  </div>
		</div>
	</div>
    <!--Max file size-->
    <div class="row section">
	<form action="{{ route('import') }}" enctype="multipart/form-data" method="POST">
	  {{ csrf_field() }}
      <div class="col s12 m12 l12">
        <input type="file" id="input-file-max-fs" class="dropify" data-max-file-size="4M" name="csv"/>
      </div>
	  <div class="col mt-2 md-2">
		<button class="btn mb-1 waves-effect waves-light mr-1 center" id="submit" type="submit">{{ __('locale.Import')}}</button>
	  </div>
	</form>
    </div>	
  </div>
</div>
@endsection

{{-- vendor script --}}
@section('vendor-script')
<script src="{{asset('vendors/dropify/js/dropify.min.js')}}"></script>
@endsection

{{-- page script --}}
@section('page-script')
<script src="{{asset('js/scripts/form-file-uploads.js')}}"></script>
@endsection