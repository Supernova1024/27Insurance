{{-- layout --}}
@extends('layouts.contentLayoutMaster')

{{-- page title --}}
@section('title','Quotation List')

{{-- vendor styles --}}
@section('vendor-style')
<link rel="stylesheet" type="text/css" href="{{asset('vendors/flag-icon/css/flag-icon.min.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('vendors/data-tables/css/jquery.dataTables.min.css')}}">
<link rel="stylesheet" type="text/css"
  href="{{asset('vendors/data-tables/extensions/responsive/css/responsive.dataTables.min.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('vendors/data-tables/css/select.dataTables.min.css')}}">
@endsection

{{-- page style --}}
@section('page-style')
<link rel="stylesheet" type="text/css" href="{{asset('css/pages/data-tables.css')}}">
@endsection

{{-- page content --}}
@section('content')
<div class="section section-data-tables">
  
  <!-- Page Length Options -->
  <div class="row">
    <div class="col s12">
      <div class="card">
        <div class="card-content">
          <div class="row">
            <div class="col s12">
              <table id="page-length-option" class="display">
                <thead>
                  <tr>
                    <th>{{ __('locale.Start_date')}}</th>
                    <th>{{ __('locale.ID')}}</th>
                    <th>{{ __('locale.Brand')}}</th>
                    <th>{{ __('locale.Year')}}</th>
                    <th>{{ __('locale.Package')}}</th>
                    <th>{{ __('locale.Payment')}}</th>
                    <th>Ptotal</th>
                    <th>{{ __('locale.Description')}}</th>
					@if($user->role != 'client')
                    <th>{{ __('locale.Full_name')}}</th>
                    <th>{{ __('locale.Email')}}</th>
                    <th>{{ __('locale.Edit')}}</th>
                    <th>{{ __('locale.Issuing')}}</th>
					@endif
                    <th>PDF</th>
                  </tr>
                </thead>
                <tbody id="quot-list">
				  @foreach ($data['quotes'] as $quot)
					<tr>
						<td>{{ $quot['start_date'] }}</td>
						<td>{{ $quot['cot_id'] }}</td>
						<td>{{ $quot['marca'] }}</td>
						<td>{{ $quot['model'] }}</td>
						@if($quot['paq'] == 1)
						<td>{{ __('locale.Wide')}}</td>
						@elseif($quot['paq'] == 2)
						<td>{{ __('locale.Limited')}}</td>
						@elseif($quot['paq'] == 3)
						<td>{{ __('locale.RC')}}</td>
						@else
						<td>{{ __('locale.INTEGRAL')}}</td>
						@endif
						@if($quot['fp'] == 12)
						<td>{{ __('locale.Annual')}}</td>
						@elseif($quot['fp'] == 28)
						<td>{{ __('locale.Semi-annual')}}</td>
						@elseif($quot['fp'] == 29)
						<td>{{ __('locale.Quarterly')}}</td>
						@elseif($quot['fp'] == 27)
						<td>{{ __('locale.Monthly')}}</td>
						@else
						<td>{{ __('locale.Biweekly')}}</td>
						@endif
						<td>$ {{ $quot['ptotal'] }} |MXN</td>
						<td>{{ $quot['description'] }}</td>
						@if($user->role != 'client')
						<td><span class="green-text">{{ $quot['firstname'] }} {{ $quot['lastname'] }} {{ $quot['paternal_surname'] }} {{ $quot['maternal_surname'] }}</span></td>
						<td><a href="{{ route('client-view', $quot['user_id']) }}">{{ $quot['email'] }}</a></td>
						<td>
							@if($quot['condition'] == 0)
							<a href="{{ route('quot-edit', $quot['id']) }}"><i class="material-icons">mode_edit</i></a>
							@else
							<i class="material-icons">not_interested</i>
							@endif
						</td>
						<td>
							@if($quot['condition'] == 1)
							<span class="badge green lighten-5 green-text text-accent-4">{{ __('locale.Issued')}}</span>
							@else
							<a href="{{ route('policy-new', $quot['id']) }}"><i class="material-icons">note_add</i></a>
							@endif
						</td>
						@endif
						<td><a href="{{ route('quot-pdf', $quot['id']) }}" target="_blank"><i class="material-icons">picture_as_pdf</i></a></td>
					</tr>
				  @endforeach
                </tbody>
                <tfoot>
                  <tr>
                    <th>{{ __('locale.Start_date')}}</th>
                    <th>{{ __('locale.ID')}}</th>
                    <th>{{ __('locale.Brand')}}</th>
                    <th>{{ __('locale.Year')}}</th>
                    <th>{{ __('locale.Package')}}</th>
                    <th>{{ __('locale.Payment')}}</th>
                    <th>Ptotal</th>
                    <th>{{ __('locale.Description')}}</th>
					@if($user->role != 'client')
                    <th>{{ __('locale.Full_name')}}</th>
                    <th>{{ __('locale.Email')}}</th>
                    <th>{{ __('locale.Edit')}}</th>
                    <th>{{ __('locale.Issuing')}}</th>
					@endif
                    <th>PDF</th>
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
@endsection

{{-- vendor scripts --}}
@section('vendor-script')
<script src="{{asset('vendors/data-tables/js/jquery.dataTables.min.js')}}"></script>
<script src="{{asset('vendors/data-tables/extensions/responsive/js/dataTables.responsive.min.js')}}"></script>
<script src="{{asset('vendors/data-tables/js/dataTables.select.min.js')}}"></script>
@endsection

{{-- page script --}}
@section('page-script')
<script src="{{asset('js/scripts/data-tables.js')}}"></script>
@endsection