{{-- layout extend --}}
@extends('layouts.contentLayoutMaster')

{{-- page title --}}
@section('title','App Email')

{{-- vendor styles --}}
@section('vendor-style')
<link rel="stylesheet" type="text/css" href="{{asset('vendors/quill/quill.snow.css')}}">
@endsection

{{-- page styles --}}
@section('page-style')
<link rel="stylesheet" type="text/css" href="{{asset('css/pages/app-sidebar.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('css/pages/app-email-content.css')}}">
@endsection

{{-- main page content --}}
@section('content')
<!-- Sidebar Area Starts -->
<div class="sidebar-left sidebar-fixed">
  <div class="sidebar">
    <div class="sidebar-content">
      <div class="sidebar-header">
        <div class="sidebar-details">
          <h5 class="m-0 sidebar-title"><i class="material-icons app-header-icon text-top">mail_outline</i>{{ __('locale.Inbox')}} </h5>
          <div class="row valign-wrapper mt-10 pt-2">
            <div class="col s3 media-image">
              <img src="{{asset('images/user/'. $user->image)}}" alt="" class="circle z-depth-2 responsive-img">
              <!-- notice the "circle" class -->
            </div>
            <div class="col s9">
              <p class="m-0 subtitle font-weight-700">{{ $user->firstname}} {{ $user->lastname}}</p>
              <p class="m-0 text-muted">{{ $user->email}}</p>
            </div>
          </div>
        </div>
      </div>
      <div id="sidebar-list" class="sidebar-menu list-group position-relative">
        <!-- Side var removed -->
      </div>
      <a href="#" data-target="email-sidenav" class="sidenav-trigger hide-on-large-only"><i
          class="material-icons">menu</i></a>
    </div>
  </div>
</div>
<!-- Sidebar Area Ends -->
<!-- Content Area Starts -->
<div class="app-email-content">
  <div class="content-area content-right">
    <div class="app-wrapper">
      <div class="app-search">
        <i class="material-icons mr-2 search-icon">search</i>
        <input type="text" placeholder="Search Mail" class="app-filter" id="email_filter">
      </div>
      <div class="card card-default scrollspy border-radius-6 fixed-width">
        <div class="card-content pt-0">
          <div class="row">
            <div class="col s12">
              <!-- Email Header -->
              <div class="email-header">
                <div class="subject">
                  <div class="back-to-mails">
                    <a href="{{asset('app-email')}}"><i class="material-icons">arrow_back</i></a>
                  </div>
          		@if(isset($data['mesag_data']['subject']))
                  <div class="email-title">{{ $data['mesag_data']['subject']}}</div>
          		@else
                  <div class="email-title">{{ __('locale.Subject')}}</div>
          		@endif
                </div>
              </div>
              <!-- Email Header Ends -->
              <hr>
              <!-- Email Content -->
              <div class="email-content">
                <div class="list-title-area">
                  <div class="user-media">
                    <img src="{{asset('images/user/' . $data['mesag_data']['user_img'])}}" alt="" class="circle z-depth-2 responsive-img avtar">
                    <div class="list-title">
            <p id="from" style="display: none;">{{ $data['mesag_data']['who']}}</p>
                      <span class="name">{{ $data['mesag_data']['user_name']}} ({{ $data['mesag_data']['who']}})</span>
                    </div>
                  </div>
                  <div class="title-left">
                    <span class="mail-time">{{ $data['mesag_data']['received_date']}}</span>
                  </div>
                </div>
                <div class="email-desc">
                  @php echo $data['mesag_data']['body']; @endphp
                </div>
              </div>
              <!-- Email Content Ends -->
              @if($data['folder'] == "inbox")
              <hr>
              <!-- Email Footer -->
              <div class="email-footer">
                <div class="footer-action">
                  
                  <div class="footer-buttons">
                    <a class="btn reply mb-1"><i class="material-icons left">reply</i><span>{{ __('locale.Reply')}}</span></a>
                    <a class="btn forward mb-1"><i class="material-icons left">reply</i><span>{{ __('locale.Forward')}}</span></a>
                  </div>
                </div>
                <div class="reply-box d-none">
                  <form>
                    <div class="input-field col s12" style="display: none;">
                      <div class="snow-container mt-2">
                        <div class="compose-editor"></div>
                        <div class="compose-quill-toolbar">
                          <span class="ql-formats mr-0">
                            <button class="ql-bold"></button>
                            <button class="ql-italic"></button>
                            <button class="ql-underline"></button>
                            <button class="ql-link"></button>
                            <button class="ql-image"></button>
                          </span>
                        </div>
                      </div>
                    </div>
                    <div class="input-field col s12">
                      <i class="material-icons prefix">mode_edit</i>
                      <textarea id="reply_message" class="materialize-textarea" style="height: 62px;"></textarea>
                      <label for="reply_message" class="active">{{ __('locale.Message')}}</label>
                    </div>
                    <div class="input-field col s12">
                      <a class="btn reply-btn right">{{ __('locale.Reply')}}</a>
                    </div>
                  </form>
                </div>
                <div class="forward-box d-none">
                  <hr>
                  <form>
                    <div class="input-field col s12">
                      <i class="material-icons prefix"> person_outline </i>
                      <input id="email" type="email" class="validate">
                      <label for="email">{{ __('locale.To')}}</label>
                    </div>
                    <div class="input-field col s12">
                      <i class="material-icons prefix">{{ __('locale.Title')}}</i>
                      <input id="subject" type="text" class="validate">
                      <label for="subject">{{ __('locale.Subject')}}</label>
                    </div>
                    <div class="input-field col s12" style="display: none;">
                      <div class="snow-container mt-2">
                        <div class="forward-email"></div>
                        <div class="forward-email-toolbar">
                          <span class="ql-formats mr-0">
                            <button class="ql-bold"></button>
                            <button class="ql-italic"></button>
                            <button class="ql-underline"></button>
                            <button class="ql-link"></button>
                            <button class="ql-image"></button>
                          </span>
                        </div>
                      </div>
                    </div>
                    <div class="input-field col s12">
                      <i class="material-icons prefix">mode_edit</i>
                      <textarea id="forward_message" class="materialize-textarea" style="height: 62px;"></textarea>
                      <label for="forward_message" class="active">{{ __('locale.Message')}}</label>
                    </div>
                    <div class="input-field col s12">
                      <a class="btn forward-btn right">Forward</a>
                    </div>
                  </form>
                </div>
                <div class="card-alert card green lighten-5" id="success" style="display: none;">
                    <div class="card-content green-text">
                      <p>SUCCESS : Message sent.</p>
                    </div>
                    <button type="button" class="close green-text" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="card-alert card orange lighten-5" id="warning" style="display: none;">
                    <div class="card-content orange-text">
                      <p>WARNING : Message was wrong</p>
                    </div>
                    <button type="button" class="close orange-text" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">×</span>
                    </button>
                </div>  
              </div>
              <!-- Email Footer Ends -->
              @endif
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Content Area Ends -->
@endsection

{{-- vendor scripts --}}
@section('vendor-script')
<script src="{{asset('vendors/quill/quill.min.js')}}"></script>
@endsection

{{-- page scripts --}}
@section('page-script')
<script src="{{asset('js/scripts/app-email-content.js')}}"></script>
@endsection