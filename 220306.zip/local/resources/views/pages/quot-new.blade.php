@extends('layouts.contentLayoutMaster')

{{-- page title --}}
@section('title','New Quotation')

{{-- vendor style --}}
@section('vendor-style')
<link rel="stylesheet" type="text/css" href="{{asset('vendors/flag-icon/css/flag-icon.min.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('vendors/materialize-stepper/materialize-stepper.min.css')}}">
@endsection
{{-- page style --}}
@section('page-style')
<link rel="stylesheet" type="text/css" href="{{asset('css/pages/form-wizard.css')}}">
@endsection

{{-- page content --}}
@section('content')
<div class="section section-form-wizard">
  <!-- Horizontal Stepper -->
  <div class="row">
    <div class="col s12">
      <div class="card">
        <div class="card-content pb-0">
          <ul class="stepper horizontal" id="horizStepper">
            <li class="step active">
              <div class="step-title waves-effect">{{ __('locale.Step')}} 1</div>
			  <div class="step-content" id="preloader" style="display: none;">
				  <div style="height: 50px;"></div>
				  <div class="row center">
					<div id="view-simple-circular">
					  <div class="preloader-wrapper active">
						  <div class="spinner-layer spinner-blue-only">
							  <div class="circle-clipper left">
								  <div class="circle"></div>
							  </div>
							  <div class="gap-patch">
								  <div class="circle"></div>
							  </div>
							  <div class="circle-clipper right">
								  <div class="circle"></div>
							  </div>
						  </div>
					  </div>
					</div>
				  </div>
				  <div style="height: 50px;"></div>
			  </div>
              <div class="step-content" id="step">
                <div class="row">
                  <div class="input-field col m6 s12">
					<p>{{ __('locale.Brand')}}</p>
                    <a id="brand" class="btn waves-effect waves-light cyan modal-trigger" href="#modal1" style="width:100%">{{ __('locale.Select')}}</a>
                  </div>
				  <div class="input-field col m6 s12">
                    <p>{{ __('locale.Sub_brand')}}</p>
                    <a id="subBrand" class="btn waves-effect waves-light cyan modal-trigger" href="#modal2" style="width:100%">{{ __('locale.Select')}}</a>
                  </div>
                </div>
                <div class="row">
			      <div class="input-field col m6 s12">
                    <p>{{ __('locale.Year')}}</p>
                    <a id="year" class="btn waves-effect waves-light cyan modal-trigger" href="#modal3" style="width:100%">{{ __('locale.Select')}}</a>
                  </div>
                  <div class="input-field col m6 s12">
                    <p>{{ __('locale.Model')}}</p>
                    <a id="model" class="btn waves-effect waves-light cyan modal-trigger" href="#modal4" style="width:100%">{{ __('locale.Select')}}</a>
                  </div>
                </div>
				<div class="row">
					<p id="brand_alert" style="display: none;">{{ __('locale.Quot_alert')}}</p>
				  <div class="input-field col m3 s6" id="manual" style="display: none;">
                    <label>
						<input id="manual" class="with-gap" name="group1" type="radio"/>
						<span>{{ __('locale.Manual')}}</span>
					</label>
                  </div>
				  <div class="input-field col m3 s6" id="automatic" style="display: none;">
					<label>
						<input id="automatic" class="with-gap" name="group1" type="radio"/>
						<span>{{ __('locale.Automatic')}}</span>
					</label>
                  </div>
                </div>
				<div class="step-actions">
					<div class="row">
						<div class="col m4 s12 mb-3">
							<a class="red btn btn-reset" href="{{ asset('quot-create')}}" disabled>
								<i class="material-icons left">clear</i>{{ __('locale.Reset')}}
							</a>
						</div>
						<div class="col m4 s12 mb-3">
							<button class="btn btn-light previous-step" disabled>
								<i class="material-icons left">arrow_back</i>
								{{ __('locale.Prev')}}
							</button>
						</div>
						<div class="col m4 s12 mb-3">
							<button id="next1" class="waves-effect waves dark btn btn-primary next-step" disabled>
								{{ __('locale.Next')}}
								<i class="material-icons right">arrow_forward</i>
							</button>
						</div>
					</div>
				  </div>
              </div>
            </li>
			<li class="step">
              <div class="step-title waves-effect">{{ __('locale.Step')}} 2</div>
				<div class="step-content" id="step">
					<div class="row">
						<div id="dec" class="input-field col s12" style="text-align:center;">
						</div>
						<div id="aba" class="input-field col l6">
							<p id="{{ asset('images/logo/aba.png')}}"></p>
						</div>
						<div id="qualitas" class="input-field col l6">
							<p id="{{ asset('images/logo/qualitas.png')}}"></p>
						</div>
					</div>
					<div class="step-actions">
						<div class="row">
							<div class="col m4 s12 mb-3">
								<a class="red btn btn-reset" href="{{ asset('quot-create')}}">
									<i class="material-icons left">clear</i>{{ __('locale.Reset')}}
								</a>
							</div>
							<div class="col m4 s12 mb-3">
								<button class="btn btn-light previous-step">
									<i class="material-icons left">arrow_back</i>
									{{ __('locale.Prev')}}
								</button>
							</div>
							<div class="col m4 s12 mb-3">
								<button id="next2" class="waves-effect waves dark btn btn-primary next-step" disabled>
									{{ __('locale.Next')}}
									<i class="material-icons right">arrow_forward</i>
								</button>
							</div>
						</div>
					</div>
				</div>
            </li>
            <li class="step">
              <div class="step-title waves-effect">{{ __('locale.Step')}} 3</div>
              <div class="step-content" id="step">
                <div class="row">
                  <div class="input-field col l3 m6 s12">
                    <label for="firstName">{{ __('locale.Firstname')}}: <span class="red-text">*</span></label>
                    <input type="text" id="firstName" class="validate" required value="{{ $user->firstname}}">
                  </div>
                  <div class="input-field col l3 m6 s12">
                    <label for="lastName">{{ __('locale.Lastname')}}: <span class="red-text">*</span></label>
                    <input type="text" id="lastName" class="validate" required value="{{ $user->lastname}}">
                  </div>
				  <div class="input-field col l3 m6 s12">
                    <label for="paternalName">{{ __('locale.Paternal')}}: <span class="red-text">*</span></label>
                    <input type="text" id="paternalName" class="validate" required value="{{ $user->paternal_surname}}">
                  </div>
                  <div class="input-field col l3 m6 s12">
                    <label for="maternalName">{{ __('locale.Maternal')}}: <span class="red-text">*</span></label>
                    <input type="text" id="maternalName" class="validate" value="{{ $user->maternal_surname}}">
                  </div>
                </div>
				<div class="row">
                  <div class="input-field col m4 s12">
                    <label for="datepicker">{{ __('locale.Birthday')}}:<span class="red-text">*</span></label>
                    <input type="text" id="datepicker" required value="{{ $user->birthday}}">
                  </div>
                  <div class="input-field col m4 s12">
                    <label for="mail">{{ __('locale.Email')}}: <span class="red-text">*</span></label>
                    <input type="email" class="validate" id="mail" required value="{{ $user->email}}">
                  </div>
				  <div class="input-field col m4 s12">
                    <label for="cp">{{ __('locale.CP')}}: <span class="red-text">*</span></label>
                    <input type="text" id="cp" class="validate" required value="{{ $user->postal_code}}">
                  </div>
                </div>
				<p id="checkbox"> 
					<label>
					<input type="checkbox">
					<span>{{ __('locale.Check1')}} <a href="#modal5" class="modal-trigger">{{ __('locale.Check2')}} </a>{{ __('locale.Check3')}} <a href="https://segurosacv.com/aviso-de-privacidad" target="_blank">{{ __('locale.Check4')}}</a></span>
					</label>
				</p>
                <div class="step-actions">
                  <div class="row">
                    <div class="col m4 s12 mb-3">
                      <a class="red btn btn-reset" href="{{ asset('quot-create')}}">
                        <i class="material-icons left">clear</i>{{ __('locale.Reset')}}
                      </a>
                    </div>
                    <div class="col m4 s12 mb-3">
                      <button class="btn btn-light previous-step">
                        <i class="material-icons left">arrow_back</i>
                        {{ __('locale.Prev')}}
                      </button>
                    </div>
                    <div class="col m4 s12 mb-3">
                      <button id="next3" class="waves-effect waves dark btn btn-primary next-step" disabled>
                        {{ __('locale.Next')}}
                        <i class="material-icons right">arrow_forward</i>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </li>
            <li class="step">
              <div class="step-title waves-effect">{{ __('locale.Step')}} 4</div>
			  <div class="step-content" id="preloader" style="display: none;">
				  <div style="height: 50px;"></div>
				  <div class="row center">
					<div id="view-simple-circular">
					  <div class="preloader-wrapper active">
						  <div class="spinner-layer spinner-blue-only">
							  <div class="circle-clipper left">
								  <div class="circle"></div>
							  </div>
							  <div class="gap-patch">
								  <div class="circle"></div>
							  </div>
							  <div class="circle-clipper right">
								  <div class="circle"></div>
							  </div>
						  </div>
					  </div>
					</div>
				  </div>
				  <div style="height: 50px;"></div>
			  </div>
              <div class="step-content" id="step">
                <div class="row">
				  <div id="detail_dec" class="input-field col s12" style="text-align:center;">
				  </div>
                  <div class="input-field col m2 s8">
					<select id="DES" {!! $user->role == 'client' ? 'disabled' : '' !!}>
					  @for($x = 0; $x <= 30; $x++)
					  @if($x == 30)
                      <option value="{{$x}}" selected>{{$x}}</option>
					  @else
                      <option value="{{$x}}">{{$x}}</option>
					  @endif
					  @endfor
                    </select>
                    <label for="DES">{{ __('locale.DES')}}(%)</label>
                  </div>
                  <div class="input-field col m2 s4">
                    <select id="plane">
                      <option value="3">{{ __('locale.RC')}}</option>
                      <option value="2">{{ __('locale.Limited')}}</option>
                      <option value="1" selected>{{ __('locale.Wide')}}</option>
					  <option value="460">{{ __('locale.INTEGRAL')}}</option>
                    </select>
					<label>{{ __('locale.Package')}}</label>
                  </div>
				  <div class="input-field col m4 s12">
                    <select id="payment">
                      <option value="12" selected>{{ __('locale.Annual')}}</option>
                      <option value="29">{{ __('locale.Quarterly')}}</option>
					  <option value="28">{{ __('locale.Semi-annual')}}</option>
                      <option value="27">{{ __('locale.Monthly')}}</option>
					  <option value="25">{{ __('locale.Biweekly')}}</option>
                    </select>
					<label>{{ __('locale.Payment')}}</label>
                  </div>
				  <div class="input-field col m4 s12">
                    <a class="waves-effect waves-light btn cyan modal-trigger" href="#modal7" style="width:100%;">
                      {{ __('locale.Send_mail')}}</a>
                  </div>
				  <div id="table" class="input-field col s12">
					  <div class="responsive-table">
						  <table class="table">
							  <thead>
								  <tr>
									  <th>Seguros ACV<br><a id="aba_view"><i class="material-icons dp48">visibility</i></a></th>
									  <th><img src="{{ asset('images/logo/aba.png')}}" style="width:100px; height:25px;"><br>
										  <p id='total'></p><p id="hire" style="display:none;">{{ __('locale.Hire')}}</p></th>
								  </tr>
							  </thead>
							  <tbody id="quotes" style="display: none;">
								  
							  </tbody>
						  </table>
						  <table class="table">
							  <thead>
								  <tr>
									  <th>Seguros ACV<br><a id="qual_view"><i class="material-icons dp48">visibility</i></a></th>
									  <th><img src="{{ asset('images/logo/qualitas.png')}}" style="width:100px; height:25px;"><br><p id='qual_ptotal'></p></th>
								  </tr>
							  </thead>
							  <tbody id="qual" style="display: none;">
							  </tbody>
						  </table>
				    </div>
                  </div>
              </div>
                <div class="step-actions">
                  <div class="row">
                    <div class="col m6 s12 mb-1">
                      <a class="red btn btn-reset" href="{{ asset('quot-create')}}">
                        <i class="material-icons left">clear</i>{{ __('locale.Reset')}}
                      </a>
                    </div>
                  </div>
                </div>
            </li>
          </ul>
		<!-- Modal Part -->	
		  <div id="modal1" class="modal modal-fixed-footer">
			  <div class="modal-content">
				  <div class="row">
					  <div class="input-field col s12">
						<select id="select_brand">
						  <option value="Select" disabled selected>{{ __('locale.Select')}} {{ __('locale.Brand')}}</option>
						  @foreach($data['brands'] as $d)
						  <option value="{{ $d['ID']}}" id="brand_{{ $d['ID']}}">{{ $d['DESC']}}</option>
						  @endforeach
						</select>
					  </div>
					  <?php $type_vehicle = array("AUDI", "BMW", "BUICK", "FIAT", "FORD", "JEEP", "GMC", "MERCEDES", "MINI", "SEAT", "HONDA", "HYUNDAI", "KIA", "MITSUBISHI", "NISSAN", "SUBARU", "SUZUKI", "TOYOTA", "VOLKSWAGEN", "MAZDA", "MERCEDES BENZ", "PEUGEOT", "RENAULT");?>
					  @foreach($data['brands'] as $d)
					  <?php $flag = 0; ?>
					  @foreach($type_vehicle as $t)
					  	@if ($d['DESC'] == $t)
					  		<?php $flag = 1; ?>
					  	@endif
					  @endforeach
					  @if ($flag == 1)
					  <div id="brand_img" class="input-field col m3 s4" style="text-align:center;">
						<img id="{{ $d['ID']}}" src="{{ asset('images/Brands/' . $d['DESC'] . '.svg') }}">
						<p id="{{ $d['DESC']}}">{{ $d['DESC']}}</p>
					  </div>
					  @endif
					  @endforeach
				  </div>
			  </div>
		  </div>
		  <div id="modal2" class="modal modal-fixed-footer">
			  <div class="modal-content">
				  <h6>{{ __('locale.Select')}} {{ __('locale.Sub_brand')}}</h6>
				  <div id="subbrand" class="row">
				  </div>
			  </div>
		  </div>
		  <div id="modal3" class="modal modal-fixed-footer">
			  <div class="modal-content">
				  <div class="row">
					  <div class="input-field col s12">
						<select id="select_year">
						  <option value="Select" disabled selected>{{ __('locale.Select')}} {{ __('locale.Year')}}</option>
						  <?php $year = date("Y") + 1; for ($x = 0; $x < 40; $x++){?>
						  <option value="{{ $year }}">{{ $year }}</option>
						  <?php  $year = $year - 1;} ?>
						</select>
					  </div>
				  	  <?php $current = date("Y") + 2; for ($x = 0; $x < 20; $x++){ $current = $current - 1;?>
					  <div id="mod" class="input-field col m3 s6" style="text-align:center;">
						  <a id="{{ $current }}" class="btn waves-effect waves-light cyan" style="width:100%">{{ $current }}</a>
					  </div>
				  	  <?php } ?>
				  </div>
			  </div>
		  </div>
		  <div id="modal4" class="modal modal-fixed-footer">
			  <div class="modal-content">
				  <h6>{{ __('locale.Select')}} {{ __('locale.Model')}}</h6>
				  <div class="row">
					  <div id="model" class="input-field col s12">
					  </div>
				  </div>
			  </div>
		  </div>
		  <div id="modal5" class="modal modal-fixed-footer">
			  <div class="modal-content">
				  <div class="row">
					  <div class="col s12">
						  <p class="titlePrincipal" data-nsfw-filter-status="swf">
							  Términos de Uso de la Aplicación
						  </p>
						  <p class="text-center" data-nsfw-filter-status="swf">
							  Revisado por última vez el: 28 de junio de 2021
						  </p>
						  <br>
						  <p class="titleGloberTerminos margintop_20px" data-nsfw-filter-status="swf">
							  CONTRATO ENTRE EL USUARIO Y SEGUROS ACV
						  </p>
						  <br>
						  <p class="titleGlober" data-nsfw-filter-status="swf">
							  1. Datos Generales
						  </p>
						  <br>
						  <p data-nsfw-filter-status="swf">
							  Bienvenido al sitio Web y a la aplicación de <span class="titleGlober" data-nsfw-filter-status="swf">Seguros ACV</span> (ambas en su conjunto o cada una de ellas referidas como la “Aplicación”).  Estos términos y condiciones de uso se referirán al conjunto de servicios ofrecidos en la Aplicación de manera gratuita.  Esta Aplicación se proporciona únicamente para ayudar a los usuarios a recolectar mediante las búsquedas que en ella se realizan (las “búsquedas”), información de seguros y de servicios relacionados (los “Servicios”), determinando la disponibilidad de los servicios, proporcionando información de precios, características, condiciones y en su caso promociones (en su conjunto la “Información”) y para ningún otro propósito. En la Aplicación tú encontrarás publicados contenidos, imágenes, textos, datos, gráficos, información, sugerencias, y en general, material diverso que te será brindada (incluyendo promociones e Información intercambiada como respuesta a tu actividad en la Aplicación) para ayudarte.
							  <br><br>
							  Los términos "nosotros", "nos", "nuestro", y “Seguros ACV”, se refieren a <span class="titleGlober" data-nsfw-filter-status="swf">Seguros ACV</span>, una sociedad mexicana. Los términos "tú", “ti”, “cliente” o “usuario” se refiere al cliente o usuario que visita la Aplicación y/o realiza una búsqueda a través de nuestra Aplicación.
							  <br><br>
							  La información y servicios proporcionada en la Aplicación tiene el propósito de presentar distintas opciones de seguros y servicios relacionados, así como las diferentes opciones de precio que estos ofrecen.
							  Se te ofrece esta Aplicación siempre y cuando aceptes sin modificar de forma alguna todos los términos, condiciones y avisos que se especifican a continuación, (colectivamente, los "Términos de uso" o "Contrato") y autorices el uso y la transferencia de tu información personal conforme a nuestro Aviso de Privacidad, los cuales constituyen un acuerdo entre el usuario y <span class="titleGlober" data-nsfw-filter-status="swf">Seguros AXV</span>, S.A de C.V.,  quien es el operador de la Aplicación.
						  </p>
						  <br>
						  <p class="titleGlober" data-nsfw-filter-status="swf">
							  2. Aceptación
						  </p>
						  <br>
						  <p data-nsfw-filter-status="swf">
							  Al hacer clic en el botón “ACEPTAR”, acceder o utilizar esta Aplicación, realizar alguna búsqueda de los productos o servicios en la Aplicación o al contactar a alguno de nuestros representantes, empleados o trabajadores, otorgas tú consentimiento,  y aceptas que se deben aplicar los Términos de Uso que estén vigentes en ese momento así como el uso y la transferencia de tu información personal conforme a nuestro Aviso de Privacidad. Esta Aceptación constituye un acuerdo respecto diversos temas entre <span class="titleGlober" data-nsfw-filter-status="swf">Seguros ACV</span> y tú, por lo que deberás leer con atención los términos y condiciones en el presente.
							  <br><br>
							  Si no aceptas los Términos de Uso, no utilices ni realices ninguna búsqueda por medio de esta Aplicación, ni realices alguna consulta a nuestros agentes, empleados o trabajadores por ningún medio, en éste caso deberás indicarlo haciendo clic en el botón "Rechazar" o " No acepto". Si deseas posteriormente cancelar tu consentimiento podrás hacerlo siguiendo los pasos que más adelante se detallan. <span class="titleGlober" data-nsfw-filter-status="swf">Seguros ACV</span> puede modificar estos Términos de Uso en cualquier momento y tu uso continuo de esta Aplicación está condicionada a la aceptación de dichos Términos de Uso actualizados.
							  <br><br>
							  La información que tú nos proporcionas al realizar tú registro y al usar los Servicios que la Aplicación te ofrece es de carácter confidencial y sólo será transferida en los casos que se requiera de conformidad con el Aviso de Privacidad y los presentes Términos de Uso.
							  <br><br>
							  El uso de la Aplicación, y/o registro constituye tu firma electrónica indicando que estás de acuerdo y acepta estos Términos de Uso y sus condiciones, incluyendo nuestro Aviso de Privacidad, así como tu consentimiento a celebrar acuerdos electrónicos con nosotros.
						  </p>
						  <br>
						  <p class="titleGlober" data-nsfw-filter-status="swf">
							  3. Uso de la Aplicación
						  </p>
						  <br>
						  <p data-nsfw-filter-status="swf">
							  Como condición de uso de esta Aplicación, reconoces y garantizas que:
							  <br><br>
						  </p><p class="titleulRomano" data-nsfw-filter-status="swf">
						  1.  Tienes por lo menos 18 años de edad; así como plena capacidad de ejercicio. Si tú no cumples con esta condición, puedes usar la Aplicación únicamente bajo la supervisión de una persona mayor de edad y capaz siempre que haya expresado previamente su acuerdo con los Términos de Uso. Al usar la Aplicación o los Servicios en representación de un menor de edad, usted garantiza que es el tutor legal de dicho menor, y que toda referencia en estos Términos de Uso a "tú", “ti”, “cliente” o “usuario”, se referirán a dicho menor de edad, o cualquier otro individuo para quien tienes autorización de celebrar estos Términos de Uso en su nombre.
						  <br>2.  Tienes la autoridad legal para crear una obligación legal vinculante; Al usar la Aplicación y/o los Servicios, tú manifiestas bajo protesta de decir verdad que tienes el derecho y la capacidad para obligarte bajo estos Términos de Uso y para acatarlos.
						  <br>3.  Utilizarás esta Aplicación de acuerdo con estos Términos de Uso;
						  <br>4.  Solo utilizarás esta Aplicación para realizar búsquedas o solicitudes con fines legítimos para ti u otra persona para la cual estás legalmente autorizado a actuar;
						  <br>5.  Le informarás a cualquier otra persona, para la cual estás utilizando la Aplicación, sobre los Términos de Uso que se aplican a las busquedas que has hecho en su nombre, incluyendo todas las normas y restricciones aplicables a ellas;
						  <br>6.  Toda la información que suministres en esta Aplicación es verdadera, exacta y completa;
						  <br>7.  Protegerás la información de tu cuenta; supervisarás y serás totalmente responsable de cualquier uso de tu cuenta, ya sea de tu parte y/o de cualquier tercero.
						  </p>
						  <br><br>
						  Nos reservamos el derecho, a nuestro exclusivo criterio, a negar el acceso a cualquier persona a esta Aplicación y a los servicios que ofrecemos, en cualquier momento y por cualquier razón, incluyendo, pero no limitándose a la violación de estos Términos de Uso.
						  <br><br>
						  Esta Aplicación es administrada en los Estados Unidos Mexicanos, y está dirigido a usuarios en México; cualquier uso del mismo fuera de México es por cuenta y riesgo del Usuarios, y el Usuarios es responsable de cumplir con cualquier ley local aplicable al uso de la Aplicación y/o los Servicios.
						  <p data-nsfw-filter-status="swf"></p>
						  <br>
						  <p class="titleGlober" data-nsfw-filter-status="swf">
							  4. Prohibiciones
						  </p>
						  <br>
						  <p data-nsfw-filter-status="swf">
							  El contenido y la información de esta Aplicación (incluyendo pero no limitándose a la información sobre el precio de productos y a la disponibilidad de servicios) así como también la infraestructura utilizada para suministrar dicho contenido e información es propiedad de <span class="titleGlober" data-nsfw-filter-status="swf">Seguros ACV</span> y/o de nuestros proveedores, según corresponda. Tú eres responsable por todo tú uso de la Aplicación y de sus credenciales.
							  <br><br>
							  Con la aceptación de estos Términos de Uso, te obligas y aceptas no modificar, copiar, distribuir, transmitir, exhibir, presentar, reproducir, publicar, autorizar, alterar, transferir, vender ni revender información, software, productos o servicios obtenidos a través de esta Aplicación.
							  <br><br>
							  Así mismo, aceptas y te obligas a: (i) Utilizar este Aplicación ni sus contenidos para cualquier propósito no autorizado por los presentes Términos de Uso. (ii) Utilizar la Aplicación de alguna forma que pudiera dañar, incapacitar, sobrecargar, o deshabilitar nuestros servidores o redes, o interferir en el uso y goce que terceros puedan hacer de la Aplicación o los Servicios. (ni le permitirá a ningún tercero hacerlo); (iii) Controlar, modificar  o copiar cualquier contenido o información de este Aplicación utilizando algún dispositivo de re direccionamiento, otro medio automatizado o cualquier proceso manual para cualquier propósito sin nuestro permiso expreso por escrito, (iv) Violar o tratar de evadir medidas empleadas para prevenir o limitar el acceso indebido o no autorizado a esta Aplicación, (v) Tomar cualquier medida o llevar a cabo cualquier acto que imponga o pueda imponer, según nuestro criterio, una carga irrazonable o desproporcionalmente grande sobre nuestra infraestructura; (vi) Realizar un enlace profundo a cualquier parte de esta Aplicación para cualquier propósito sin nuestro permiso expreso por escrito, (vi) Insertar, utilizar reflejar el contenido, o incorporar alguna parte de esta Aplicación a cualquier otra aplicación sin nuestra autorización previa, por escrito; (viii) Remover cualquier aviso sobre derechos de autor, marcas registradas, u otros avisos sobre titularidad que se contienen en o sobre la Aplicación y/o los Servicios; (ix) Crear cuentas de usuario usando medios automatizados, o con pretensiones falsas o fraudulentas;(x) Usar cualquier medio, incluyendo medios de software, para efectuar un “respaldo” de cualquier porción de la Aplicación, sus contenidos o materiales, y/o los Servicios.
							  <br><br>
							  Si tu uso de la Aplicación muestra signos de fraude, abuso o actividad sospechosa, <span class="titleGlober" data-nsfw-filter-status="swf">Seguros ACV</span> puede cancelar cualquier servicio de la Aplicación asociado con tu nombre, dirección de correo electrónico o cuenta, y cerrar cualquier cuenta asociada de <span class="titleGlober" data-nsfw-filter-status="swf">Seguros ACV</span>. Si realizas alguna actividad fraudulenta, <span class="titleGlober" data-nsfw-filter-status="swf">Seguros ACV</span> se reserva el derecho de interponer cualquier acción legal necesaria y serás el responsable de cualquier daño o perjuicio a <span class="titleGlober" data-nsfw-filter-status="swf">Seguros ACV</span>, incluyendo los costos de litigio. Para objetar la cancelación o cierre de una cuenta, comunícate con el Servicio de atención a clientes de <span class="titleGlober" data-nsfw-filter-status="swf">Seguros ACV</span>.
						  </p>
						  <br>
						  <p class="titleGlober" data-nsfw-filter-status="swf">
							  5. Normas de los Proveedores
						  </p>
						  <br>
						  <p data-nsfw-filter-status="swf">
							  Tu compra de bienes y/o contratación de servicios relacionados con la información proporcionada por la Aplicación estará sujeta a los términos y condiciones de cada Proveedor. Los términos y condiciones de compra impuestos por cualquier proveedor que elijas para adquirir bienes o contratar servicios quedará sujeta a las restricciones, términos, condiciones, obligaciones y responsabilidades del proveedor. Aún cuando <span class="titleGlober" data-nsfw-filter-status="swf">Seguros ACV</span> hará el mayor esfuerzo para  proporcionar la información más actualizada y exacta posible, las compañías de seguro pueden cambiar sus precios sin avisar, por lo que <span class="titleGlober" data-nsfw-filter-status="swf">Seguros ACV</span> no se hace responsable de los cambios en los precios o condiciones de venta.
						  </p>
						  <br>
						  <p class="titleGlober" data-nsfw-filter-status="swf">
							  6. Limitaciones de Responsabilidad
						  </p>
						  <br>
						  <p data-nsfw-filter-status="swf">
							  Al ser una herramienta la cual incluye funciones de búsqueda de precios y servicios, la información proporcionada por la Aplicación a los Usuarios, es información obtenida de diversas fuentes, por lo que está sujeta a cambios sin previo aviso. La información proporcionada por la Aplicación será en todo momento considerada de carácter informativo y no generará relación legal o contractual alguna, ni generará obligación alguna para <span class="titleGlober" data-nsfw-filter-status="swf">Seguros ACV</span> frente a los Usuarios o a los proveedores de los Productos y/o Servicios.
							  <br><br>
							  Así mismo, la Información, Software, Productos y Servicios publicados en esta Aplicación pueden incluir inexactitudes o errores, incluso errores en el precio, por ello <span class="titleGlober" data-nsfw-filter-status="swf">Seguros ACV</span> no garantiza la exactitud de la información que obtiene de los sitios públicos de internet de donde la obtiene, ni será responsable por cualquier modificación en los precios o disponibilidad, calidad, eficacia o estado de cierto Producto y/o Servicio publicado, ofrecido o publicitado por los diferentes proveedores de los diferentes Productos y/o servicios, que mencione la Aplicación. Al aceptar estos términos de Uso, tú reconoces, aceptas y liberas de toda responsabilidad a <span class="titleGlober" data-nsfw-filter-status="swf">Seguros ACV</span>  por cualquier error u otra inexactitud relacionada con la información y descripción de los productos y servicios que se muestran en esta Aplicación (incluyendo sin limitación, el precio, los nombres, las descripciones del producto, etc.).
							  <br><br>
							  <span class="titleGlober" data-nsfw-filter-status="swf">Seguros ACV</span> y sus empresas afiliadas no realizan ninguna declaración o manifestación sobre la idoneidad de la información, el software, los productos y los servicios incluidos en este Aplicación para ningún propósito. La inclusión o la oferta de cualquier producto o servicio en esta Aplicación no constituye ninguna recomendación de dichos productos o servicios por parte de <span class="titleGlober" data-nsfw-filter-status="swf">Seguros ACV</span>. Dicha información, productos de software y servicios se proporcionan "en el estado en que se encuentran" sin ningún tipo de garantía.
							  <br><br>
							  Será del interés de <span class="titleGlober" data-nsfw-filter-status="swf">Seguros ACV</span> reparar cualquier interrupción o posible mal funcionamiento de la Aplicación, sin embargo <span class="titleGlober" data-nsfw-filter-status="swf">Seguros ACV</span> se reserva el derecho de suspender temporal o permanentemente el funcionamiento de la Aplicación por cualquier circunstancia que sea para el correcto, debido o mejorado funcionamiento de la Aplicación.
							  <br><br>
							  Bajo ninguna circunstancia <span class="titleGlober" data-nsfw-filter-status="swf">Seguros ACV</span> y sus empresas afiliadas serán responsables de algún daño directo, indirecto, punitivo, incidental, especial o consecuencial que surja o que esté relacionado de alguna manera con tu acceso, visualización o uso de esta Aplicación o con el retraso o incapacidad de acceso, visualización o uso de esta Aplicación (incluyendo sin limitación, cualquier virus informático, información, software, enlaces relacionados, productos y servicios obtenidos a través de esta Aplicación, o que surjan por el acceso, visualización o uso de la misma) ya sea a causa de negligencia, contrato, responsabilidad, orden de protección del consumidor o lo que fuera, aún si <span class="titleGlober" data-nsfw-filter-status="swf">Seguros ACV</span> y sus empresas afiliadas fueran advertidos sobre la posibilidad de estos daños.
							  <br><br>
							  <span class="titleGlober" data-nsfw-filter-status="swf">Seguros ACV</span>, podrá añadir nuevos servicios a la Aplicación, sustituir un servicio nuevo por uno de los Servicios existentes, o descontinuar o suspender uno de los Servicios existentes. El uso de los servicios nuevos se regirá por estos Términos de Uso y/o sus modificaciones.
							  <br><br>
							  La limitación de responsabilidad refleja la asignación de riesgos entre las partes. Las limitaciones especificadas en esta sección perdurarán y se aplicarán aún si el Usuario u <span class="titleGlober" data-nsfw-filter-status="swf">Seguros ACV</span> suspenden el uso de la Aplicación. Las limitaciones de responsabilidad que se especifican en estos Términos de uso redundan en beneficio de <span class="titleGlober" data-nsfw-filter-status="swf">Seguros ACV</span>.
						  </p>
						  <br>
						  <p class="titleGlober" data-nsfw-filter-status="swf">
							  7.  Renuncia de Garantías
						  </p>
						  <br>
						  <p data-nsfw-filter-status="swf">
							  Por este medio tú reconoces, acuerdas y aceptas que <span class="titleGlober" data-nsfw-filter-status="swf">Seguros ACV</span> no otorga garantía alguna, sea implícita o explícita, respecto a los Servicios, los Productos y/o la Aplicación. No garantizamos que el resultado que se pueda obtener del uso de los servicios o de los productos promocionados a través de la Aplicación serán efectivos, o correctos, ni que satisfacerán tus requerimientos; no garantizamos que tú podrás obtener acceso a utilizar los Servicios (sea en forma directa o por medio de redes de terceros) en las oportunidades o desde las ubicaciones que tú escojas; no somos responsables por la exactitud y confiabilidad de la información o datos aportados o recibidos por medio de la Aplicación, ni por que dicha información sea oportuna y completa; no hacemos garantía alguna respecto a los sistemas de información, software, y funciones que se hacen accesibles por medio de la Aplicación, o por cualquier otro aspecto de seguridad asociado con la transmisión de información; no garantizamos que la Aplicación y los servicios operarán sin errores, o que el software de los servicios o la Aplicación estén libres de virus de computadora, contaminantes, y otros elementos nocivos.
						  </p>
						  <br>
						  <p class="titleGlober" data-nsfw-filter-status="swf">
							  8.  Indemnización
						  </p>
						  <br>
						  <p data-nsfw-filter-status="swf">
							  Al hacer uso de esta Aplicación, aceptas defender, indemnizar y sacar en paz y a salvo a <span class="titleGlober" data-nsfw-filter-status="swf">Seguros ACV</span> y sus empresas afiliadas, así como a cualquiera de sus contratistas, gerentes, funcionarios, directores, empleados, agentes, derechohabientes y cesionarios, en contra de cualquier reclamación, demanda, exigencia o cualquier otro acto de molestia, y cubrirá todos los gastos relacionados, incluyendo honorarios de abogado, como resultado de:
							  <br><br>
						  </p><p class="titleulRomano" data-nsfw-filter-status="swf">
						  1.  Tu violación o incumplimiento a estos Términos de Uso o a los documentos a los que se hace referencia en ellos;
						  <br>2.  Tu violación de cualquier ley o derecho de tercero; o
						  <br>3.  Tu uso de esta Aplicación.
						  </p>
						  <p data-nsfw-filter-status="swf"></p>
						  <br>
						  <p class="titleGlober" data-nsfw-filter-status="swf">
							  10. Enlaces a Sitios y Referencias a Terceros
						  </p>
						  <br>
						  <p data-nsfw-filter-status="swf">
							  Esta Aplicación puede contener referencias a nombres y marcas de terceros con carácter informativo, así como a hipervínculos a sitios web operados por terceros no relacionados con <span class="titleGlober" data-nsfw-filter-status="swf">Seguros ACV</span>, incluyendo enlaces aportados en calidad de resultados de búsqueda automatizada y algunos de estos sitios pueden contener materiales que son objetables o incorrectos. Dichos nombres, marcas e hipervínculos se proporcionan solamente para referencia y en tú beneficio. No controlamos estos sitios web ni tampoco somos responsables de sus contenidos o de la privacidad u otras prácticas de dichos sitios web. Además, es tu decisión tomar precauciones para asegurarte de que el enlace que selecciones o el software que descargues (ya sea de este o de cualquier otra Aplicación) esté libre de virus, defectos y otros elementos de naturaleza destructiva. Nuestra inclusión de los hipervínculos en dichos sitios web no implica ninguna aprobación del material de dichos sitios web ni ninguna asociación con sus operadores.
						  </p>
						  <br>
						  <p class="titleGlober" data-nsfw-filter-status="swf">
							  11. Software
						  </p>
						  <br>
						  <p data-nsfw-filter-status="swf">
							  Cualquier software que pongamos a disposición para descargar esta Aplicación ("Software") es obra de <span class="titleGlober" data-nsfw-filter-status="swf">Seguros ACV</span> y/o sus empresas afiliadas protegida por derechos de autor. El uso de dicho Software se rige por los términos del acuerdo de licencia del usuario final, si lo hubiere, que acompaña o está incluido con el Software ("Acuerdo de Licencia"). No podrás instalar ni utilizar ningún Software que venga acompañado o que incluya un Acuerdo de Licencia a menos que primero aceptes los términos del Acuerdo de Licencia. En el caso de que el Software para descargar esta Aplicación no venga acompañado de un Acuerdo de Licencia, por el presente te otorgamos a ti, el usuario, una licencia limitada, personal, no exclusiva y no transferible para descargar, instalar y utilizar el Software para visualizar y utilizar esta Aplicación y/o acceder al contenido y a la información disponible dentro de la Aplicación Móvil de acuerdo con estos Términos de Uso y para ningún otro propósito.
							  <br><br>
							  Ten en cuenta que todo el Software, incluyendo sin limitación, todo código y controles incluidos en esta Aplicación, es propiedad de <span class="titleGlober" data-nsfw-filter-status="swf">Seguros ACV</span> y/o sus empresas afiliadas y está protegido por las disposiciones de las leyes de derecho de autor y de los tratados internacionales aplicables. Cualquier reproducción o redistribución del Software está expresamente prohibido y puede provocar serias penalizaciones civiles y penales. Los infractores serán procesados en el máximo alcance legal posible.
							  <br><br>
							  Tú reconoces que los Servicios y cualquier tecnología subyacente o software que se usen en conexión con la Aplicación contienen información propiedad de , por lo que te otorgamos permiso de usar el contenido antedicho, únicamente para fines personales, no-comerciales y no te transferimos ningún derecho de propiedad intelectual con motivo de permitir el uso de los Servicios. Tú no puedes copiar, distribuir, volver a publicar, vender, o explotar el contenido en forma alguna, o explotar la Aplicación, sea en parte o en su totalidad, para fines de lucro comercial, o para cualquier otro fin. <span class="titleGlober" data-nsfw-filter-status="swf">Seguros ACV</span> se reserva todos los derechos correspondientes a la Aplicación y los Servicios que no le han sido expresamente otorgados a usted.
							  <br><br>
							  Tu dispositivo móvil debe estar conectado a internet para que la Aplicación funcione correctamente. Eres responsable de hacer todos los arreglos necesarios para que tu dispositivo tenga conexión a internet, así como también eres responsable de todos los cargos que tu proveedor de servicios puede cobrarte que surjan de los datos de transmisión y recepción de la Aplicación (incluyendo pero no limitándose a los cargos de roaming de datos). Tal como se describe más adelante en nuestro Aviso de Privacidad, con el registro en la Aplicación tu proporcionarás automáticamente una pequeña cantidad de datos como parte de su funcionamiento normal, incluso cómo utilizas la Aplicación, a qué contenidos accedes y con qué errores o problemas técnicos te encuentras cuando utilizas la Aplicación. Al utilizar la Aplicación, reconoces, aceptas y accedes a la recolección automática de esta información.
						  </p>
						  <br>
						  <p class="titleGlober" data-nsfw-filter-status="swf">
							  12. Control de la Información proporcionada por la Aplicación
						  </p>
						  <br>
						  <p data-nsfw-filter-status="swf">
							  Te exhortamos a que de manera independiente, verifiques la información que te haya sido proporcionada por la Aplicación.
							  <br><br>
							  Todo producto y/o Servicio presentado en Aplicación por anunciantes, patrocinadores, y otros participantes en la Aplicación, sean pagados o no pagados, son presentados con el propósito de que usted esté consciente de los mismos, y no necesariamente conllevan la implicación de idoneidad para algún individuo en particular, ni cualquier pronóstico de efectividad, resultado o éxito. En ningún caso <span class="titleGlober" data-nsfw-filter-status="swf">Seguros ACV</span> será responsable por los posibles daños o perjuicios que pudieran derivar de la Información disponible en la Aplicación referente al mal uso en cualquier grado de los productos o de los signos distintivos relacionados con los mismos.
						  </p>
						  <br>
						  <p class="titleGlober" data-nsfw-filter-status="swf">
							  13. Avisos de Marcas Registradas y Derechos de Autor
						  </p>
						  <br>
						  <p data-nsfw-filter-status="swf">
							  Toda la información disponible en o por conducto de los Servicios y/o la Aplicación, incluyendo sin limitación texto, fotografías, gráficos, y contenidos de video y audio, pertenece a <span class="titleGlober" data-nsfw-filter-status="swf">Seguros ACV</span> y a nuestros licenciadores y está protegido por el derecho de secreto industrial, patentes, marcas registradas, y derechos de autor, y otros derechos de propiedad y tratados internacionales.
							  <br><br>
							  El logotipo de <span class="titleGlober" data-nsfw-filter-status="swf">Seguros ACV</span>, es marca registrada o marca comercial de <span class="titleGlober" data-nsfw-filter-status="swf">Seguros ACV</span>, SAPI de CV en México y/o otros países. Los demás logotipos, nombres de productos y empresas aquí mencionados pueden ser marcas registradas de sus respectivos propietarios. <span class="titleGlober" data-nsfw-filter-status="swf">Seguros ACV</span> no se hace responsable por el contenido de los sitios web administrados por terceros distintos a <span class="titleGlober" data-nsfw-filter-status="swf">Seguros ACV</span>.
							  <br><br>
							  Si estás al tanto de una infracción de nuestra marca, notifícanos por correo electrónico ventas@Seguros ACV.mx. En esta dirección de correo electrónico solo respondemos mensajes relacionados con la infracción de marcas.
						  </p>
						  <br>
						  <p class="titleGlober" data-nsfw-filter-status="swf">
							  14. Cierre de la Cuenta
						  </p>
						  <br>
						  <p data-nsfw-filter-status="swf">
							  Podremos terminar y/o suspender a un Usuario de forma inmediata, sin aviso previo, si se ha presentado una violación a estos Términos de Uso, o de otras políticas y términos publicados en la Aplicación, ya sea por parte suya o por alguien que esté utilizando sus registro.
							  <br><br>
							  También podemos cancelar o suspender tu registro por cualquier otro motivo, incluyendo inactividad durante un periodo de tiempo extendido; pero intentaremos notificarte por adelantado en caso de dicha cancelación o suspensión.
							  <br><br>
							  Toda solicitud de terminación o cancelación de registro será atendida en un periodo que no excederá de 5 (cinco) días hábiles y podrá requerir realizar diversas actividades a fin de eliminar el software que en su caso se haya instalado y la información con datos sensibles que exista en nuestro sistema. Igualmente podremos requerirte el llenado de un formulario con el fin de asegurarse que no hayan existido violaciones a los presentes Términos de Uso.
							  <span class="titleGlober" data-nsfw-filter-status="swf">Seguros ACV</span> no tendrá responsabilidad ante ti o cualquier tercero con motivo de  la terminación de tú acceso a la Aplicación y/o los Servicios. Por otra parte, tú convienes en no intentar usar la Aplicación después de haber sido eliminado o desactivado tu registro.
							  <br><br>
							  Por otra parte si existiere alguna inconformidad, controversia o discrepancia en relación con los presentes Términos de Uso, la única vía para resolverlos será la cancelación de tu registro por lo que de manera expresa tú reconoces que la responsabilidad de <span class="titleGlober" data-nsfw-filter-status="swf">Seguros ACV</span> es limitada a realizar correctamente la cancelación del registro.
						  </p>
						  <br>
						  <p class="titleGlober" data-nsfw-filter-status="swf">
							  15. Aviso de Infracción
						  </p>
						  <br>
						  <p data-nsfw-filter-status="swf">
							  Si crees de buena fe que los materiales publicados por la Aplicación infringen tú propiedad industrial, tú (o tu agente) pueden enviarnos un aviso por escrito que incluya la siguiente información. Ten en cuenta que no procesaremos tu reclamo si no se llenó correctamente o si el reclamo está incompleto. Cualquier declaración falsa en tu aviso respecto a la actividad o el contenido puede hacerte responsable por los daños y perjuicios que se generen.
							  <br><br>
						  </p><p class="titleulRomano" data-nsfw-filter-status="swf">
						  1.  Identificación clara del material que se afirma está infringiendo en la Aplicación.
						  <br>2.  Tu dirección, dirección de correo electrónico y número de teléfono.
						  <br>3.  Una declaración firmada de que la parte que manda la notificación está autorizada para actuar en nombre del propietario de un derecho exclusivo que presuntamente se ha infringido.
						  <br>4.  Puedes enviarnos tu aviso por correo electrónico a ventas@Seguros ACV.mx, Atención: Departamento Legal de Marcas Registradas,
						  </p>
						  <p data-nsfw-filter-status="swf"></p>
						  <br>
						  <p class="titleGlober" data-nsfw-filter-status="swf">
							  16. Mapas
						  </p>
						  <br>
						  <p data-nsfw-filter-status="swf">
							  El uso que haces del mapeo disponible en esta Aplicación se rige por los Términos de uso y la Declaración de privacidad de Microsoft, Apple y Google. Microsoft, Apple y Google se reservan el derecho de cambiar sus Términos de uso y Declaraciones de privacidad en cualquier momento, según su criterio exclusivo. Haz clic aquí para obtener información adicional:
						  </p>
						  <br>
						  <p class="titleGlober" data-nsfw-filter-status="swf">
							  17. Jurisdicción y Ley Aplicable
						  </p>
						  <br>
						  <p data-nsfw-filter-status="swf">
							  Esta Aplicación es operada por una entidad mexicana y este Contrato que contiene los Términos de Uso, han sido elaborados de conformidad y se interpretarán y ejecutarán de conformidad con las leyes del Estado de Querétaro en materia local y demás legislación aplicable en materia federal. Por el presente accedes a la jurisdicción exclusiva y competencia territorial de los tribunales en la ciudad de Querétaro, Querétaro, en todas las disputas que surjan o que estén relacionadas con el uso de esta Aplicación. El uso de esta Aplicación no está autorizado en ninguna jurisdicción que no otorgue efecto a todas las provisiones de estos Términos de Uso, incluyendo sin limitación este párrafo.
							  <br><br>
							  Aceptas que no existe ninguna empresa conjunta, sociedad o relación de empleo entre tú y <span class="titleGlober" data-nsfw-filter-status="swf">Seguros ACV</span> y sus empresas afiliadas como resultado de este Contrato o el uso de esta Aplicación.
							  <br><br>
							  Nuestro cumplimiento de este Contrato está sujeto a las leyes existentes y al debido proceso legal.
						  </p>
						  <br>
						  <p class="titleGlober" data-nsfw-filter-status="swf">
							  18. Contrato Único
						  </p>
						  <br>
						  <p data-nsfw-filter-status="swf">
							  Si se encuentra que alguna parte de este Contrato es inválida, ilegal o inexigible, la validez, legalidad y cumplimiento de las provisiones restantes no se verá afectadas ni limitadas de forma alguna. Nuestra incapacidad o retraso para cumplir con alguna disposición de este Contrato en cualquier momento no nos exime del derecho de hacer cumplir dicha disposición o cualquiera otra en el futuro.
							  <br><br>
							  Este Contrato (y cualquier otro término y condición a los que aquí se hace referencia) constituye la totalidad del contrato entre tú y <span class="titleGlober" data-nsfw-filter-status="swf">Seguros ACV</span>, en relación con esta Aplicación, nuestros servicios y tus negocios y relaciones con nosotros y sustituye todo tipo de comunicación o convenio previo, ya sea electrónica, oral o escrita entre tú y nosotros. Se aceptará una versión impresa de este Contrato en procedimientos judiciales y administrativos en la misma medida y sujeto a las mismas condiciones que otros documentos y registros comerciales generados originalmente y mantenidos en forma impresa. Todos los derechos no otorgados expresamente quedan reservados.
						  </p>
						  <br>
						  <p class="titleGlober" data-nsfw-filter-status="swf">
							  19. Cesiones
						  </p>
						  <br>
						  <p data-nsfw-filter-status="swf">
							  <span class="titleGlober" data-nsfw-filter-status="swf">Seguros ACV</span> se reserva el derecho de ceder este contrato en cualquier momento a cualquier casa matriz, filial, o compañía afiliada, o como parte de la venta a, fusión con, u otra transferencia, de nuestra compañía con otra entidad.
							  <br><br>
							  En tal caso, se harán los esfuerzos necesarios para notificarte con respecto ello, y a cualquier cambio de titularidad, para que tengas la oportunidad de descontinuar tu uso de la Aplicación si así lo deseas, o cancelar tu registro.
							  <br><br>
							  Sin embargo, tú no puedes ceder, transferir, o sub-licenciar estos Términos de Uso a cualquier otra persona, y cualquier intento de hacerlo en violación de esta sección será nulo e inválido.
						  </p>
						  <br>
						  <p class="titleGlober" data-nsfw-filter-status="swf">
							  20. Aviso de Privacidad
						  </p>
						  <br>
						  <p data-nsfw-filter-status="swf">Para poder registrarse, tú aportas datos personales, y en su caso, datos personales sensibles, para lo cual también aceptas el manejo de dichos datos por parte de <span class="titleGlober" data-nsfw-filter-status="swf">Seguros ACV</span>, conforme al Aviso de Privacidad, igualmente publicado en la dirección: www.segurosacv.com</p>
					  </div>
				  </div>
			  </div>
		  </div>
		  <div id="modal6" class="modal modal-fixed-footer">
			  <div class="modal-content">
				<div class="row" style="text-align:center;">
				  <img src="{{ asset('images/small-background.png')}}">
				  <h4>Hola, soy tu agente, Leonardo.</h4>
				  <p>
					  Me pongo en contacto contigo a la brevedad para gestionar la <b>emisión de la póliza para tu seguro</b> de auto.
				  </p>
				  <button id="submit_quot" type="button" class="btn waves-effect waves-light cyan">¡Entendido!</button>
				</div>
			  </div>
		  </div>
		  <div id="modal7" class="modal modal-fixed-footer">
			  <div class="modal-content">
				  <div class="row" style="text-align:center;">
					  <img src="{{ asset('images/icon/send.svg')}}" alt="MulticotizadorSaas-enviar-cotizion" width="104" height="90">
					  <h4>Confirma tu correo electrónico</h4>
					  <p>Tu cotización llegará pronto a</p>
					  <input id="send_email" type="text" class="col m6 offset-m3">
					  <button id="send_email" class="btn waves-effect waves-light cyan" type="button">Enviar cotización
						  <i class="material-icons right">send</i>
					  </button>
				  </div>
			  </div>
		  </div>
		  <div id="modal8" class="modal modal-fixed-footer">
			  <div class="modal-content">
				<div class="row" style="text-align:center;">
				  <img src="{{ asset('images/small-background.png')}}">
				  <h4>Hola, soy tu agente, Leonardo.</h4>
				  <p>
					  Me pongo en contacto contigo a la brevedad para gestionar la <b>emisión de la póliza para tu seguro</b> de auto.
				  </p>
				  <button id="submit_qual" type="button" class="btn waves-effect waves-light cyan">¡Entendido!</button>
				</div>
			  </div>
		  </div>
        </div>
      </div>
    </div>
  </div>
</div>
@endsection

{{-- vendor script --}}
@section('vendor-script')
<script src="{{asset('vendors/materialize-stepper/materialize-stepper.min.js')}}"></script>
<script src="{{asset('vendors/sortable/jquery-sortable-min.js')}}"></script>
@endsection

{{-- page script --}}
@section('page-script')
<script src="{{asset('js/scripts/form-wizard.js')}}"></script>
<script src="{{asset('js/scripts/advance-ui-modals.js')}}"></script>
<script src="{{asset('js/quot.min.js')}}"></script>
@endsection