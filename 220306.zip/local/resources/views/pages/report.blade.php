{{-- extend layout --}}
@extends('layouts.contentLayoutMaster')

{{-- page title --}}
@section('title','Report')

{{-- page content --}}
@section('content')
<div class="seaction">
   <!--Line Chart-->
   <div id="chartjs-line-chart" class="card">
      <div class="card-content">
         <h4 class="card-title">{{ __('locale.Quotation')}}</h4>
         <p class="caption">
         </p>
         <div class="row">
            <div class="col s12">
               <p class="mb-2">
               </p>
               <div class="sample-chart-wrapper"><canvas id="quot-chart" height="400"></canvas></div>
            </div>
         </div>
      </div>
   </div>
	
   <!--Line Chart-->
   <div id="chartjs-line-chart" class="card">
      <div class="card-content">
         <h4 class="card-title">{{ __('locale.Policy')}}</h4>
         <p class="caption">
         </p>
         <div class="row">
            <div class="col s12">
               <p class="mb-2">
               </p>
               <div class="sample-chart-wrapper"><canvas id="line-chart" height="400"></canvas></div>
            </div>
         </div>
      </div>
   </div>
	
   <!--Bar Chart-->
   <div id="chartjs-bar-chart" class="card">
      <div class="card-content">
         <h4 class="card-title">{{ __('locale.Company')}}</h4>
         <div class="row">
            <div class="col s12">
               <p class="mb-2">
               </p>
               <div class="sample-chart-wrapper"><canvas id="bar-chart" height="400"></canvas></div>
            </div>
         </div>
      </div>
   </div>
	
   <!--Line Chart-->
   <div id="chartjs-line-chart" class="card">
      <div class="card-content">
         <h4 class="card-title">{{ __('locale.Ptotal')}}</h4>
         <p class="caption">
         </p>
         <div class="row">
            <div class="col s12">
               <p class="mb-2">
               </p>
               <div class="sample-chart-wrapper"><canvas id="ptotal-chart" height="400"></canvas></div>
            </div>
         </div>
      </div>
   </div>
</div>
@endsection

{{-- vendor scripts --}}
@section('vendor-script')
<script src="{{asset('vendors/chartjs/chart.min.js')}}"></script>
@endsection

{{-- page scripts --}}
@section('page-script')
<script src="{{asset('js/scripts/charts-chartjs.js')}}"></script>
@endsection