{{-- layout extend --}}
@extends('layouts.contentLayoutMaster')

{{-- page title --}}
@section('title','Notifications')

{{-- vendor styles --}}
@section('vendor-style')
<link rel="stylesheet" type="text/css" href="{{asset('vendors/flag-icon/css/flag-icon.min.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('vendors/quill/quill.snow.css')}}">
@endsection

{{-- page styles --}}
@section('page-style')
<link rel="stylesheet" type="text/css" href="{{asset('css/pages/app-sidebar.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('css/pages/app-email.css')}}">
@endsection

{{-- page content --}}
@section('content')
<!-- Sidebar Area Starts -->
<div class="email-overlay"></div>
<div class="sidebar-left sidebar-fixed">
  <div class="sidebar">
    <div class="sidebar-content">
      <div class="sidebar-header">
        <div class="sidebar-details">
          <h5 class="m-0 sidebar-title"><i class="material-icons app-header-icon text-top">notifications_none</i> {{ __('locale.Notifications')}}</h5>
          <div class="row valign-wrapper mt-10 pt-2 animate fadeLeft">
            <div class="col s3 media-image">
              <img src="{{asset('images/user/'. $user->image)}}" alt="" class="circle z-depth-2 responsive-img">
              <!-- notice the "circle" class -->
            </div>
            <div class="col s9">
              <p class="m-0 subtitle font-weight-700">{{ $user->firstname }} {{ $user->lastname }}</p>
              <p class="m-0 text-muted">{{ $user->email }}</p>
            </div>
          </div>
        </div>
      </div>
      <div id="sidebar-list" class="sidebar-menu list-group position-relative animate fadeLeft">
        <div class="sidebar-list-padding app-sidebar sidenav" id="email-sidenav">
          <ul class="display-grid">
            <li class="sidebar-title">{{ __('locale.Quotation')}}</li>
			<li><a href="{{ asset('quot_notify')}}" class="text-sub"><i class="material-icons mr-2"> note_add </i>{{ __('locale.Quot_notify')}}
				@if($notify['new_quot'] > 0)
				<span class="badge pill purple float-right mr-10">{{$notify['new_quot']}}</span>
				@endif
				</a>
			</li>
            <li class="sidebar-title">{{ __('locale.Policy')}}</li>
            <li><a href="{{ asset('new')}}" class="text-sub"><i class="material-icons mr-2"> add_shopping_cart </i>{{ __('locale.Policy_new')}}
				@if($notify['new'] > 0)
				<span class="badge pill purple float-right mr-10">{{$notify['new']}}</span>
				@endif
				</a>
			</li>
            <li class="active"><a href="{{ asset('expired')}}" class="text-sub"><i class="material-icons mr-2"> stars </i>{{ __('locale.Policy_expired')}}
				@if($notify['expired'] > 0)
				<span class="badge pill orange float-right mr-10">{{$notify['expired']}}</span>
				@endif
				</a>
			</li>
            <li><a href="{{ asset('canceled')}}" class="text-sub"><i class="material-icons mr-2"> today </i>{{ __('locale.Policy_canceled')}} 
				@if($notify['canceled'] > 0)
				<span class="badge pill pink float-right mr-10">{{$notify['canceled']}}</span>
				@endif
				</a>
			</li>
          </ul>
        </div>
      </div>
      <a data-target="email-sidenav" class="sidenav-trigger hide-on-large-only"><i
          class="material-icons">menu</i></a>
    </div>
  </div>
</div>
<!-- Sidebar Area Ends -->

<!-- Content Area Starts -->
<div class="app-email">
  <div class="content-area content-right">
    <div class="app-wrapper">
	  <div class="app-search">
        <i class="material-icons mr-2 search-icon">search</i>
        <input type="text" placeholder="{{ __('locale.Search')}}" class="app-filter" id="email_filter">
      </div>
      <div class="card card card-default scrollspy border-radius-6 fixed-width">
        <div class="card-content p-0 pb-2">
		  <div class="email-header">
            <div class="left-icons">
              <span style="margin-left: 1rem;">
                <i class="material-icons">notifications_none</i>
              </span>
            </div>
          </div>
          <div class="collection email-collection">
			@foreach ($data['news'] as $value)
            <div class="email-brief-info collection-item animate fadeUp delay-1">
              <a class="list-content" href="{{ route('policy-pdf', $value['message']) }}" target="_blank">
                <div class="list-title-area">
                  <div class="user-media">
                    <img src="{{asset('images/favicon/mstile-144x144.png')}}" alt="" class="circle z-depth-2 responsive-img avtar">
				  	<div class="list-title">{{ $value['cve']}}{{ $value['pol']}}</div>
                  </div>
                </div>
                <div class="list-desc">
					<span id="name" class="col l5">{{ $value['firstname']}} {{ $value['lastname']}} {{ $value['paternal_surname']}} {{ $value['maternal_surname']}}</span>
					<span id="start" class="col l3">{{ __('locale.Start_date')}}:&nbsp;&nbsp;{{ $value['start_date']}}</span>
					<span id="end" class="col l4">{{ __('locale.Cancel_date')}}:&nbsp;&nbsp;{{ $value['end_date']}}</span><br>
					<span id="des" class="col l8">{{ __('locale.Description')}}:&nbsp;&nbsp;{{ $value['description']}}</span>
					<span id="ptotal" class="col l4">Prima Total:&nbsp;&nbsp;${{ $value['ptotal']}} |MXN</span>
				</div>
              </a>
              <div class="list-right">
				@php $notify= explode(" ", $value['created_at']); @endphp
                <div class="list-date"> {{ $notify[0]}} </div>
              </div>
            </div>
			@endforeach
            <div class="no-data-found collection-item">
              <h6 class="center-align font-weight-500">{{ __('locale.No_result')}}</h6>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Content Area Ends -->

<!-- Add new email popup -->
<div style="bottom: 54px; right: 19px;" class="fixed-action-btn direction-top">
  <a class="btn-floating btn-large primary-text gradient-shadow compose-email-trigger">
    <i class="material-icons">mail_outline</i>
  </a>
</div>
<!-- Add new email popup Ends-->

<!-- email compose sidebar -->
<div class="email-compose-sidebar">
  <div class="card quill-wrapper">
    <div class="card-content pt-0">
      <div class="card-header display-flex pb-2">
        <h3 class="card-title"><i class="material-icons app-header-icon text-top">mail_outline</i></h3>
        <div class="close close-icon">
          <i class="material-icons">close</i>
        </div>
      </div>
      <div class="divider"></div>
      <!-- form start -->
      <form class="edit-email-item mt-10 mb-10" id="mail" action="{{ route('send-email') }}" enctype="multipart/form-data" method="POST">
		{{ csrf_field() }}
        <div class="input-field">
          <input type="email" value="{{ $user->email}}" disabled>
		  <input type="email" id="edit-item-from" name="from" value="{{ $user->email}}" style="display:none;">
          <label for="edit-item-from">{{ __('locale.From')}}</label>
        </div>
        <div class="input-field">
          <input type="email" id="edit-item-to" name="to" value="">
          <label for="edit-item-to">{{ __('locale.To')}}</label>
        </div>
        <div class="input-field">
          <input type="text" id="edit-item-subject" name="subject">
          <label for="edit-item-subject">{{ __('locale.Subject')}}</label>
        </div>
        <div class="input-field">
          <input type="email" id="edit-item-CC" name="CC">
          <label for="edit-item-CC">{{ __('locale.CC')}}</label>
        </div>
        <div class="input-field">
          <input type="email" id="edit-item-BCC" name="BCC">
          <label for="edit-item-BCC">{{ __('locale.BCC')}}</label>
        </div>
        <!-- Compose mail Quill editor -->
        <div class="input-field" style="display:none;">
          <div class="snow-container mt-2">
            <div class="compose-editor"></div>
            <div class="compose-quill-toolbar">
            </div>
          </div>
        </div>
		<div class="input-field">
			<textarea id="forward_message" class="materialize-textarea" name="content" style="height: 62px;"></textarea>
			<label for="forward_message" class="active">{{ __('locale.Message')}}</label>
		</div>
		<div class="file-field input-field">
          <div class="btn btn-file">
            <i class="material-icons mr-2"> attachment </i>
            <input type="file" name="attach">
          </div>
          <div class="file-path-wrapper">
            <input class="file-path validate" name="filePath" type="text">
          </div>
        </div>
      </form>
      <div class="card-action pl-0 pr-0 right-align">
        <button type="reset" class="btn-small waves-effect waves-light cancel-email-item mr-1">
          <i class="material-icons left">close</i>
          <span>Cancel</span>
        </button>
        <button class="btn-small waves-effect waves-light send-email-item">
          <i class="material-icons left">send</i>
          <span>{{ __('locale.Send')}}</span>
        </button>
      </div>
      <!-- form start end-->
    </div>
  </div>
</div>
@endsection

{{-- vendor scripts --}}
@section('vendor-script')
<script src="{{asset('vendors/quill/quill.min.js')}}"></script>
@endsection

{{-- page scripts --}}
@section('page-script')
<script src="{{asset('js/scripts/app-email.js')}}"></script>
@endsection