{{-- layout --}}
@extends('layouts.contentLayoutMaster')

{{-- page title --}}
@section('title','Policy Edit')

{{-- vendor styles --}}
@section('vendor-style')
<link rel="stylesheet" type="text/css" href="{{asset('vendors/select2/select2.min.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('vendors/select2/select2-materialize.css')}}">
@endsection

{{-- page style --}}
@section('page-style')
<link rel="stylesheet" type="text/css" href="{{asset('css/pages/page-users.css')}}">
@endsection

{{-- page content --}}
@section('content')
<!-- users edit start -->
<div class="section users-edit">
  
  <div class="card">
	  <div class="card-content">
		  <!-- users edit media object start -->
          <div class="media display-flex align-items-center mb-2">
            <div class="media-body">
              <h5 class="media-heading mt-0">{{ $data['policy']['cve'] }}{{ $data['policy']['pol'] }}</h5>
            </div>
          </div>
		  @if(session('success'))
		  <div class="card-alert card green lighten-5">
			  <div class="card-content green-text">
				  <p>{{ __('locale.'. session('success'))}}</p>
			  </div>
			  <button type="button" class="close green-text" data-dismiss="alert" aria-label="Close">
				  <span aria-hidden="true">×</span>
			  </button>
		  </div>
		  @endif
	  </div>
  </div>
  
  <div class="card">
    <div class="card-content">
      <div class="row">
        <div class="col s12" id="account">
          
          <!-- users edit account form start -->
          <form id="accountForm" action="{{ asset('policy-update/') }}" method="POST">
			  {{ csrf_field() }}
			  <input name="id" type="hidden" value="{{ $data['policy']['id'] }}">
            <div class="row">
				<div class="col s12 m6 l3 input-field">
					<input name="start_date" type="text" id="start"
                      value="{{ $data['policy']['start_date'] }}">
                    <label>{{ __('locale.Start_date')}}</label>
				</div>
				<div class="col s12 m6 l3 input-field">
					<input id="end_date" name="end_date" type="text"
                      value="{{ $data['policy']['end_date'] }}" {!! $data['policy']['status'] == '1' ? '' : 'disabled' !!}>
                    <label>{{ __('locale.End_date')}}</label>
				</div>
				<div class="col s12 m6 l3 input-field">
					<select id="status" name="status">
                      <option disabled {!! $data['policy']['status'] == null ? 'selected' : '' !!}>{{ __('locale.Select')}}</option>
					  <option value="1" {!! $data['policy']['status'] == '1' ? 'selected' : '' !!}>VIGENTE</option>
                      <option value="0" {!! $data['policy']['status'] == '0' ? 'selected' : '' !!}>CANCELADA</option>
                    </select>
                    <label>{{ __('locale.Status')}}</label>
				</div>
				<div class="col s12 m6 l3 input-field">
					<input id="cancel_date" name="cancel_date" type="text"
                      value="{{ $data['policy']['cancel_date'] }}" {!! $data['policy']['status'] == '0' ? '' : 'disabled' !!}>
                    <label>{{ __('locale.Cancel_date')}}</label>
				</div>
				<div class="col s12 m6 l3 input-field">
					<input name="brand" type="text" class="validate" value="{{ $data['policy']['marca'] }}">
					<label>{{ __('locale.Brand')}}</label>
				</div>
				<div class="col s12 m6 l3 input-field">
					<input name="model" type="text" class="validate" value="{{ $data['policy']['model'] }}">
					<label>{{ __('locale.Year')}}</label>
				</div>
				<div class="col s12 m12 l6 input-field">
					<input name="des" type="text" class="validate" value="{{ $data['policy']['description'] }}">
					<label>{{ __('locale.Description')}}</label>
				</div>
				<div class="col s12 m6 l3 input-field">
					<input name="serie" type="text" class="validate" value="{{ $data['policy']['serie'] }}">
					<label>{{ __('locale.Serie')}}</label>
				</div>
				<div class="col s12 m6 l3 input-field">
					<input name="motor" type="text" class="validate" value="{{ $data['policy']['motor'] }}">
					<label>{{ __('locale.Motor')}}</label>
				</div>
				<div class="col s12 m6 l3 input-field">
					<input name="plates" type="text" class="validate" value="{{ $data['policy']['plates'] }}">
					<label>{{ __('locale.Plates')}}</label>
				</div>
				<div class="col s12 m6 l3 input-field">
					<input name="ref" type="text" class="validate" value="{{ $data['policy']['reference'] }}">
					<label>{{ __('locale.Reference')}}</label>
				</div>
				<div class="col s12 m4 input-field">
					<select name="paq">
                      <option disabled {!! $data['policy']['paq'] == null ? 'selected' : '' !!}>{{ __('locale.Select')}}</option>
					  <option value="1" {!! $data['policy']['paq'] == '1' ? 'selected' : '' !!}>{{ __('locale.RC')}}</option>
                      <option value="2" {!! $data['policy']['paq'] == '2' ? 'selected' : '' !!}>{{ __('locale.Limited')}}</option>
					  <option value="3" {!! $data['policy']['paq'] == '3' ? 'selected' : '' !!}>{{ __('locale.Wide')}}</option>
                      <option value="460" {!! $data['policy']['paq'] == '460' ? 'selected' : '' !!}>{{ __('locale.INTEGRAL')}}</option>
                    </select>
                    <label>{{ __('locale.Package')}}</label>
				</div>
				<div class="col s12 m4 input-field">
					<select name="fp">
					  <option disabled {!! $data['policy']['fp'] == null ? 'selected' : '' !!}>{{ __('locale.Select')}}</option>
                      <option value="12" {!! $data['policy']['fp'] == '12' ? 'selected' : '' !!}>{{ __('locale.Annual')}}Contado</option>
                      <option value="28" {!! $data['policy']['fp'] == '28' ? 'selected' : '' !!}>{{ __('locale.Semi-annual')}}</option>
					  <option value="29" {!! $data['policy']['fp'] == '29' ? 'selected' : '' !!}>{{ __('locale.Quarterly')}}</option>
                      <option value="27" {!! $data['policy']['fp'] == '27' ? 'selected' : '' !!}>{{ __('locale.Monthly')}}</option>
                      <option value="25" {!! $data['policy']['fp'] == '25' ? 'selected' : '' !!}>{{ __('locale.Biweekly')}}</option>
                    </select>
                    <label>{{ __('locale.Payment')}}</label>
				</div>
				<div class="col s12 m4 input-field">
					<select name="company">
					  <option disabled {!! $data['policy']['company'] == null ? 'selected' : '' !!}>{{ __('locale.Select')}}</option>
                      <option value="ABA" {!! $data['policy']['company'] == 'ABA' ? 'selected' : '' !!}>ABA</option>
                      <option value="AXA" {!! $data['policy']['company'] == 'AXA' ? 'selected' : '' !!}>AXA</option>
					  <option value="QUA" {!! $data['policy']['company'] == 'QUA' ? 'selected' : '' !!}>QUA</option>
                      <option value="BAN" {!! $data['policy']['company'] == 'BAN' ? 'selected' : '' !!}>BAN</option>
                      <option value="HDI" {!! $data['policy']['company'] == 'HDI' ? 'selected' : '' !!}>HDI</option>
                      <option value="MAP" {!! $data['policy']['company'] == 'MAP' ? 'selected' : '' !!}>MAP</option>
                    </select>
                    <label>{{ __('locale.Company')}}</label>
				</div>
				<div class="col s12 m4 input-field">
					<input name="REC" type="text" class="validate" value="{{ $data['policy']['REC'] }}">
					<label>REC</label>
				</div>
				<div class="col s12 m4 input-field">
					<input name="DES" type="text" class="validate" value="{{ $data['policy']['DES'] }}">
					<label>DES</label>
				</div>
				<div class="col s12 m4 input-field">
					<input name="BON" type="text" class="validate" value="{{ $data['policy']['BON'] }}">
					<label>BON</label>
				</div>
				<div class="col s12 m6 l3 input-field">
					<input name="DER" type="text" class="validate" value="{{ $data['policy']['DER'] }}">
					<label>DER</label>
				</div>
				<div class="col s12 m6 l3 input-field">
					<input name="iva" type="text" class="validate" value="{{ $data['policy']['iva'] }}">
					<label>IVA</label>
				</div>
				<div class="col s12 m6 l3 input-field">
					<input name="pneta" type="text" class="validate" value="{{ $data['policy']['pneta'] }}">
					<label>Pneta</label>
				</div>
				<div class="col s12 m6 l3 input-field">
					<input name="ptotal" type="text" class="validate" value="{{ $data['policy']['ptotal'] }}">
					<label>Ptotal</label>
				</div>
				<div class="col s12 m6 l3 input-field">
					<input name="email" type="email" class="validate" value="{{ $data['policy']['email'] }}" disabled>
					<label>{{ __('locale.Email')}}</label>
				</div>
				<div class="col s12 m6 l3 input-field">
					<input name="cp" type="text" class="validate" value="{{ $data['policy']['postal_code'] }}">
					<label>{{ __('locale.CP')}}</label>
				</div>
				<div class="col s12 m6 l3 input-field">
					<input name="muni" type="text" class="validate" value="{{ $data['policy']['municipality'] }}">
					<label>Municipality</label>
				</div>
				<div class="col s12 m6 l3 input-field">
					<input name="colonia" type="text" class="validate" value="{{ $data['policy']['colonia'] }}">
					<label>Colonia</label>
				</div>
              <div class="col s12">
                <button type="submit" class="btn indigo" id="submit" style="display: none;"></button>
				<a class="btn cyan waves-effect waves-light modal-trigger right" href="#modal1">{{ __('locale.Save')}}</a>
				  <div id="modal1" class="modal">
					  <div class="modal-content">
						  <h4>{{ __('locale.Confirm_title')}}</h4>
						  <p>{{ __('locale.Confirm')}}</p>
					  </div>
					  <div class="modal-footer">
						  <a id="yes" class="modal-action modal-close btn cyan waves-effect waves-light">{{ __('locale.Yes')}}</a>
						  <a class="modal-action modal-close btn waves-effect waves-light">{{ __('locale.No')}}</a>
					  </div>
				  </div>
              </div>
            </div>
          </form>
          <!-- users edit account form ends -->
        </div>
      </div>
      <!-- </div> -->
    </div>
  </div>
</div>
<!-- users edit ends -->
@endsection

{{-- vendor scripts --}}
@section('vendor-script')
<script src="{{asset('vendors/select2/select2.full.min.js')}}"></script>
<script src="{{asset('vendors/jquery-validation/jquery.validate.min.js')}}"></script>
@endsection

{{-- page scripts --}}
@section('page-script')
<script src="{{asset('js/scripts/policy-edit.js')}}"></script>
<script src="{{asset('js/scripts/advance-ui-modals.js')}}"></script>
<script src="{{asset('js/scripts/edit.js')}}"></script>
@endsection