{{-- extend layout --}}
@extends('layouts.contentLayoutMaster')

{{-- page title --}}
@section('title','Account Settings')

{{-- vendor styles --}}
@section('vendor-style')
<link rel="stylesheet" type="text/css" href="{{asset('vendors/select2/select2.min.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('vendors/select2/select2-materialize.css')}}">
@endsection

{{-- page style --}}
@section('page-style')
<link rel="stylesheet" type="text/css" href="{{asset('css/pages/page-account-settings.css')}}">
@endsection

{{-- page content --}}
@section('content')
<!-- Account settings -->
<section class="tabs-vertical mt-1 section">
  <div class="row">
    <div class="col l4 s12">
      <!-- tabs  -->
      <div class="card-panel">
        <ul class="tabs">
          <li class="tab">
            <a href="#general">
              <i class="material-icons">brightness_low</i>
              <span>{{ __('locale.General')}}</span>
            </a>
          </li>
          <li class="tab">
            <a href="#change-password">
              <i class="material-icons">lock_open</i>
              <span>{{ __('locale.Password')}}</span>
            </a>
          </li>
        </ul>
      </div>
    </div>
    <div class="col l8 s12">
      <!-- tabs content -->
      <div id="general">
        <div class="card-panel">
			@if(session('success'))
			<div class="card-alert card green lighten-5">
				<div class="card-content green-text">
					<p>{{ __('locale.'. session('success'))}}</p>
				</div>
				<button type="button" class="close green-text" data-dismiss="alert" aria-label="Close">
					<span aria-hidden="true">×</span>
				</button>
			</div>
			@endif
			@if(session('error'))
			<div class="card-alert card red lighten-5">
				<div class="card-content red-text">
					<p>{{ __('locale.'. session('error'))}}</p>
				</div>
				<button type="button" class="close red-text" data-dismiss="alert" aria-label="Close">
					<span aria-hidden="true">×</span>
				</button>
			</div>
			@endif
          <div class="display-flex">
            <div class="media">
              <img id="account_image" src="{{asset('images/user/'. $data['user']->image)}}" class="border-radius-4" alt="profile image"
                height="64" width="64">
            </div>
            <div class="media-body">
              <div class="general-action-btn">
                <button id="select-files" class="btn indigo mr-2">
                  <span>{{ __('locale.Upload_photo')}}</span>
                </button>
              </div>
              <small>{{ __('locale.Photo_ref')}}</small>
              
            </div>
          </div>
          <div class="divider mb-1 mt-1"></div>
          <form class="formValidate" action="{{ route('account-general') }}" enctype="multipart/form-data" method="POST">
			{{ csrf_field() }}
			<div class="upfilewrapper">
			  <input id="upfile" accept="image/*" type="file" name="image" onchange="loadFile(event)"/>
			</div>
            <div class="row">
              <div class="col m6 s12">
                <div class="input-field">
                  <label for="name">{{ __('locale.Firstname')}}</label>
                  <input id="name" name="firstname" type="text" value="{{ $data['user']->firstname}}" data-error=".errorTxt2">
                  <small class="errorTxt2"></small>
                </div>
              </div>
			  <div class="col m6 s12">
                <div class="input-field">
                  <label for="lastname">{{ __('locale.Lastname')}}</label>
                  <input id="lastname" name="lastname" type="text" value="{{ $data['user']->lastname}}">
                </div>
              </div>
			  <div class="col m6 s12">
                <div class="input-field">
                  <label for="paternal_surname">{{ __('locale.Paternal')}}</label>
                  <input id="paternal_surname" name="paternal_surname" type="text" value="{{ $data['user']->paternal_surname}}">
                </div>
              </div>
			  <div class="col m6 s12">
                <div class="input-field">
                  <label for="maternal_surname">{{ __('locale.Maternal')}}</label>
                  <input id="maternal_surname" name="maternal_surname" type="text" value="{{ $data['user']->maternal_surname}}">
                </div>
              </div>
              <div class="col s12">
                <div class="input-field">
                  <label for="email">{{ __('locale.Email')}}</label>
                  <input id="email" type="email" name="email" value="{{ $data['user']->email}}" data-error=".errorTxt3">
                  <small class="errorTxt3"></small>
                </div>
              </div>
			  <!--
              <div class="col s12">
                <div class="card-alert card orange lighten-5">
                  <div class="card-content orange-text">
                    <p>Your email is not confirmed. Please check your inbox.</p>
                    <a href="javascript: void(0);">Resend confirmation</a>
                  </div>
                  <button type="button" class="close orange-text" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">×</span>
                  </button>
                </div>
              </div> -->
              <div class="col m6 s12">
                <div class="input-field">
                  <input id="pick-birthday" name="birthday" type="text" value="{{ $data['user']->birthday}}">
                  <label for="pick-birthday">{{ __('locale.Birthday')}}</label>
                </div>
              </div>
			  <div class="col m6 s12">
                <div class="input-field">
                  <label for="postal_code">{{ __('locale.CP')}}</label>
                  <input id="postal_code" name="postal_code" type="text" value="{{ $data['user']->postal_code}}">
                </div>
              </div>
			  <div class="col m6 s12">
				  <div class="input-field">
					  <select name="sex">
						  <option disabled {!! $data['user']->sex == null ? 'selected' : '' !!}>{{ __('locale.Select')}}</option>
						  <option value="male" {!! $data['user']->sex == 'male' ? 'selected' : '' !!}>{{ __('locale.Male')}}</option>
						  <option value="female" {!! $data['user']->sex == 'female' ? 'selected' : '' !!}>{{ __('locale.Female')}}</option>
					  </select>
					  <label>Sex</label>
				  </div>
			  </div>
			  <div class="col m6 s12">
				  <div class="input-field">
					  <select name="marital">
						  <option disabled {!! $data['user']->marital == null ? 'selected' : '' !!}>{{ __('locale.Select')}}</option>
						  <option value="1" {!! $data['user']->marital == '1' ? 'selected' : '' !!}>{{ __('locale.Married')}}</option>
						  <option value="2" {!! $data['user']->marital == '2' ? 'selected' : '' !!}>{{ __('locale.Single')}}</option>
						  <option value="3" {!! $data['user']->marital == '3' ? 'selected' : '' !!}>{{ __('locale.Widower')}}</option>
						  <option value="4" {!! $data['user']->marital == '4' ? 'selected' : '' !!}>{{ __('locale.Divorced')}}</option>
					  </select>
					  <label>{{ __('locale.Marital')}} {{ __('locale.Status')}}</label>
				  </div>
			  </div>
			  <div class="col s12">
                <div class="input-field">
					<textarea id="address" name="address" class="materialize-textarea">{{ $data['user']->address}}</textarea>
					<label for="addrss">{{ __('locale.Address')}}</label>
                </div>
              </div>
			  <div class="col m6 s12">
                <div class="input-field">
                  <input id="phone-num" name="phone" type="text" class="validate" value="{{ $data['user']->phone}}">
                  <label for="phone-num">{{ __('locale.Phone')}}</label>
                </div>
              </div>
			  <div class="col m6 s12">
                <div class="input-field">
                  <input id="telephone-num" name="tele" type="text" class="validate" value="{{ $data['user']->telephone}}">
                  <label for="telephone-num">{{ __('locale.Telephone')}}</label>
                </div>
              </div>
              <div class="col s12 display-flex justify-content-end form-action">
                <button type="submit" class="btn indigo waves-effect waves-light mr-2">
                  {{ __('locale.Save')}}
                </button>
                <button type="button" class="btn btn-light-pink waves-effect waves-light mb-1">{{ __('locale.Cancel')}}</button>
              </div>
            </div>
          </form>
        </div>
      </div>
      <div id="change-password">
        <div class="card-panel">
          <form class="paaswordvalidate" action="{{ asset('change-password') }}" method="POST">
			{{ csrf_field() }}
            <div class="row">
              <div class="col s12">
                <div class="input-field">
                  <input id="oldpswd" name="oldpswd" type="password" data-error=".errorTxt4">
                  <label for="oldpswd">{{ __('locale.Password')}} {{ __('locale.Old')}}</label>
                  <small class="errorTxt4"></small>
                </div>
              </div>
              <div class="col s12">
                <div class="input-field">
                  <input id="newpswd" name="newpswd" type="password" data-error=".errorTxt5">
                  <label for="newpswd">{{ __('locale.Password')}} {{ __('locale.New')}}</label>
                  <small class="errorTxt5"></small>
                </div>
              </div>
              <div class="col s12">
                <div class="input-field">
                  <input id="repswd" type="password" name="repswd" data-error=".errorTxt6">
                  <label for="repswd">{{ __('locale.Retype')}} {{ __('locale.Password')}} {{ __('locale.New')}}</label>
                  <small class="errorTxt6"></small>
                </div>
              </div>
              <div class="col s12 display-flex justify-content-end form-action">
                <button type="submit" class="btn indigo waves-effect waves-light mr-1">{{ __('locale.Save')}}</button>
                <button type="reset" class="btn btn-light-pink waves-effect waves-light">{{ __('locale.Cancel')}}</button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</section>
@endsection

{{-- page scripts --}}
@section('vendor-script')
<script src="{{asset('vendors/select2/select2.full.min.js')}}"></script>
<script src="{{asset('vendors/jquery-validation/jquery.validate.min.js')}}"></script>
@endsection

{{-- page script --}}
@section('page-script')
<script src="{{asset('js/scripts/account-settings.js')}}"></script>
<script>
	var loadFile = function(event) {
	var image = document.getElementById('account_image');
	image.src = URL.createObjectURL(event.target.files[0]);
};
</script>
@endsection