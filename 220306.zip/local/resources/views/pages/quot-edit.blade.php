{{-- layout --}}
@extends('layouts.contentLayoutMaster')

{{-- page title --}}
@section('title','Quotation Edit')

{{-- vendor styles --}}
@section('vendor-style')
<link rel="stylesheet" type="text/css" href="{{asset('vendors/select2/select2.min.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('vendors/select2/select2-materialize.css')}}">
@endsection

{{-- page style --}}
@section('page-style')
<link rel="stylesheet" type="text/css" href="{{asset('css/pages/page-users.css')}}">
@endsection

{{-- page content --}}
@section('content')
<!-- users edit start -->
<div class="section users-edit">
  <div class="card">
	  <div class="card-content">
		  <!-- users edit media object start -->
          <div class="media display-flex align-items-center mb-2">
            <div class="media-body">
              <h5 class="media-heading mt-0">{{ __('locale.Quotation')}}: {{ $data['quotes']['cot_id'] }}</h5>
            </div>
          </div>
		  @if(session('success'))
		  <div class="card-alert card green lighten-5">
			  <div class="card-content green-text">
				  <p>{{ __('locale.'. session('success'))}}</p>
			  </div>
			  <button type="button" class="close green-text" data-dismiss="alert" aria-label="Close">
				  <span aria-hidden="true">×</span>
			  </button>
		  </div>
		  @endif
	  </div>
  </div>
  <div class="card">
    <div class="card-content">
      <div class="row">
        <div class="col s12" id="account">
          <!-- users edit account form start -->
          <form id="accountForm" action="{{ asset('quot-update/') }}" method="POST">
			  {{ csrf_field() }}
			  <input name="id" type="hidden" value="{{ $data['quotes']['id'] }}">
            <div class="row">
				<div class="col s12 m6 l3 input-field">
					<input name="start_date" type="text" class="birthdate-picker datepicker"
                      value="{{ $data['quotes']['start_date'] }}" disabled>
                    <label>{{ __('locale.Start_date')}}</label>
				</div>
				<div class="col s12 m6 l3 input-field">
					<input name="end_date" type="text" class="birthdate-picker datepicker"
                      value="{{ $data['quotes']['end_date'] }}" disabled>
                    <label>{{ __('locale.End_date')}}</label>
				</div>
				<div class="col s12 m6 l3 input-field">
					<input name="brand" type="text" class="validate" value="{{ $data['quotes']['marca'] }}" disabled>
					<label>{{ __('locale.Brand')}}</label>
				</div>
				<div class="col s12 m6 l3 input-field">
					<input name="model" type="text" class="validate" value="{{ $data['quotes']['model'] }}" disabled>
					<label>{{ __('locale.Year')}}</label>
				</div>
				<div class="col s12 input-field">
					<input name="des" type="text" class="validate" value="{{ $data['quotes']['description'] }}" disabled>
					<label>{{ __('locale.Description')}}</label>
				</div>
				<div class="col s12 m3 input-field">
					<select name="paq" disabled>
					  <option value="1" {!! $data['quotes']['paq'] == '1' ? 'selected' : '' !!}>{{ __('locale.RC')}}</option>
                      <option value="2" {!! $data['quotes']['paq'] == '2' ? 'selected' : '' !!}>{{ __('locale.Limited')}}</option>
					  <option value="3" {!! $data['quotes']['paq'] == '3' ? 'selected' : '' !!}>{{ __('locale.Wide')}}</option>
                      <option value="460" {!! $data['quotes']['paq'] == '460' ? 'selected' : '' !!}>{{ __('locale.INTEGRAL')}}</option>
                    </select>
                    <label>{{ __('locale.Package')}}</label>
				</div>
				<div class="col s12 m3 input-field">
					<select name="fp">
                      <option value="12" {!! $data['quotes']['fp'] == '12' ? 'selected' : '' !!}>{{ __('locale.Annual')}}</option>
                      <option value="28" {!! $data['quotes']['fp'] == '28' ? 'selected' : '' !!}>{{ __('locale.Semi-annual')}}</option>
					  <option value="29" {!! $data['quotes']['fp'] == '29' ? 'selected' : '' !!}>{{ __('locale.Quarterly')}}</option>
                      <option value="27" {!! $data['quotes']['fp'] == '27' ? 'selected' : '' !!}>{{ __('locale.Monthly')}}</option>
                      <option value="25" {!! $data['quotes']['fp'] == '25' ? 'selected' : '' !!}>{{ __('locale.Biweekly')}}</option>
                    </select>
                    <label>{{ __('locale.Payment')}}</label>
				</div>
				<div class="col s12 m6 input-field">
					<input name="email" type="email" class="validate" value="{{ $data['quotes']['email'] }}" disabled>
					<label>{{ __('locale.Email')}}</label>
				</div>
				<div class="col s12 m6 l3 input-field">
					<input name="REC" type="text" class="validate" value="{{ $data['quotes']['REC'] }}" disabled>
					<label>REC</label>
				</div>
				<div class="col s12 m6 l3 input-field">
					<input name="iva" type="text" class="validate" value="{{ $data['quotes']['iva'] }}" disabled>
					<label>IVA</label>
				</div>
				<div class="col s12 m6 l3 input-field">
					<input name="pneta" type="text" class="validate" value="{{ $data['quotes']['pneta'] }}" disabled>
					<label>Pneta</label>
				</div>
				<div class="col s12 m6 l3 input-field">
					<input name="ptotal" type="text" class="validate" value="{{ $data['quotes']['ptotal'] }}" disabled>
					<label>Ptotal</label>
				</div>
				<div class="col s12 m4 input-field">
					<input name="DES" type="text" class="validate" value="{{ $data['quotes']['DES'] }}">
					<label>DES(%)</label>
				</div>
				<div class="col s12 m4 input-field">
					<input name="BON" type="text" class="validate" value="{{ $data['quotes']['BON'] }}">
					<label>BON(%)</label>
				</div>
				<div class="col s12 m4 input-field">
					<input name="DER" type="text" class="validate" value="{{ $data['quotes']['DER'] }}">
					<label>DER</label>
				</div>
              <div class="col s12">
                <button type="submit" class="btn indigo" id="submit" style="display: none;"></button>
				<a class="btn cyan waves-effect waves-light modal-trigger right" href="#modal1">{{ __('locale.Save')}}</a>
				  <div id="modal1" class="modal">
					  <div class="modal-content">
						  <h4>{{ __('locale.Confirm_title')}}</h4>
						  <p>{{ __('locale.Confirm')}}</p>
					  </div>
					  <div class="modal-footer">
						  <a id="yes" class="modal-action modal-close btn cyan waves-effect waves-light">{{ __('locale.Yes')}}</a>
						  <a class="modal-action modal-close btn waves-effect waves-light">{{ __('locale.No')}}</a>
					  </div>
				  </div>
              </div>
            </div>
          </form>
          <!-- users edit account form ends -->
        </div>
      </div>
      <!-- </div> -->
    </div>
  </div>
</div>
<!-- users edit ends -->
@endsection

{{-- vendor scripts --}}
@section('vendor-script')
<script src="{{asset('vendors/select2/select2.full.min.js')}}"></script>
<script src="{{asset('vendors/jquery-validation/jquery.validate.min.js')}}"></script>
@endsection

{{-- page scripts --}}
@section('page-script')
<script src="{{asset('js/scripts/advance-ui-modals.js')}}"></script>
<script src="{{asset('js/scripts/edit.js')}}"></script>
@endsection