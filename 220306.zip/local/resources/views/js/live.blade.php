(function($) {
	var val, sidebar, count,
		flag = 0, sms = '',
		currenturl = window.location.href,
		url_array = currenturl.split('/'),
		url = url_array[0] + '//' + url_array[2],
		newMessageAudio = new Audio('{{ asset('uploads/audio/new-message.mp3') }}');
	if(typeof(EventSource) !== "undefined") {
		var source = new EventSource('{{ route('Chatlive', array('quiet' => true)) }}');
		source.onmessage = function(event) {
			var pre_count = $('span#count').html();
			var to_user = $('p#to_user').html();
			count = JSON.parse(event.data).length;

			if(count == 0){
				val = 'chat_bubble_outline';
				sidebar = '<i class="material-icons">chat_bubble_outline</i><span class="menu-title">Chat</span>';
			} else if(count > 99){
				val = 'chat_bubble_outline<small class="notification-badge">99+</small>';
				sidebar = '<i class="material-icons">chat_bubble_outline</i><span class="menu-title">Chat</span><span class="badge pill pink float-right mr-10">99+</span>';
			} else{
				val = 'chat_bubble_outline<small class="notification-badge">'+ count +'</small>';
				sidebar = '<i class="material-icons">chat_bubble_outline</i><span class="menu-title">Chat</span><span class="badge pill pink float-right mr-10">'+ count +'</span>';
			}
			if(count > pre_count){
			   $('.chat-user').css('animation', 'none')
			   $.ajaxSetup({ headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') }});
			   $.ajax({ url:url+"/filter", data:{ name: ''}, type:'post',
					   success: function(result){
						   var as = '';
						   if(result.length != 0){
							   result.forEach(function(item) {
								   var image_url = url +'/images/user/'+ item[0]['image'];
								   if(item[1] == 'Null')
									   var last_message = "";
								   else
									   var last_message = item[1];
								   as += '<div class="chat-user animate fadeUp delay" id="'+ item[0]['email'] +'"><div class="user-section"><div class="row valign-wrapper"><div class="col s2 media-image online pr-0"><img src="'+ image_url +'" alt="" class="circle z-depth-2 responsive-img"></div><div class="col s10"><p class="m-0 blue-grey-text text-darken-4 font-weight-700">'+ item[0]['firstname'] +' '+ item[0]['lastname']+'</p><p class="m-0 info-text">'+ last_message +'</p></div></div></div><div class="info-section">';
								   if(item[2] != 0){
									   as +='<div class="star-timing"><div class="time"><span class="badge badge pill red">'+ item[2] +'</span></div></div></div></div>';
								   } else{
									   as += '<div class="star-timing"><div class="time"></div></div></div></div>';
								   }
							   });
						   }
						   $("div#chat-list").html(as);	
					   },
					   error: function(result){
						   console.log("failed");
					   }
				});
				//newMessageAudio.muted = true;
				//newMessageAudio.play();
				JSON.parse(event.data).forEach(function(item) {
					if(to_user == item['sender_id'] && item['flag'] == '0'){
						var img = $("p#img").html();
						sms = '<div class="chat"><div class="chat-avatar"><a class="avatar"><img src="'+ img +'" class="circle" alt="avatar" /></a></div><div class="chat-body"><div class="chat-text"><p>'+ item['message'] +'</p></div></div></div>';
					}
				});
				$("div#chat_content").append(sms);
				$(".chat-area").scrollTop($(".chat-area > .chats").height());
				
			}
			$('span#count').html(count);
			$('i#chat_new').html(val);
			$('a#insura-chats').html(sidebar);
		};
	} else {
		//$('div#result').innerHTML = "Sorry, your browser does not support server-sent events...";
	}
})(window.jQuery);