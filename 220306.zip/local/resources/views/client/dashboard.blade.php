{{-- extend layout --}}
@extends('layouts.contentLayoutMaster')

{{-- page title --}}
@section('title', 'Dashboard')

{{-- page style --}}
@section('page-style')
<link rel="stylesheet" type="text/css" href="{{asset('css/pages/dashboard.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('css/pages/page-users.css')}}">
@endsection

{{-- page content --}}
@section('content')
<div class="section">
   <!--card stats start-->
   <div id="card-stats" class="pt-0">
      <div class="row">
         <div class="col s12 m6 l6 xl3">
            <div class="card gradient-45deg-light-blue-cyan gradient-shadow min-height-100 white-text animate fadeLeft">
			   <a href="{{ asset('quot-list/'. date("Y"))}}" style="display: none;" id="quote"></a>
               <div class="padding-4" id="quote">
                  <div class="row">
                     <div class="col s7 m7">
                        <i class="material-icons background-round mt-5">note_add</i>
                        <p>{{ __('locale.Quotation')}}</p>
                     </div>
                     <div class="col s5 m5 right-align">
                        <h5 class="mb-0 white-text">{{ $data['new_quot']}}</h5>
                        <p class="no-margin">{{ __('locale.New')}}</p>
                        <p>{{ $data['total_quot']}}</p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
		  <div id="client" style="display: none;"></div>
         <div class="col s12 m6 l6 xl3">
            <div class="card gradient-45deg-red-pink gradient-shadow min-height-100 white-text animate fadeLeft">
               <div class="padding-4">
                  <div class="row">
                     <div class="col s7 m7">
                        <i class="material-icons background-round mt-5">note</i>
                        <p>{{ __('locale.Policy')}}</p>
                     </div>
                     <div class="col s5 m5 right-align">
                        <h5 class="mb-0 white-text" id="active_customer">{{ $data['new_pol']}}</h5>
                        <p class="no-margin">{{ __('locale.New')}}</p>
                        <p>{{ $data['total_pol']}}</p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="col s12 m6 l6 xl3">
            <div class="card gradient-45deg-amber-amber gradient-shadow min-height-100 white-text animate fadeRight">
               <div class="padding-4">
                  <div class="row">
                     <div class="col s7 m7">
                        <i class="material-icons background-round mt-5">sync</i>
                        <p>{{ __('locale.Purchase')}}</p>
                     </div>
                     <div class="col s5 m5 right-align">
						@php 
						 $sum = $data['total_pol'] + $data['total_quot'];
						 if($sum == 0){
						 	$percent = 0;
						 } else{
						 	$percent = $data['total_pol']*100/$sum;
						 }
						@endphp
                        <h5 class="mb-0 white-text">{{ $percent}}%</h5>
                        <p class="no-margin">{{ __('locale.Rate')}}</p>
                        <p>{{ $data['total_pol']}}</p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="col s12 m6 l6 xl3">
            <div class="card gradient-45deg-green-teal gradient-shadow min-height-100 white-text animate fadeRight">
               <div class="padding-4">
                  <div class="row">
                     <div class="col s7 m7">
                        <i class="material-icons background-round mt-5">attach_money</i>
                        <p>{{ __('locale.Payed')}}</p>
                     </div>
                     <div class="col s5 m5 right-align">
                        <h5 class="mb-0 white-text">${{ $data['payed']}}</h5>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<div class="section users-view">
   <!--card stats end-->
   <div class="card">
    <div class="card-content">
	  <div class="row indigo lighten-5 border-radius-4 mb-2">
        <div class="col s12 m6 users-view-timeline">
          <h6 class="indigo-text m-0">{{ __('locale.Quotation')}}: <span>{{ $data['quotes']->count()}}</span></h6>
        </div>
      </div>
      <div class="row">
        <div class="col s12">
          <table class="responsive-table">
            <thead>
              <tr>
                <th>{{ __('locale.ID')}}</th>
                    <th>{{ __('locale.Start_date')}}</th>
                    <th>{{ __('locale.Brand')}}</th>
                    <th>{{ __('locale.Year')}}</th>
                    <th>{{ __('locale.Package')}}</th>
                    <th>{{ __('locale.Payment')}}</th>
                    <th>Ptotal</th>
                    <th>{{ __('locale.Description')}}</th>
                    <th>PDF</th>
              </tr>
            </thead>
            <tbody>
				@foreach ($data['quotes'] as $quot)
				<tr>
					<td>{{ $quot['cot_id'] }}</td>
					<td>{{ $quot['start_date'] }}</td>
					<td>{{ $quot['marca'] }}</td>
					<td>{{ $quot['model'] }}</td>
					@if($quot['paq'] == 1)
					<td>{{ __('locale.Wide')}}</td>
					@elseif($quot['paq'] == 2)
					<td>{{ __('locale.Limited')}}</td>
					@elseif($quot['paq'] == 3)
					<td>{{ __('locale.RC')}}</td>
					@else
					<td>{{ __('locale.INTEGRAL')}}</td>
					@endif
					@if($quot['fp'] == 12)
					<td>{{ __('locale.Annual')}}</td>
					@elseif($quot['fp'] == 28)
					<td>{{ __('locale.Semi-annual')}}</td>
					@elseif($quot['fp'] == 29)
					<td>{{ __('locale.Quarterly')}}</td>
					@elseif($quot['fp'] == 27)
					<td>{{ __('locale.Monthly')}}</td>
					@else
					<td>{{ __('locale.Biweekly')}}</td>
					@endif
					<td>$ {{ $quot['ptotal'] }} |MXN</td>
					<td>{{ $quot['description'] }}</td>
					<td><a href="{{ route('quot-pdf', $quot['id']) }}" target="_blank"><i class="material-icons">picture_as_pdf</i></a></td>
				</tr>
				@endforeach
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="section users-view">
   <!--card stats end-->
   <div class="card">
    <div class="card-content">
	  <div class="row indigo lighten-5 border-radius-4 mb-2">
        <div class="col s12 m6 users-view-timeline">
          <h6 class="indigo-text m-0">{{ __('locale.Policy')}}: <span>{{ $data['policies']->count()}}</span></h6>
        </div>
      </div>
      <div class="row">
        <div class="col s12">
          <table class="responsive-table">
            <thead>
              <tr>
                <th>{{ __('locale.Policy')}} {{ __('locale.ID')}}</th>
                <th>{{ __('locale.Start_date')}}</th>
                <th>{{ __('locale.End_date')}}</th>
                <th>{{ __('locale.Brand')}}</th>
                <th>{{ __('locale.Year')}}</th>
                <th>{{ __('locale.Package')}}</th>
                <th>{{ __('locale.Payment')}}</th>
                <th>Ptotal</th>
                <th>{{ __('locale.Description')}}</th>
                <th>{{ __('locale.Status')}}</th>
                <th>PDF</th>
              </tr>
            </thead>
            <tbody>
			@foreach($data['policies'] as $policy)
              <tr>
                <td>{{$policy['cve']}}{{$policy['pol']}}</td>
                <td>{{$policy['start_date']}}</td>
                @if($policy['status'] == 1)
				  @if($policy['end_date'] > date('Y-m-d'))
				  <td><span class="task-cat cyan">{{ $policy['end_date'] }}</span></td>
				  @else
				  <td><span class="task-cat deep-orange accent-2">{{ $policy['end_date'] }}</span></td>
				  @endif
				  @else
				  <td><span class="task-cat red accent-2">{{ $policy['cancel_date'] }}</span></td>
				@endif
                <td>{{$policy['marca']}}</td>
                <td>{{$policy['model']}}</td>
                @if($policy['paq'] == 1)
				  <td>{{ __('locale.Wide')}}</td>
				  @elseif($policy['paq'] == 2)
				  <td>{{ __('locale.Limited')}}</td>
				  @elseif($policy['paq'] == 3)
				  <td>{{ __('locale.RC')}}</td>
				  @else
				  <td>{{ __('locale.INTEGRAL')}}</td>
				@endif
				@if($policy['fp'] == 12)
				  <td>{{ __('locale.Annual')}}</td>
				  @elseif($policy['fp'] == 28)
				  <td>{{ __('locale.Semi-annual')}}</td>
				  @elseif($policy['fp'] == 29)
				  <td>{{ __('locale.Quarterly')}}</td>
				  @elseif($policy['fp'] == 27)
				  <td>{{ __('locale.Monthly')}}</td>
				  @else
				  <td>{{ __('locale.Biweekly')}}</td>
				@endif
                <td>${{$policy['ptotal']}} |MXN</td>
                <td>{{$policy['description']}}</td>
				@if($policy['status'] == 1)
				  @if($policy['end_date'] > date('Y-m-d'))
				  <td><span class="task-cat cyan">{{ __('locale.Valid')}}</span></td>
				  @else
				  <td><span class="task-cat deep-orange accent-2">{{ __('locale.Expired')}}</span></td>
				  @endif
				  @else
				  <td><span class="task-cat red accent-2">{{ __('locale.Canceled')}}</span></td>
				@endif
				<td><a href="{{ route('policy-pdf', $policy['id']) }}" target="_blank"><i class="material-icons">picture_as_pdf</i></a></td>
              </tr>
			@endforeach
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
@endsection

{{-- vendor script --}}
@section('vendor-script')
<script src="{{asset('vendors/chartjs/chart.min.js')}}"></script>
@endsection

{{-- page script --}}
@section('page-script')
<script src="{{asset('vendors/sortable/jquery-sortable-min.js')}}"></script>
<script src="{{asset('js/scripts/redirect.js')}}"></script>
@endsection