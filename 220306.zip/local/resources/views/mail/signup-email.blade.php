Hola {{ $email_data['name'] }}
<br><br>
Bienvenido a visitar nuestro sitio.
<br>
Estamos asombrados de que seas parte de nuestra familia.
<br>
Por favor confirmar.
<br>
<a href="{{asset('verify?code=' . $email_data['verification_code'])}}">Click Here!</a>
<br><br>
¡Gracias!