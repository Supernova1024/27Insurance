<!DOCTYPE html>
<html>
<head>
	<title>mail</title>
</head>
<body>
	<table style="border-collapse:collapse;width:100%;background:#f5f5f5;padding:30px 0 30px 0;margin:0 auto">
        <tbody>
            <tr>
                <td align="center">
                    <table border="0" cellspacing="0" cellpadding="0" style="max-width:700px;width:100%;border-collapse:collapse;margin:0 auto">
                        <tbody>
                            <tr bgcolor="#ffffff"><td align="center" style="padding:30px 0 40px 0"><table border="0" cellspacing="0" cellpadding="0" style="width:100%"><tbody><tr><td align="center"><img src="{{ asset('images/mail/seguros_acv.png')}}" style="height:40px!important;max-height:40px" class="CToWUd"></td></tr></tbody></table></td></tr>
                            <tr bgcolor="#ffffff">
                                <td align="center" style="padding:0 0 30px 0">
                                    <table border="0" cellspacing="0" cellpadding="0" style="width:70%;color:#39527c;font-family:Helvetica;font-size:28px;font-weight:bold;line-height:34px">
                                        <tbody>
                                            <tr>
                                                <td align="center">
                                                    <span>
                                                        Su póliza de seguro de automóvil vencerá
                                                    </span>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>

                            <tr bgcolor="#ffffff">
                                <td align="center" style="padding:0 0 40px 0">
                                    <table border="0" cellspacing="0" cellpadding="0" style="width:70%">
                                        <tbody>
                                            <tr>
                                                <td align="center">
                                                    <img src="{{ asset('images/mail/expired.png')}}" style="width:100%!important" class="CToWUd a6T" tabindex="0"><div class="a6S" dir="ltr" style="opacity: 0.01; left: 772px; top: 408px;"><div id=":10p" class="T-I J-J5-Ji aQv T-I-ax7 L3 a5q" role="button" tabindex="0" aria-label="Download attachment " data-tooltip-class="a1V" data-tooltip="Download"><div class="akn"><div class="aSK J-J5-Ji aYr"></div></div></div></div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>


                            <tr bgcolor="#ffffff">
                                <td align="center" style="padding:0 0 50px 0">
                                    <table border="0" cellspacing="0" cellpadding="0" style="width:70%;color:#5e6a7e;font-family:Helvetica;font-size:18px;font-weight:normal;line-height:26px;text-align:left">
                                        <tbody>
                                            <tr>
                                                <td align="left">
                                                    <span style="font-weight:bold">
                                                        Hola, {{ $name}}.
                                                    </span>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td align="left">
                                                    <span>
                                                        Le informo que su póliza {{$pol}}{{ $pol_num}} está próxima a fin de vigencia: {{ $endDate}}.
                                                        <br>
                                                    </span>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>

                            <tr bgcolor="#ffffff">
                                <td align="center" style="padding:0 0 50px 0">
                                    <table border="0" cellspacing="0" cellpadding="0" style="width:70%">
                                        <tbody>
                                            <tr>
                                                <td align="center">
                                                    <table border="0" cellspacing="0" cellpadding="0" style="width:300px">
                                                        <tbody>
                                                            <tr>
                                                                <td style="background-color:#fa6609;border-radius:34px;padding:15px 0 15px 0;width:100%" align="center">
                                                                    <a href="{{ asset('policy-pdf/'. $pol_id)}}" style="text-decoration:none" target="_blank">
                                                                        <span style="color:#ffffff;font-family:Helvetica;font-weight:bold;line-height:31px;font-size:24px;text-decoration:none;text-align:center">
                                                                            Ver Póliza
                                                                        </span>
                                                                    </a>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>

                            <tr bgcolor="#ffffff">
                                <td align="center" style="padding:0 0 50px 0">
                                    <table border="0" cellspacing="0" cellpadding="0" style="width:70%;color:#5e6a7e;font-family:Helvetica;font-size:18px;font-weight:normal;line-height:22px;text-align:left">
                                        <tbody>
                                            <tr>
                                                <td align="left">
                                                    <span>
                                                        Le informamos que se renueva de forma automática, así procuramos la continuidad de cobertura de su patrimonio.
                                                        <br>
														En próximos días informaremos su nuevo número de póliza por los medios de comunicación que tenemos registrados.
														<br>
														<br>
                                                        CAROV - Asesores en Seguros
                                                    </span>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>

                            <tr bgcolor="#ffffff">
                                <td align="center" style="padding:0">
                                    <table border="0" cellspacing="0" cellpadding="0" style="width:100%;background-color:#fafafa;padding:40px 10%">
                                        <tbody>
                                            <tr>
                                                <td align="center" style="width:40%">
                                                    <div style="height:100px;width:100px;background-image:url({{ asset('images/mail/small_logo.png')}});background-position:center!important;background-size:cover!important">
                                                    </div>
                                                </td>
                                                <td align="left" style="width:60%">
                                                    <table border="0" cellspacing="0" cellpadding="0" style="width:100%;color:#445065;font-family:Helvetica;font-size:14px;font-weight:normal;letter-spacing:0;line-height:20px">
                                                        <tbody><tr>
                                                            <td style="padding-bottom:10px">
                                                                <span style="font-size:18px;font-weight:bold">Seguros ACV</span>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td style="padding-bottom:5px">
                                                                <img src="{{ asset('images/mail/whatsapp.png')}}" style="height:16px!important;width:16px!important;max-width:16px" class="CToWUd">
                                                                &nbsp;
                                                                <span><a href="tel:3335876688" target="_blank">(33) 3587-6688</a></span>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td style="padding-bottom:8px">
                                                                <img src="{{ asset('images/mail/mail.png')}}" style="height:12px!important;width:16px!important;max-width:16px" class="CToWUd">
                                                                &nbsp;
                                                                <span><a href="mailto:contacto@segurosacv.com" target="_blank">contacto@segurosacv.com</a></span>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td>
                                                                <img src="{{ asset('images/mail/location.png')}}" style="height:16px!important;width:12px!important;max-width:16px" class="CToWUd">
                                                                &nbsp;
                                                                <span>Av. Chapultepec No. 120 int. Piso 4, CP 44600 Ladrón de Guevara, Guadalajara, Jalisco</span>
                                                            </td>
                                                        </tr>
                                                    </tbody></table>

                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                            <tr bgcolor="#ffffff">
                                <td align="center" style="padding:0">
                                    <table border="0" cellspacing="0" cellpadding="0" style="width:100%;background-color:#cce2ff">
                                        <tbody>
                                            <tr>
                                                <td align="center" style="padding:24px 0 24px 0">
                                                    <a href="{{ asset('/')}}" style="text-decoration:none" target="_blank">
                                                        <span style="color:#5c5f60;font-family:Helvetica;font-size:14px;font-weight:bold;letter-spacing:0;line-height:20px">© 2021 Copyright SegurosACV</span>
                                                    </a>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </td>
            </tr>
        </tbody>
    </table>
</body>
</html>