<!DOCTYPE html>
<html>
<head>
	<title>Send Email</title>
</head>
<body>
	{{ $sms}}
</body>
</html>