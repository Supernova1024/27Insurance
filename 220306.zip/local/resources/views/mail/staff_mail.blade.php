<!DOCTYPE html>
<html>
<head>
	<title>Client mail</title>
</head>
<body>
	<table style="border-collapse: collapse; width: 100%; background: #f5f5f5; padding: 30px 0 30px 0; margin: 0 auto;">
	    <tbody>
	        <tr>
	            <td align="center">
	                <table border="0" cellspacing="0" cellpadding="0" style="max-width: 700px; width: 100%; border-collapse: collapse; margin: 0 auto;">
	                    <tbody>
	                        <tr bgcolor="#ffffff">
	                            <td align="center" style="padding: 0;">
	                                <table border="0" cellspacing="0" cellpadding="0" style="width: 100%; background-color: #fafafa;">
	                                    <tbody>
	                                        <tr>
	                                            <td align="center">
	                                                <img
	                                                    style="width: 100% !important;"
	                                                    src="{{ asset('images/mail/client_image.png')}}"
	                                                    class="CToWUd a6T"
	                                                    tabindex="0"
	                                                />
	                                                <div class="a6S" dir="ltr" style="opacity: 1; left: 877px; top: 558px;">
	                                                    <div id=":1dm" class="T-I J-J5-Ji aQv T-I-ax7 L3 a5q" role="button" tabindex="0" aria-label="Download attachment " data-tooltip-class="a1V" data-tooltip="Download">
	                                                        <div class="akn"><div class="aSK J-J5-Ji aYr"></div></div>
	                                                    </div>
	                                                </div>
	                                            </td>
	                                        </tr>
	                                    </tbody>
	                                </table>
	                            </td>
	                        </tr>
	                        <tr bgcolor="#ffffff">
	                            <td align="center" style="padding: 50px 0 40px 0;">
	                                <table border="0" cellspacing="0" cellpadding="0" style="width: 70%; color: #5e6a7e; font-family: Helvetica; font-size: 20px; font-weight: normal; line-height: 33px;">
	                                    <tbody>
	                                        <tr>
	                                            <td align="left"><span style="color: #fa6609; font-weight: bold; font-size: 28px;">Hola Leonardo, </span></td>
	                                        </tr>
	                                        <tr>
	                                            <td align="left">
	                                                <span>
	                                                    <br />
	                                                    Tienes nuevos contactos y cotizaciones en tu portal de agente…
	                                                </span>
	                                            </td>
	                                        </tr>
	                                    </tbody>
	                                </table>
	                            </td>
	                        </tr>
	                        <tr bgcolor="#ffffff">
	                            <td align="center" style="padding: 0 0 50px 0;">
	                                <table border="0" cellspacing="0" cellpadding="0" style="width: 70%;">
	                                    <tbody>
	                                        <tr>
	                                            <td align="center">
	                                                <table border="0" cellspacing="0" cellpadding="0" style="width: 224px;">
	                                                    <tbody>
	                                                        <tr>
	                                                            <td style="background-color: #006fff; border-radius: 34px; padding: 15px 0 15px 0; width: 100%;" align="center">
	                                                                <a
	                                                                    href="{{ asset('client-view/'. $client_id)}}"
	                                                                    style="text-decoration: none;"
	                                                                    rel="noreferrer noreferrer"
	                                                                    target="_blank"
	                                                                >
	                                                                    <span style="color: #ffffff; font-family: Helvetica; font-weight: bold; line-height: 24px; font-size: 20px; text-decoration: none; text-align: center;">
	                                                                        Accede a tu CRM
	                                                                    </span>
	                                                                </a>
	                                                            </td>
	                                                        </tr>
	                                                    </tbody>
	                                                </table>
	                                            </td>
	                                        </tr>
	                                    </tbody>
	                                </table>
	                            </td>
	                        </tr>
	                        <tr bgcolor="#ffffff">
	                            <td align="center" style="padding: 0 0 50px 0; border-radius: 10px 10px 0 0;">
	                                <table border="0" cellspacing="0" cellpadding="0" style="width: 70%; border-bottom: 2px solid #e7eaee;">
	                                    <tbody></tbody>
	                                </table>
	                            </td>
	                        </tr>
	                        <tr bgcolor="#ffffff">
	                            <td align="center" style="padding: 0 0 50px 0;">
	                                <table border="0" cellspacing="0" cellpadding="0" style="width: 100%;">
	                                    <tbody>
	                                        <tr>
	                                            <td align="center">
	                                                <img
	                                                    style="width: 97px !important;"
	                                                    src="{{ asset('images/mail/crm.png')}}"
	                                                    class="CToWUd"
	                                                />
	                                            </td>
	                                        </tr>
	                                    </tbody>
	                                </table>
	                            </td>
	                        </tr>
	                        <tr bgcolor="#ffffff">
	                            <td align="center" style="padding: 0 0 70px 0;">
	                                <table border="0" cellspacing="0" cellpadding="0" style="width: 70%; color: #5e6a7e; font-family: Helvetica; font-size: 18px; font-weight: normal; line-height: 22px; text-align: left;">
	                                    <tbody>
	                                        <tr>
	                                            <td align="left" colspan="2" style="font-size: 20px; font-weight: bold; line-height: 24px;">
	                                                <span>Resumen</span>
	                                            </td>
	                                        </tr>
	                                        <tr>
	                                            <td align="left" style="padding: 30px 0 20px 0;">
	                                                <img
	                                                    style="height: 18px !important; width: 18px !important; max-width: 18px; vertical-align: bottom;"
	                                                    src="{{ asset('images/mail/user.png')}}"
	                                                    class="CToWUd"
	                                                />
	                                                &nbsp; <span style="font-weight: bold; vertical-align: top;"> <?php echo $name; ?> </span><br />
	                                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="tel:<?php echo $phone_num; ?>" style="text-decoration: none; color: #5e6a7e;" rel="noreferrer noreferrer" target="_blank"> <span style="vertical-align: top;"><?php echo $phone_num; ?> </span></a>
	                                                
	                                            </td>
	                                            <td align="right" style="width: 40%;">
													@php $year = date('Y'); @endphp
	                                                <a
	                                                    href="{{ asset('quot-list/'. $year)}}"
	                                                    style="text-decoration: none; color: #fc8f22; font-size: 16px; font-weight: bold; letter-spacing: 0; line-height: 19px;"
	                                                    rel="noreferrer noreferrer"
	                                                    target="_blank"
	                                                >
	                                                    Ir a contacto
	                                                </a>
	                                            </td>
	                                        </tr>
	                                        <tr>
	                                            <td align="left" colspan="2">
	                                                <img
	                                                    style="height: 18px !important; width: 18px !important; max-width: 18px; vertical-align: top;"
	                                                    src="{{ asset('images/mail/car_icon.png')}}"
	                                                    class="CToWUd"
	                                                />
	                                                &nbsp; <span style="vertical-align: top;"><?php echo $description; ?> </span>
	                                            </td>
	                                        </tr>
	                                    </tbody>
	                                </table>
	                            </td>
	                        </tr>
	                        <tr bgcolor="#ffffff">
	                            <td align="center" style="padding: 0 0 70px 0;">
	                                <table border="0" cellspacing="0" cellpadding="0" style="width: 70%; color: #5e6a7e; font-family: Helvetica; font-size: 22px; font-weight: bold; line-height: 26px; text-align: left;">
	                                    <tbody>
	                                        <tr>
	                                            <td align="left" style="font-size: 18px; font-weight: normal; line-height: 24px;">
	                                                <span>
	                                                    Cordialmente, <br />
	                                                    <br />
	                                                    <b>El Equipo de SegurosACV.</b>
	                                                </span>
	                                            </td>
	                                        </tr>
	                                    </tbody>
	                                </table>
	                            </td>
	                        </tr>
	                        <tr bgcolor="#ffffff">
	                            <td align="center" style="padding: 0 0 20px 0; border-radius: 10px 10px 0 0;">
	                                <table border="0" cellspacing="0" cellpadding="0" style="width: 70%; border-bottom: 2px solid #e7eaee;">
	                                    <tbody></tbody>
	                                </table>
	                            </td>
	                        </tr>
	                        <tr bgcolor="#ffffff">
	                            <td align="center" style="padding: 40px 0 50px 0;">
	                                <table border="0" cellspacing="0" cellpadding="0" style="width: 100%;">
	                                    <tbody>
	                                        <tr>
	                                            <td align="center" style="padding: 0 0 0 0;">
	                                                <a
	                                                    href="https://www.facebook.com/"
	                                                    style="text-decoration: none;"
	                                                    rel="noreferrer noreferrer"
	                                                    target="_blank"
	                                                >
	                                                    <img
	                                                        style="height: 26px !important; width: 26px !important; max-width: 26px;"
	                                                        src="{{ asset('images/mail/facebook_icon.png')}}"
	                                                        class="CToWUd"
	                                                    />
	                                                </a>
	                                                &nbsp;
	                                                <a
	                                                    href="https://www.instagram.com/"
	                                                    style="text-decoration: none;"
	                                                    rel="noreferrer noreferrer"
	                                                    target="_blank"
	                                                >
	                                                    <img
	                                                        style="height: 26px !important; width: 26px !important; max-width: 26px;"
	                                                        src="{{ asset('images/mail/twitter_icon.png')}}"
	                                                        class="CToWUd"
	                                                    />
	                                                </a>
	                                                &nbsp;
	                                                <a
	                                                    href="https://www.linkedin.com/"
	                                                    style="text-decoration: none;"
	                                                    rel="noreferrer noreferrer"
	                                                    target="_blank"
	                                                >
	                                                    <img
	                                                        style="height: 26px !important; width: 26px !important; max-width: 26px;"
	                                                        src="{{ asset('images/mail/instagram_icon.png')}}"
	                                                        class="CToWUd"
	                                                    />
	                                                </a>
	                                                &nbsp;
	                                                <a
	                                                    href="https://twitter.com/"
	                                                    style="text-decoration: none;"
	                                                    rel="noreferrer noreferrer"
	                                                    target="_blank"
	                                                >
	                                                    <img
	                                                        style="height: 26px !important; width: 26px !important; max-width: 26px;"
	                                                        src="{{ asset('images/mail/linkedin_icon.png')}}"
	                                                        class="CToWUd"
	                                                    />
	                                                </a>
	                                            </td>
	                                        </tr>
	                                        <tr>
	                                            <td align="center" style="padding: 22px 0 0 0;">
	                                                <table border="0" cellspacing="0" cellpadding="0" width="100%">
	                                                    <tbody>
	                                                        <tr>
	                                                            <td align="right" style="width: 50%; padding-right: 10px;">
	                                                                <img
	                                                                    style="height: 22px !important; width: 22px !important; max-width: 22px; vertical-align: bottom;"
	                                                                    src="{{ asset('images/mail/whatsapp.png')}}"
	                                                                    class="CToWUd"
	                                                                />
	                                                                &nbsp;
	                                                                <a
	                                                                    href="tel:3335876688"
	                                                                    style="text-decoration: none; width: 124px; height: 22px !important;"
	                                                                    rel="noreferrer noreferrer"
	                                                                    target="_blank"
	                                                                >
	                                                                    <span style="color: #5c5f60; font-family: Helvetica; font-size: 14px; letter-spacing: 0; line-height: 24px;">33 3587 6688</span>
	                                                                </a>
	                                                            </td>
	                                                            <td align="left" style="width: 50%; padding-left: 10px;">
	                                                                <img
	                                                                    style="height: 22px !important; width: 22px !important; max-width: 22px; vertical-align: bottom;"
	                                                                    src="{{ asset('images/mail/website.png')}}"
	                                                                    class="CToWUd"
	                                                                />
	                                                                &nbsp;
	                                                                <a
	                                                                    href="{{ asset('/')}}"
	                                                                    style="text-decoration: none; width: 124px; height: 22px !important;"
	                                                                    rel="noreferrer noreferrer"
	                                                                    target="_blank"
	                                                                >
	                                                                    <span style="color: #5c5f60; font-family: Helvetica; font-size: 14px; letter-spacing: 0; line-height: 22px;">segurosacv.com/</span>
	                                                                </a>
	                                                            </td>
	                                                        </tr>
	                                                    </tbody>
	                                                </table>
	                                            </td>
	                                        </tr>
	                                        <tr>
	                                            <td align="center" style="padding: 24px 0 0 0;">
	                                                <a
	                                                    href="{{ asset('/')}}"
	                                                    style="text-decoration: none;"
	                                                    rel="noreferrer noreferrer"
	                                                    target="_blank"
	                                                >
	                                                    <span style="color: #5c5f60; font-family: Helvetica; font-size: 14px; font-weight: bold; letter-spacing: 0; line-height: 20px;">© 2021 Copyright SegurosACV</span>
	                                                </a>
	                                            </td>
	                                        </tr>
	                                    </tbody>
	                                </table>
	                            </td>
	                        </tr>
	                    </tbody>
	                </table>
	            </td>
	        </tr>
	    </tbody>
	</table>

</body>
</html>