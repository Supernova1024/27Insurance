<div class="collapsible-body">
	@php $year = date('Y'); @endphp
  <ul class="collapsible collapsible-sub" data-collapsible="accordion">
    @foreach ($menu as $submenu)
      @php
        $custom_classes="";
        if(isset($submenu->class))
        {
        $custom_classes = $submenu->class;
        }
      @endphp
      <li class="{{(request()->is($submenu->url.'*')) ? 'active' : '' }}">
        <a id="{{$submenu->url}}" href="@if(($submenu->url) === 'javascript:void(0)'){{$submenu->url}} @elseif(($submenu->url) == 'quot-list' || ($submenu->url) == 'policy-list'){{url($submenu->url. '/' . $year)}} @else{{url($submenu->url)}} @endif"
          class="{{$custom_classes}} {{(request()->is($submenu->url.'*')) ? 'active '.$configData['activeMenuColor'] : '' }}"
          @if(!empty($configData['activeMenuColor'])) {{'style=background:none;box-shadow:none;'}} @endif
          {{isset($submenu->newTab) ? 'target="_blank"':''}}>
          <i class="material-icons">radio_button_unchecked</i>
          <span>{{ __('locale.'.$submenu->name)}}</span>
		  @if(($submenu->url) == 'quot_notify' && ($notify['new_quot']) > 0)
          <span class="badge pill purple float-right mr-10">{{$notify['new_quot']}}</span>
          @endif
		  @if(($submenu->url) == 'new' && ($notify['new']) > 0)
          <span class="badge pill pink float-right mr-10">{{$notify['new']}}</span>
          @endif
		  @if(($submenu->url) == 'expired' && ($notify['expired']) > 0)
          <span class="badge pill orange float-right mr-10">{{$notify['expired']}}</span>
          @endif
		  @if(($submenu->url) == 'canceled' && ($notify['canceled']) > 0)
          <span class="badge pill pink float-right mr-10">{{$notify['canceled']}}</span>
          @endif
        </a>
        @if (isset($submenu->submenu))
          @include('panels.submenu', ['menu' => $submenu->submenu])
        @endif
      </li>
    @endforeach
  </ul>
</div>