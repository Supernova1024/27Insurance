<?php $__env->startSection('title', 'Dashboard'); ?>


<?php $__env->startSection('page-style'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/pages/dashboard.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/pages/page-users.css')); ?>">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="section">
   <!--card stats start-->
   <div id="card-stats" class="pt-0">
      <div class="row">
         <div class="col s12 m6 l6 xl3">
            <div class="card gradient-45deg-light-blue-cyan gradient-shadow min-height-100 white-text animate fadeLeft">
			   <a href="<?php echo e(asset('quot-list/'. date("Y"))); ?>" style="display: none;" id="quote"></a>
               <div class="padding-4" id="quote">
                  <div class="row">
                     <div class="col s7 m7">
                        <i class="material-icons background-round mt-5">note_add</i>
                        <p><?php echo e(__('locale.Quotation')); ?></p>
                     </div>
                     <div class="col s5 m5 right-align">
                        <h5 class="mb-0 white-text"><?php echo e($data['new_quot']); ?></h5>
                        <p class="no-margin"><?php echo e(__('locale.New')); ?></p>
                        <p><?php echo e($data['total_quot']); ?></p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
		  <div id="client" style="display: none;"></div>
         <div class="col s12 m6 l6 xl3">
            <div class="card gradient-45deg-red-pink gradient-shadow min-height-100 white-text animate fadeLeft">
               <div class="padding-4">
                  <div class="row">
                     <div class="col s7 m7">
                        <i class="material-icons background-round mt-5">note</i>
                        <p><?php echo e(__('locale.Policy')); ?></p>
                     </div>
                     <div class="col s5 m5 right-align">
                        <h5 class="mb-0 white-text" id="active_customer"><?php echo e($data['new_pol']); ?></h5>
                        <p class="no-margin"><?php echo e(__('locale.New')); ?></p>
                        <p><?php echo e($data['total_pol']); ?></p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="col s12 m6 l6 xl3">
            <div class="card gradient-45deg-amber-amber gradient-shadow min-height-100 white-text animate fadeRight">
               <div class="padding-4">
                  <div class="row">
                     <div class="col s7 m7">
                        <i class="material-icons background-round mt-5">sync</i>
                        <p><?php echo e(__('locale.Purchase')); ?></p>
                     </div>
                     <div class="col s5 m5 right-align">
						<?php 
						 $sum = $data['total_pol'] + $data['total_quot'];
						 if($sum == 0){
						 	$percent = 0;
						 } else{
						 	$percent = $data['total_pol']*100/$sum;
						 }
						?>
                        <h5 class="mb-0 white-text"><?php echo e($percent); ?>%</h5>
                        <p class="no-margin"><?php echo e(__('locale.Rate')); ?></p>
                        <p><?php echo e($data['total_pol']); ?></p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="col s12 m6 l6 xl3">
            <div class="card gradient-45deg-green-teal gradient-shadow min-height-100 white-text animate fadeRight">
               <div class="padding-4">
                  <div class="row">
                     <div class="col s7 m7">
                        <i class="material-icons background-round mt-5">attach_money</i>
                        <p><?php echo e(__('locale.Payed')); ?></p>
                     </div>
                     <div class="col s5 m5 right-align">
                        <h5 class="mb-0 white-text">$<?php echo e($data['payed']); ?></h5>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<div class="section users-view">
   <!--card stats end-->
   <div class="card">
    <div class="card-content">
	  <div class="row indigo lighten-5 border-radius-4 mb-2">
        <div class="col s12 m6 users-view-timeline">
          <h6 class="indigo-text m-0"><?php echo e(__('locale.Quotation')); ?>: <span><?php echo e($data['quotes']->count()); ?></span></h6>
        </div>
      </div>
      <div class="row">
        <div class="col s12">
          <table class="responsive-table">
            <thead>
              <tr>
                <th><?php echo e(__('locale.ID')); ?></th>
                    <th><?php echo e(__('locale.Start_date')); ?></th>
                    <th><?php echo e(__('locale.Brand')); ?></th>
                    <th><?php echo e(__('locale.Year')); ?></th>
                    <th><?php echo e(__('locale.Package')); ?></th>
                    <th><?php echo e(__('locale.Payment')); ?></th>
                    <th>Ptotal</th>
                    <th><?php echo e(__('locale.Description')); ?></th>
                    <th>PDF</th>
              </tr>
            </thead>
            <tbody>
				<?php $__currentLoopData = $data['quotes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($quot['cot_id']); ?></td>
					<td><?php echo e($quot['start_date']); ?></td>
					<td><?php echo e($quot['marca']); ?></td>
					<td><?php echo e($quot['model']); ?></td>
					<?php if($quot['paq'] == 1): ?>
					<td><?php echo e(__('locale.Wide')); ?></td>
					<?php elseif($quot['paq'] == 2): ?>
					<td><?php echo e(__('locale.Limited')); ?></td>
					<?php elseif($quot['paq'] == 3): ?>
					<td><?php echo e(__('locale.RC')); ?></td>
					<?php else: ?>
					<td><?php echo e(__('locale.INTEGRAL')); ?></td>
					<?php endif; ?>
					<?php if($quot['fp'] == 12): ?>
					<td><?php echo e(__('locale.Annual')); ?></td>
					<?php elseif($quot['fp'] == 28): ?>
					<td><?php echo e(__('locale.Semi-annual')); ?></td>
					<?php elseif($quot['fp'] == 29): ?>
					<td><?php echo e(__('locale.Quarterly')); ?></td>
					<?php elseif($quot['fp'] == 27): ?>
					<td><?php echo e(__('locale.Monthly')); ?></td>
					<?php else: ?>
					<td><?php echo e(__('locale.Biweekly')); ?></td>
					<?php endif; ?>
					<td>$ <?php echo e($quot['ptotal']); ?> |MXN</td>
					<td><?php echo e($quot['description']); ?></td>
					<td><a href="<?php echo e(route('quot-pdf', $quot['id'])); ?>" target="_blank"><i class="material-icons">picture_as_pdf</i></a></td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="section users-view">
   <!--card stats end-->
   <div class="card">
    <div class="card-content">
	  <div class="row indigo lighten-5 border-radius-4 mb-2">
        <div class="col s12 m6 users-view-timeline">
          <h6 class="indigo-text m-0"><?php echo e(__('locale.Policy')); ?>: <span><?php echo e($data['policies']->count()); ?></span></h6>
        </div>
      </div>
      <div class="row">
        <div class="col s12">
          <table class="responsive-table">
            <thead>
              <tr>
                <th><?php echo e(__('locale.Policy')); ?> <?php echo e(__('locale.ID')); ?></th>
                <th><?php echo e(__('locale.Start_date')); ?></th>
                <th><?php echo e(__('locale.End_date')); ?></th>
                <th><?php echo e(__('locale.Brand')); ?></th>
                <th><?php echo e(__('locale.Year')); ?></th>
                <th><?php echo e(__('locale.Package')); ?></th>
                <th><?php echo e(__('locale.Payment')); ?></th>
                <th>Ptotal</th>
                <th><?php echo e(__('locale.Description')); ?></th>
                <th><?php echo e(__('locale.Status')); ?></th>
                <th>PDF</th>
              </tr>
            </thead>
            <tbody>
			<?php $__currentLoopData = $data['policies']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $policy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($policy['cve']); ?><?php echo e($policy['pol']); ?></td>
                <td><?php echo e($policy['start_date']); ?></td>
                <?php if($policy['status'] == 1): ?>
				  <?php if($policy['end_date'] > date('Y-m-d')): ?>
				  <td><span class="task-cat cyan"><?php echo e($policy['end_date']); ?></span></td>
				  <?php else: ?>
				  <td><span class="task-cat deep-orange accent-2"><?php echo e($policy['end_date']); ?></span></td>
				  <?php endif; ?>
				  <?php else: ?>
				  <td><span class="task-cat red accent-2"><?php echo e($policy['cancel_date']); ?></span></td>
				<?php endif; ?>
                <td><?php echo e($policy['marca']); ?></td>
                <td><?php echo e($policy['model']); ?></td>
                <?php if($policy['paq'] == 1): ?>
				  <td><?php echo e(__('locale.Wide')); ?></td>
				  <?php elseif($policy['paq'] == 2): ?>
				  <td><?php echo e(__('locale.Limited')); ?></td>
				  <?php elseif($policy['paq'] == 3): ?>
				  <td><?php echo e(__('locale.RC')); ?></td>
				  <?php else: ?>
				  <td><?php echo e(__('locale.INTEGRAL')); ?></td>
				<?php endif; ?>
				<?php if($policy['fp'] == 12): ?>
				  <td><?php echo e(__('locale.Annual')); ?></td>
				  <?php elseif($policy['fp'] == 28): ?>
				  <td><?php echo e(__('locale.Semi-annual')); ?></td>
				  <?php elseif($policy['fp'] == 29): ?>
				  <td><?php echo e(__('locale.Quarterly')); ?></td>
				  <?php elseif($policy['fp'] == 27): ?>
				  <td><?php echo e(__('locale.Monthly')); ?></td>
				  <?php else: ?>
				  <td><?php echo e(__('locale.Biweekly')); ?></td>
				<?php endif; ?>
                <td>$<?php echo e($policy['ptotal']); ?> |MXN</td>
                <td><?php echo e($policy['description']); ?></td>
				<?php if($policy['status'] == 1): ?>
				  <?php if($policy['end_date'] > date('Y-m-d')): ?>
				  <td><span class="task-cat cyan"><?php echo e(__('locale.Valid')); ?></span></td>
				  <?php else: ?>
				  <td><span class="task-cat deep-orange accent-2"><?php echo e(__('locale.Expired')); ?></span></td>
				  <?php endif; ?>
				  <?php else: ?>
				  <td><span class="task-cat red accent-2"><?php echo e(__('locale.Canceled')); ?></span></td>
				<?php endif; ?>
				<td><a href="<?php echo e(route('policy-pdf', $policy['id'])); ?>" target="_blank"><i class="material-icons">picture_as_pdf</i></a></td>
              </tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('vendor-script'); ?>
<script src="<?php echo e(asset('vendors/chartjs/chart.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-script'); ?>
<script src="<?php echo e(asset('vendors/sortable/jquery-sortable-min.js')); ?>"></script>
<script src="<?php echo e(asset('js/scripts/redirect.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.contentLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/dreamy-montalcini.74-208-200-19.plesk.page/htdocs/local/resources/views//client/dashboard.blade.php ENDPATH**/ ?>