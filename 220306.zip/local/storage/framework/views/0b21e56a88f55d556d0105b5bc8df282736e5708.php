<?php $__env->startSection('title','App Email'); ?>


<?php $__env->startSection('vendor-style'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendors/flag-icon/css/flag-icon.min.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendors/quill/quill.snow.css')); ?>">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-style'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/pages/app-sidebar.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/pages/app-email.css')); ?>">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<!-- Sidebar Area Starts -->
<div class="email-overlay"></div>
<div class="sidebar-left sidebar-fixed">
  <div class="sidebar">
    <div class="sidebar-content">
      <div class="sidebar-header">
        <div class="sidebar-details">
          <h5 class="m-0 sidebar-title"><i class="material-icons app-header-icon text-top">mail_outline</i> <?php echo e(__('locale.Mailbox')); ?></h5>
          <div class="row valign-wrapper mt-10 pt-2 animate fadeLeft">
            <div class="col s3 media-image">
              <img src="<?php echo e(asset('images/user/'. $user->image)); ?>" alt="" class="circle z-depth-2 responsive-img">
              <!-- notice the "circle" class -->
            </div>
            <div class="col s9">
              <p class="m-0 subtitle font-weight-700"><?php echo e($user->firstname); ?> <?php echo e($user->lastname); ?></p>
              <p class="m-0 text-muted"><?php echo e($user->email); ?></p>
            </div>
          </div>
        </div>
      </div>
      <div id="sidebar-list" class="sidebar-menu list-group position-relative animate fadeLeft">
        <div class="sidebar-list-padding app-sidebar sidenav" id="email-sidenav">
          <ul class="email-list display-grid">
            <a class="sidebar-title"> <?php echo e(__('locale.Folders')); ?> </a>
            <li class="active"><a class="text-sub"><i class="material-icons mr-2"> mail_outline </i> <?php echo e(__('locale.Inbox')); ?> </a></li>
            <li><a class="text-sub"><i class="material-icons mr-2"> send </i> <?php echo e(__('locale.Sent')); ?> </a></li>
            <li><a class="text-sub"><i class="material-icons mr-2"> description </i> <?php echo e(__('locale.Draft')); ?> </a></li>
            <li><a class="text-sub"><i class="material-icons mr-2"> info_outline </i> <?php echo e(__('locale.Spam')); ?> </a></li>
            <li><a class="text-sub"><i class="material-icons mr-2"> delete </i> <?php echo e(__('locale.Trash')); ?> </a></li>
          </ul>
        </div>
      </div>
      <a data-target="email-sidenav" class="sidenav-trigger hide-on-large-only"><i
          class="material-icons">menu</i></a>
    </div>
  </div>
</div>
<!-- Sidebar Area Ends -->

<!-- Content Area Starts -->
<div class="app-email">
  <div class="content-area content-right">
    <div class="app-wrapper">
      <div class="app-search">
        <i class="material-icons mr-2 search-icon">search</i>
        <input type="text" placeholder="Search Mail" class="app-filter" id="email_filter">
      </div>
	  <?php if(session('success')): ?>
		<div class="card-alert card green lighten-5">
			<div class="card-content green-text">
				<p><?php echo e(__('locale.'. session('success'))); ?></p>
			</div>
			<button type="button" class="close green-text" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">×</span>
			</button>
		</div>
	  <?php endif; ?>
      <div class="card card card-default scrollspy border-radius-6 fixed-width">
        <div class="card-content p-0 pb-2">
          <div class="email-header">
            <div class="left-icons">
              <span class="header-checkbox" id="total_checkbox_span">
                <label>
                  <input type="checkbox" onClick="toggle(this)" />
                  <span></span>
                </label>
              </span>
            </div>
            <div class="list-content"></div>
            <div class="email-action">
              <span class="email-options" id="header_trash"><i class="material-icons delete-mails">delete</i></span>
            </div>
          </div>
          <div class="collection email-collection" id="collection-email-collection">
            <?php if(isset($data)): ?>
              <?php $__currentLoopData = $data['all_message_data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="email-brief-info collection-item animate fadeUp delay" id="<?php echo e($item['id'].'&'.$item['folder']); ?>">
                <div class="list-left">
                  <label>
                    <input type="checkbox" name="foo" />
                    <span></span>
                  </label>
                </div>
                <a class="list-content" href="<?php echo e(asset('app-email/content/' . $item['id'] . '/' . $item['folder'])); ?>">
                  <div class="list-title-area">
                    <div class="user-media">
                      <img src="<?php echo e(asset('images/user/'. $item['user_img'])); ?>" alt="" class="circle z-depth-2 responsive-img avtar">
                      <div class="list-title"><?php echo e($item['user_name']); ?></div>
                    </div>
                    <div class="title-right">
                    </div>
                  </div>
                  <div class="list-desc"><?php echo e($item['subject']); ?></div>
                </a>
                <div class="list-right">
                  <div class="list-date"><?php echo e($item['received_date']); ?></div>
                </div>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Content Area Ends -->

<!-- Add new email popup -->
<div style="bottom: 54px; right: 19px;" class="fixed-action-btn direction-top">
  <a class="btn-floating btn-large primary-text gradient-shadow compose-email-trigger">
    <i class="material-icons">add</i>
  </a>
</div>
<!-- Add new email popup Ends-->

<!-- email compose sidebar -->
<div class="email-compose-sidebar">
  <div class="card quill-wrapper">
    <div class="card-content pt-0">
      <div class="card-header display-flex pb-2">
        <h3 class="card-title"><i class="material-icons app-header-icon text-top">mail_outline</i></h3>
        <div class="close close-icon">
          <i class="material-icons">close</i>
        </div>
      </div>
      <div class="divider"></div>
      <!-- form start -->
      <form class="edit-email-item mt-10 mb-10" id="mail" action="<?php echo e(route('send-email')); ?>" enctype="multipart/form-data" method="POST">
		<?php echo e(csrf_field()); ?>

        <div class="input-field">
          <input type="email" value="<?php echo e($user->email); ?>" disabled>
		  <input type="email" id="edit-item-from" name="from" value="<?php echo e($user->email); ?>" style="display:none;">
          <label for="edit-item-from"><?php echo e(__('locale.From')); ?>:</label>
        </div>
        <div class="input-field">
          <input type="email" id="edit-item-to" name="to" value="">
          <label for="edit-item-to"><?php echo e(__('locale.To')); ?>:</label>
        </div>
        <div class="input-field">
          <input type="text" id="edit-item-subject" name="subject">
          <label for="edit-item-subject"><?php echo e(__('locale.Subject')); ?>:</label>
        </div>
        <div class="input-field">
          <input type="email" id="edit-item-CC" name="CC">
          <label for="edit-item-CC"><?php echo e(__('locale.CC')); ?>:</label>
        </div>
        <div class="input-field">
          <input type="email" id="edit-item-BCC" name="BCC">
          <label for="edit-item-BCC"><?php echo e(__('locale.BCC')); ?>:</label>
        </div>
        <!-- Compose mail Quill editor -->
        <div class="input-field" style="display:none;">
          <div class="snow-container mt-2">
            <div class="compose-editor"></div>
            <div class="compose-quill-toolbar">
            </div>
          </div>
        </div>
		<div class="input-field">
			<textarea id="forward_message" class="materialize-textarea" name="content" style="height: 62px;"></textarea>
			<label for="forward_message" class="active"><?php echo e(__('locale.Message')); ?>:</label>
		</div>
		<div class="file-field input-field">
          <div class="btn btn-file">
            <i class="material-icons mr-2"> attachment </i>
            <input type="file" name="attach">
          </div>
          <div class="file-path-wrapper">
            <input class="file-path validate" name="filePath" type="text">
          </div>
        </div>
      </form>
      <div class="card-action pl-0 pr-0 right-align">
        <button type="reset" class="btn-small waves-effect waves-light cancel-email-item mr-1">
          <i class="material-icons left">close</i>
          <span>Cancel</span>
        </button>
        <button class="btn-small waves-effect waves-light send-email-item">
          <i class="material-icons left">send</i>
          <span><?php echo e(__('locale.Send')); ?></span>
        </button>
      </div>
      <!-- form start end-->
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('vendor-script'); ?>
<script src="<?php echo e(asset('vendors/sortable/jquery-sortable-min.js')); ?>"></script>
<script src="<?php echo e(asset('vendors/quill/quill.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-script'); ?>
<script src="<?php echo e(asset('js/scripts/app-email.js')); ?>"></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.contentLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/dreamy-montalcini.74-208-200-19.plesk.page/htdocs/local/resources/views/pages/app-email.blade.php ENDPATH**/ ?>