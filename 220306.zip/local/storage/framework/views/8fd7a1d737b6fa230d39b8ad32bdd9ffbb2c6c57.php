<?php $__env->startSection('title','Notifications'); ?>


<?php $__env->startSection('vendor-style'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendors/flag-icon/css/flag-icon.min.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendors/quill/quill.snow.css')); ?>">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-style'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/pages/app-sidebar.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/pages/app-email.css')); ?>">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<!-- Sidebar Area Starts -->
<div class="email-overlay"></div>
<div class="sidebar-left sidebar-fixed">
  <div class="sidebar">
    <div class="sidebar-content">
      <div class="sidebar-header">
        <div class="sidebar-details">
          <h5 class="m-0 sidebar-title"><i class="material-icons app-header-icon text-top">notifications_none</i> <?php echo e(__('locale.Notifications')); ?></h5>
          <div class="row valign-wrapper mt-10 pt-2 animate fadeLeft">
            <div class="col s3 media-image">
              <img src="<?php echo e(asset('images/user/'. $user->image)); ?>" alt="" class="circle z-depth-2 responsive-img">
              <!-- notice the "circle" class -->
            </div>
            <div class="col s9">
              <p class="m-0 subtitle font-weight-700"><?php echo e($user->firstname); ?> <?php echo e($user->lastname); ?></p>
              <p class="m-0 text-muted"><?php echo e($user->email); ?></p>
            </div>
          </div>
        </div>
      </div>
      <div id="sidebar-list" class="sidebar-menu list-group position-relative animate fadeLeft">
        <div class="sidebar-list-padding app-sidebar sidenav" id="email-sidenav">
          <ul class="display-grid">
            <li class="sidebar-title"><?php echo e(__('locale.Quotation')); ?></li>
			<li class="active"><a href="<?php echo e(asset('quot_notify')); ?>" class="text-sub"><i class="material-icons mr-2"> note_add </i><?php echo e(__('locale.Quot_notify')); ?>

				<?php if($notify['new_quot'] > 0): ?>
				<span class="badge pill purple float-right mr-10"><?php echo e($notify['new_quot']); ?></span>
				<?php endif; ?>
				</a>
			</li>
            <li class="sidebar-title"><?php echo e(__('locale.Policy')); ?></li>
            <li><a href="<?php echo e(asset('new')); ?>" class="text-sub"><i class="material-icons mr-2"> add_shopping_cart </i><?php echo e(__('locale.Policy_new')); ?>

				<?php if($notify['new'] > 0): ?>
				<span class="badge pill purple float-right mr-10"><?php echo e($notify['new']); ?></span>
				<?php endif; ?>
				</a>
			</li>
            <li><a href="<?php echo e(asset('expired')); ?>" class="text-sub"><i class="material-icons mr-2"> stars </i><?php echo e(__('locale.Policy_expired')); ?>

				<?php if($notify['expired'] > 0): ?>
				<span class="badge pill orange float-right mr-10"><?php echo e($notify['expired']); ?></span>
				<?php endif; ?>
				</a>
			</li>
            <li><a href="<?php echo e(asset('canceled')); ?>" class="text-sub"><i class="material-icons mr-2"> today </i><?php echo e(__('locale.Policy_canceled')); ?>

				<?php if($notify['canceled'] > 0): ?>
				<span class="badge pill pink float-right mr-10"><?php echo e($notify['canceled']); ?></span>
				<?php endif; ?>
				</a>
			</li>
          </ul>
        </div>
      </div>
      <a data-target="email-sidenav" class="sidenav-trigger hide-on-large-only"><i
          class="material-icons">menu</i></a>
    </div>
  </div>
</div>
<!-- Sidebar Area Ends -->

<!-- Content Area Starts -->
<div class="app-email">
  <div class="content-area content-right">
    <div class="app-wrapper">
	  <div class="app-search">
        <i class="material-icons mr-2 search-icon">search</i>
        <input type="text" placeholder="<?php echo e(__('locale.Search')); ?>" class="app-filter" id="email_filter">
      </div>
      <div class="card card card-default scrollspy border-radius-6 fixed-width">
        <div class="card-content p-0 pb-2">
		  <div class="email-header">
            <div class="left-icons">
              <span style="margin-left: 1rem;">
                <i class="material-icons">notifications_none</i>
              </span>
            </div>
          </div>
          <div class="collection email-collection">
			<?php $__currentLoopData = $data['news']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="email-brief-info collection-item animate fadeUp delay-1">
			  <?php if($user->role == 'client'): ?>
				<a class="list-content" href="<?php echo e(asset('chat')); ?>">
			  <?php else: ?>
                <a class="list-content" href="<?php echo e(route('quot-pdf', $value['message'])); ?>" target="_blank">
			  <?php endif; ?>
                <div class="list-title-area">
                  <div class="user-media">
                    <img src="<?php echo e(asset('images/favicon/mstile-144x144.png')); ?>" alt="" class="circle z-depth-2 responsive-img avtar">
				  	<div class="list-title"><?php echo e(__('locale.Quotation')); ?> <?php echo e($value['cot_id']); ?></div>
                  </div>
                </div>
                <div class="list-desc">
					<span id="name" class="col l5"><?php echo e($value['firstname']); ?> <?php echo e($value['lastname']); ?> <?php echo e($value['paternal_surname']); ?> <?php echo e($value['maternal_surname']); ?></span>
					<span id="start" class="col l3"><?php echo e(__('locale.Start_date')); ?>:&nbsp;&nbsp;<?php echo e($value['start_date']); ?></span>
					<span id="end" class="col l4"><?php echo e(__('locale.Cancel_date')); ?>:&nbsp;&nbsp;<?php echo e($value['end_date']); ?></span><br>
					<span id="des" class="col l8"><?php echo e(__('locale.Description')); ?>:&nbsp;&nbsp;<?php echo e($value['description']); ?></span>
					<span id="ptotal" class="col l4">Prima Total:&nbsp;&nbsp;$<?php echo e($value['ptotal']); ?> |MXN</span>
				</div>
              </a>
              <div class="list-right">
                <?php $notify= explode(" ", $value['created_at']); ?>
                <div class="list-date"> <?php echo e($notify[0]); ?> </div>
              </div>
            </div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="no-data-found collection-item">
              <h6 class="center-align font-weight-500"><?php echo e(__('locale.No_result')); ?></h6>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Content Area Ends -->

<!-- Add new email popup -->
<div style="bottom: 54px; right: 19px;" class="fixed-action-btn direction-top">
  <a class="btn-floating btn-large primary-text gradient-shadow compose-email-trigger">
    <i class="material-icons">mail_outline</i>
  </a>
</div>
<!-- Add new email popup Ends-->

<!-- email compose sidebar -->
<div class="email-compose-sidebar">
  <div class="card quill-wrapper">
    <div class="card-content pt-0">
      <div class="card-header display-flex pb-2">
        <h3 class="card-title"><i class="material-icons app-header-icon text-top">mail_outline</i></h3>
        <div class="close close-icon">
          <i class="material-icons">close</i>
        </div>
      </div>
      <div class="divider"></div>
      <!-- form start -->
      <form class="edit-email-item mt-10 mb-10" id="mail" action="<?php echo e(route('send-email')); ?>" enctype="multipart/form-data" method="POST">
		<?php echo e(csrf_field()); ?>

        <div class="input-field">
          <input type="email" value="<?php echo e($user->email); ?>" disabled>
		  <input type="email" id="edit-item-from" name="from" value="<?php echo e($user->email); ?>" style="display:none;">
          <label for="edit-item-from"><?php echo e(__('locale.From')); ?></label>
        </div>
        <div class="input-field">
          <input type="email" id="edit-item-to" name="to" value="">
          <label for="edit-item-to"><?php echo e(__('locale.To')); ?></label>
        </div>
        <div class="input-field">
          <input type="text" id="edit-item-subject" name="subject">
          <label for="edit-item-subject"><?php echo e(__('locale.Subject')); ?></label>
        </div>
        <div class="input-field">
          <input type="email" id="edit-item-CC" name="CC">
          <label for="edit-item-CC"><?php echo e(__('locale.CC')); ?></label>
        </div>
        <div class="input-field">
          <input type="email" id="edit-item-BCC" name="BCC">
          <label for="edit-item-BCC"><?php echo e(__('locale.BCC')); ?></label>
        </div>
        <!-- Compose mail Quill editor -->
        <div class="input-field" style="display:none;">
          <div class="snow-container mt-2">
            <div class="compose-editor"></div>
            <div class="compose-quill-toolbar">
            </div>
          </div>
        </div>
		<div class="input-field">
			<textarea id="forward_message" class="materialize-textarea" name="content" style="height: 62px;"></textarea>
			<label for="forward_message" class="active"><?php echo e(__('locale.Message')); ?></label>
		</div>
		<div class="file-field input-field">
          <div class="btn btn-file">
            <i class="material-icons mr-2"> attachment </i>
            <input type="file" name="attach">
          </div>
          <div class="file-path-wrapper">
            <input class="file-path validate" name="filePath" type="text">
          </div>
        </div>
      </form>
      <div class="card-action pl-0 pr-0 right-align">
        <button type="reset" class="btn-small waves-effect waves-light cancel-email-item mr-1">
          <i class="material-icons left">close</i>
          <span>Cancel</span>
        </button>
        <button class="btn-small waves-effect waves-light send-email-item">
          <i class="material-icons left">send</i>
          <span><?php echo e(__('locale.Send')); ?></span>
        </button>
      </div>
      <!-- form start end-->
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('vendor-script'); ?>
<script src="<?php echo e(asset('vendors/quill/quill.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-script'); ?>
<script src="<?php echo e(asset('js/scripts/app-email.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.contentLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/dreamy-montalcini.74-208-200-19.plesk.page/htdocs/local/resources/views/pages/notifi-quot_new.blade.php ENDPATH**/ ?>