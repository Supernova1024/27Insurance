<?php $__env->startSection('title','User Login'); ?>


<?php $__env->startSection('page-style'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/pages/login.css')); ?>">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div id="login-page" class="row">
  <div class="col s12 m6 l4 z-depth-4 card-panel border-radius-6 login-card bg-opacity-8">
    <form class="login-form" method="POST" action="<?php echo e(route('login')); ?>">
      <?php echo csrf_field(); ?>
      <div class="row">
		<!--<div class="input-field col s12"  style="text-align: center;">
  			<img src="<?php echo e(asset('images/mail/seguros_acv.png')); ?>" height="50" width="264">
		</div> -->
        <div class="col s12">
		  <?php if(session('success')): ?>
		    <div class="card-alert card green lighten-5">
			  <div class="card-content green-text">
				  <p><?php echo e(__('locale.'. session('success'))); ?></p>
			  </div>
			  <button type="button" class="close green-text" data-dismiss="alert" aria-label="Close">
				  <span aria-hidden="true">×</span>
			  </button>
			</div>
		  <?php elseif(session('error')): ?>
		    <div class="card-alert card red lighten-5">
			  <div class="card-content red-text">
				  <p><?php echo e(__('locale.'. session('error'))); ?></p>
			  </div>
			  <button type="button" class="close red-text" data-dismiss="alert" aria-label="Close">
				  <span aria-hidden="true">×</span>
			  </button>
			</div>
		  <?php else: ?>
          	<h5 class="ml-4"><?php echo e(__('locale.Sign_in')); ?></h5>
		  <?php endif; ?>
        </div>
      </div>
      <div class="row margin">
        <div class="input-field col s12">
          <i class="material-icons prefix pt-2">person_outline</i>
          <input id="email" type="email" class=" <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email"
            value="<?php echo e(old('email')); ?>"  autocomplete="email" autofocus>
          <label for="email" class="center-align"><?php echo e(__('locale.Email')); ?></label>
          <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <small class="red-text ml-7" >
            <?php echo e($message); ?>

          </small>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
      </div>
      <div class="row margin">
        <div class="input-field col s12">
          <i class="material-icons prefix pt-2">lock_outline</i>
          <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
            name="password"  autocomplete="current-password">
          <label for="password"><?php echo e(__('locale.Password')); ?></label>
          <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <small class="red-text ml-7" >
            <?php echo e($message); ?>

          </small>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
      </div>
      <div class="row margin">
        <div class="col s8 m8 l8">
          <p>
            <label>
              <input type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
              <span><?php echo e(__('locale.Remember')); ?></span>
            </label>
          </p>
		</div>
		<div class="col s4 m4 l4">
			<ul class="navbar-list">
				<li class="dropdown-language">
				  <a class="waves-effect waves-block waves-light translation-button" data-target="translation-dropdown">
					<span class="flag-icon flag-icon-mx"></span>
				  </a>
				</li>
			</ul>
        </div>
      </div>
      <div class="row">
        <div class="input-field col s12">
          <button type="submit" class="btn waves-effect waves-light border-round gradient-45deg-indigo-blue col s12">
            <?php echo e(__('locale.Login')); ?>

          </button>
        </div>
      </div>
      <div class="row">
        <div class="input-field col s6 m6 l6">
          <p class="margin medium-small"><a href="<?php echo e(route('register')); ?>"><?php echo e(__('locale.Register_now')); ?></a></p>
        </div>
        <div class="input-field col s6 m6 l6">
          <p class="margin right-align medium-small">
            <a href="<?php echo e(route('password.request')); ?>"><?php echo e(__('locale.Forgot_password')); ?></a>
          </p>
        </div>
      </div>
    </form>
  </div>
	<style>
		.myfooter {
			position: fixed;
			left: 0;
			bottom: 20px;
			width: 100%;
			color: white;
			text-align: center;
		}
	</style>
	<div class="myfooter">
		<img src="<?php echo e(asset('images/logo/footer.png')); ?>" width="300" height="60">
	</div>
</div>
<ul class="dropdown-content" id="translation-dropdown">
	<li class="dropdown-item">
		<a class="grey-text text-darken-1" href="<?php echo e(url('lang/en')); ?>" data-language="en">
			<i class="flag-icon flag-icon-us"></i>
			<?php echo e(__('locale.English')); ?>

		</a>
	</li>
	<li class="dropdown-item">
		<a class="grey-text text-darken-1" href="<?php echo e(url('lang/es')); ?>" data-language="es">
			<i class="flag-icon flag-icon-mx"></i>
			<?php echo e(__('locale.Spanish')); ?>

		</a>
	</li>
</ul>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.fullLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/dreamy-montalcini.74-208-200-19.plesk.page/htdocs/local/resources/views//auth/login.blade.php ENDPATH**/ ?>