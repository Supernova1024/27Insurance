<?php $__env->startSection('title','Iussing Policy'); ?>


<?php $__env->startSection('vendor-style'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendors/flag-icon/css/flag-icon.min.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendors/materialize-stepper/materialize-stepper.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-style'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/pages/form-wizard.css')); ?>">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="section section-form-wizard">

  <!-- Horizontal Stepper -->
  <div class="row">
    <div class="col s12">
	  <?php if(session('success')): ?>
		<div class="card">
			<div class="card-content">
				<!-- users edit media object start -->
				<div class="media display-flex align-items-center mb-2">
					<div class="media-body">
						<h5 class="media-heading mt-0"><?php echo e($data['quot']['cot_id']); ?></h5>
					</div>
				</div>
				<div class="card-alert card green lighten-5">
					<div class="card-content green-text">
						<p><?php echo e(session('success')); ?></p>
					</div>
					<button type="button" class="close green-text" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">×</span>
					</button>
				</div>
			</div>
		</div>
	  <?php endif; ?>
	  <?php if(session('error')): ?>
		<div class="card">
			<div class="card-content">
				<!-- users edit media object start -->
				<div class="media display-flex align-items-center mb-2">
					<div class="media-body">
						<h5 class="media-heading mt-0"><?php echo e($data['quot']['cot_id']); ?></h5>
					</div>
				</div>
				<div class="card-alert card red lighten-5">
					<div class="card-content red-text">
						<p><?php echo e(session('error')); ?></p>
					</div>
					<button type="button" class="close red-text" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">×</span>
					</button>
				</div>
			</div>
		</div>
	  <?php endif; ?>
      <div class="card">
        <div class="card-content pb-0">		
          <div class="card-header mb-2">
            <h4 class="card-title"><?php echo e(__('locale.Quotation')); ?> <?php echo e($data['quot']['cot_id']); ?></h4>
          </div>
		  <form action="<?php echo e(asset('policy-issuing')); ?>" method="POST">
			  <?php echo e(csrf_field()); ?>

          <ul class="stepper horizontal" id="horizStepper">
            <li class="step active">
              <div class="step-title waves-effect"><?php echo e(__('locale.Step')); ?> 1</div>
              <div class="step-content">
                <div class="row">
                  <div class="input-field col l6 s12" id="dec">
					<label for="dec">Vehicle: <span class="red-text">*</span></label>
                    <input type="text" class="validate" name="dec" value="<?php echo e($data['quot']['description']); ?>" disabled>
					<input type="hidden" class="validate" name="quot_id" value="<?php echo e($data['quot']['id']); ?>">
                  </div>
				  <div class="input-field col l6 s12">
                    <label for="serie"><?php echo e(__('locale.Serie')); ?>: <span class="red-text">*</span></label>
                    <input type="text" id="serie" class="validate" name="serie" required>
                  </div>
                </div>
                <div class="row">
			      <div class="input-field col l4 m6 s12">
                    <label for="motor"><?php echo e(__('locale.Motor')); ?>: <span class="red-text">*</span></label>
                    <input type="text" id="motor" class="validate" name="motor" required>
                  </div>
                  <div class="input-field col l4 m6 s12">
                    <label for="plates"><?php echo e(__('locale.Plates')); ?>: <span class="red-text">*</span></label>
                    <input type="text" id="plates" class="validate" name="plates" required>
                  </div>
				  <div class="input-field col l4 s12">
                    <label for="ref"><?php echo e(__('locale.Reference')); ?>: <span class="red-text">*</span></label>
                    <input type="text" id="ref" class="validate" name="ref" required>
                  </div>
                </div>
				<div class="step-actions">
					<div class="row">
						<div class="col m4 s12 mb-3">
							<a class="red btn btn-reset" disabled>
								<i class="material-icons left">clear</i><?php echo e(__('locale.Reset')); ?>

							</a>
						</div>
						<div class="col m4 s12 mb-3">
							<button class="btn btn-light previous-step" disabled>
								<i class="material-icons left">arrow_back</i>
								<?php echo e(__('locale.Prev')); ?>

							</button>
						</div>
						<div class="col m4 s12 mb-3">
							<button id="next1" class="waves-effect waves dark btn btn-primary next-step" disabled>
								<?php echo e(__('locale.Next')); ?>

								<i class="material-icons right">arrow_forward</i>
							</button>
						</div>
					</div>
				  </div>
              </div>
            </li>
			<li class="step">
              <div class="step-title waves-effect"><?php echo e(__('locale.Step')); ?> 2</div>
				<div class="step-content">
					<div class="row">
						<div class="input-field col l3 m6 s12">
							<label for="firstname"><?php echo e(__('locale.Firstname')); ?>: <span class="red-text">*</span></label>
							<input type="text" id="firstname" class="validate" name="firstname" value="<?php echo e($data['client']['firstname']); ?>">
						</div>
						<div class="input-field col l3 m6 s12">
							<label for="lastname"><?php echo e(__('locale.Lastname')); ?>: <span class="red-text">*</span></label>
							<input type="text" id="lastname" class="validate" name="lastname" value="<?php echo e($data['client']['lastname']); ?>">
						</div>
						<div class="input-field col l3 m6 s12">
							<label for="paternal"><?php echo e(__('locale.Paternal')); ?>: <span class="red-text">*</span></label>
							<input type="text" id="paternal" class="validate" name="paternal" value="<?php echo e($data['client']['paternal_surname']); ?>" >
						</div>
						<div class="input-field col l3 m6 s12">
							<label for="maternal"><?php echo e(__('locale.Maternal')); ?>: <span class="red-text">*</span></label>
							<input type="text" id="maternal" class="validate" name="maternal" value="<?php echo e($data['client']['maternal_surname']); ?>" >
						</div>
					</div>
					<div class="row">
						<div class="input-field col m6 s12">
							<label for="email"><?php echo e(__('locale.Email')); ?>: <span class="red-text">*</span></label>
							<input type="text" id="email" class="validate" name="email" value="<?php echo e($data['client']['email']); ?>">
						</div>
						<div class="input-field col m6 s12">
							<label for="datepicker"><?php echo e(__('locale.Birthday')); ?>:<span class="red-text">*</span></label>
							<input type="text" id="datepicker" name="birthday" value="<?php echo e($data['client']['birthday']); ?>">
						</div>
					</div>
					<div class="row">
						<div class="input-field col m6 s12">
							<select id="sex" name="sex">
								<option disabled <?php echo $data['client']['sex'] == null ? 'selected' : ''; ?>><?php echo e(__('locale.Select')); ?></option>
								<option value="male" <?php echo $data['client']['sex'] == 'male' ? 'selected' : ''; ?>><?php echo e(__('locale.Male')); ?></option>
								<option value="female" <?php echo $data['client']['sex'] == 'female' ? 'selected' : ''; ?>><?php echo e(__('locale.Female')); ?></option>
							</select>
							<label><?php echo e(__('locale.Sex')); ?><span class="red-text">*</span></label>
						</div>
						<div class="input-field col m6 s12">
							<select id="marital" name="marital">
								<option disabled <?php echo $data['client']['marital'] == null ? 'selected' : ''; ?>><?php echo e(__('locale.Select')); ?></option>
								<option value="1" <?php echo $data['client']['marital'] == '1' ? 'selected' : ''; ?>><?php echo e(__('locale.Married')); ?></option>
								<option value="2" <?php echo $data['client']['marital'] == '2' ? 'selected' : ''; ?>><?php echo e(__('locale.Single')); ?></option>
								<option value="3" <?php echo $data['client']['marital'] == '3' ? 'selected' : ''; ?>><?php echo e(__('locale.Widower')); ?></option>
								<option value="4" <?php echo $data['client']['marital'] == '4' ? 'selected' : ''; ?>><?php echo e(__('locale.Divorced')); ?></option>
							</select>
							<label><?php echo e(__('locale.Marital')); ?> <?php echo e(__('locale.Status')); ?></label>
						</div>
						<div class="input-field col m6 s12">
							<select id="person" name="person">
								<option disabled><?php echo e(__('locale.Select')); ?></option>
								<option value="1"><?php echo e(__('locale.Fisica')); ?></option>
								<option value="2"><?php echo e(__('locale.Moral')); ?></option>
							</select>
							<label><?php echo e(__('locale.Person')); ?><span class="red-text">*</span></label>
						</div><div class="input-field col m6 s12">
							<select id="nationality" name="nationality">
								<option disabled><?php echo e(__('locale.Select')); ?></option>
								<option value="1"><?php echo e(__('locale.Mexican')); ?></option>
								<option value="2"><?php echo e(__('locale.Foreign')); ?></option>
							</select>
							<label><?php echo e(__('locale.Nationality')); ?><span class="red-text">*</span></label>
						</div>
						<div class="input-field col s12">
							<label for="address"><?php echo e(__('locale.Address')); ?>: <span class="red-text">*</span></label>
							<input type="text" id="address" class="validate" name="address" value="<?php echo e($data['client']['address']); ?>">
						</div>
					</div>
					<div class="step-actions">
						<div class="row">
							<div class="col m4 s12 mb-3">
								<a class="red btn btn-reset" href="<?php echo e(asset('policy-new/' . $data['quot']['id'])); ?>">
									<i class="material-icons left">clear</i><?php echo e(__('locale.Reset')); ?>

								</a>
							</div>
							<div class="col m4 s12 mb-3">
								<button class="btn btn-light previous-step">
									<i class="material-icons left">arrow_back</i>
									<?php echo e(__('locale.Prev')); ?>

								</button>
							</div>
							<div class="col m4 s12 mb-3">
								<button id="next2" class="waves-effect waves dark btn btn-primary next-step">
									<?php echo e(__('locale.Next')); ?>

									<i class="material-icons right">arrow_forward</i>
								</button>
							</div>
						</div>
					</div>
				</div>
            </li>
            <li class="step">
              <div class="step-title waves-effect"><?php echo e(__('locale.Step')); ?> 3</div>
              <div class="step-content">
                <div class="row">
					<div class="input-field col m4 s12">
						<select id="business" name="business">
							<option disabled><?php echo e(__('locale.Select')); ?></option>
							<option value="10"><?php echo e(__('locale.Industrial')); ?></option>
							<option value="20"><?php echo e(__('locale.Comercial')); ?></option>
							<option value="30"><?php echo e(__('locale.Servicios')); ?></option>
							<option value="31"><?php echo e(__('locale.Públicos')); ?></option>
							<option value="32"><?php echo e(__('locale.Privados')); ?></option>
							<option value="33"><?php echo e(__('locale.Transporte')); ?></option>
							<option value="34"><?php echo e(__('locale.Turismo')); ?></option>
							<option value="35"><?php echo e(__('locale.Instituciones')); ?></option>
							<option value="36"><?php echo e(__('locale.Educación')); ?></option>
							<option value="37"><?php echo e(__('locale.Salubridad')); ?></option>
							<option value="38"><?php echo e(__('locale.Fianzas')); ?></option>
						</select>
						<label><?php echo e(__('locale.Business')); ?></label>
					</div>
					<div class="input-field col m4 s12">
						<select id="occupation" name="occupation">
							<option disabled><?php echo e(__('locale.Select')); ?></option>
							<option value="1"><?php echo e(__('locale.Businessman')); ?></option>
							<option value="2"><?php echo e(__('locale.Empleado')); ?></option>
							<option value="3"><?php echo e(__('locale.Empresario')); ?></option>
							<option value="4"><?php echo e(__('locale.Permisionario')); ?></option>
							<option value="5"><?php echo e(__('locale.Otro')); ?></option>
							<option value="6"><?php echo e(__('locale.Transportista')); ?></option>
							<option value="7"><?php echo e(__('locale.Hogar')); ?></option>
						</select>
						<label><?php echo e(__('locale.Occupation')); ?></label>
					</div>
					<div class="input-field col m4 s12">
						<select id="profession" name="profession">
							<option disabled><?php echo e(__('locale.Select')); ?></option>
							<option value="1"><?php echo e(__('locale.Administrador')); ?></option>
							<option value="2"><?php echo e(__('locale.Abogado')); ?></option>
							<option value="3"><?php echo e(__('locale.Arquitecto')); ?></option>
							<option value="4"><?php echo e(__('locale.Actuario')); ?></option>
							<option value="5"><?php echo e(__('locale.Contador')); ?></option>
							<option value="6"><?php echo e(__('locale.Docente')); ?></option>
							<option value="7"><?php echo e(__('locale.Economista')); ?></option>
							<option value="8"><?php echo e(__('locale.Ingeniero')); ?></option>
							<option value="9"><?php echo e(__('locale.Medico')); ?></option>
							<option value="10"><?php echo e(__('locale.Psicólogo')); ?></option>
							<option value="11"><?php echo e(__('locale.Odontólogo')); ?></option>
							<option value="12"><?php echo e(__('locale.Químico')); ?></option>
							<option value="13"><?php echo e(__('locale.Biólogo')); ?></option>
							<option value="14"><?php echo e(__('locale.Sociólogo')); ?></option>
							<option value="15"><?php echo e(__('locale.Periodista')); ?></option>
							<option value="16"><?php echo e(__('locale.Otro')); ?></option>
							<option value="17"><?php echo e(__('locale.Ninguna')); ?></option>
						</select>
						<label><?php echo e(__('locale.Profession')); ?></label>
					</div>
					<div class="input-field col m6 s12">
						<label for="phone"><?php echo e(__('locale.Phone')); ?>: <span class="red-text">*</span></label>
						<input type="text" id="phone" class="validate" name="phone" value="<?php echo e($data['client']['phone']); ?>">
					</div>
					<div class="input-field col m6 s12">
						<label for="telephone"><?php echo e(__('locale.Telephone')); ?>: <span class="red-text">*</span></label>
						<input type="text" id="telephone" class="validate" name="telephone" value="<?php echo e($data['client']['telephone']); ?>" >
					</div>
					<div class="input-field col m6 s12">
						<label for="colonia"><?php echo e(__('locale.Colonia')); ?>: <span class="red-text">*</span></label>
						<input type="text" id="colonia" class="validate" name="colonia" value="<?php echo e($data['quot']['colonia']); ?>">
					</div>
					<div class="input-field col m6 s12">
						<label for="municipality"><?php echo e(__('locale.Municipality')); ?>: <span class="red-text">*</span></label>
						<input type="text" id="municipality" class="validate" name="municipality" value="<?php echo e($data['quot']['municipality']); ?>" >
					</div>
					<div class="input-field col m4 s12">
						<label for="cp"><?php echo e(__('locale.CP')); ?>: <span class="red-text">*</span></label>
						<input type="text" id="cp" class="validate" name="cp" value="<?php echo e($data['client']['postal_code']); ?>">
					</div>
					<div class="input-field col m4 s12">
						<label for="rfc"><?php echo e(__('locale.RFC')); ?>: <span class="red-text">*</span></label>
						<input type="text" id="rfc" class="validate" name="rfc" value="__________">
					</div>
					<div class="input-field col m4 s12">
						<label for="ext_num"><?php echo e(__('locale.Outdoor_num')); ?>: <span class="red-text">*</span></label>
						<input type="text" id="ext_num" class="validate" name="ext_num">
					</div>
                </div>
                <div class="step-actions">
                  <div class="row">
                    <div class="col m4 s12 mb-3">
                      <a class="red btn btn-reset" href="<?php echo e(asset('policy-new/' . $data['quot']['id'])); ?>">
                        <i class="material-icons left">clear</i><?php echo e(__('locale.Reset')); ?>

                      </a>
                    </div>
                    <div class="col m4 s12 mb-3">
                      <button class="btn btn-light previous-step">
                        <i class="material-icons left">arrow_back</i>
                        <?php echo e(__('locale.Prev')); ?>

                      </button>
                    </div>
                    <div class="col m4 s12 mb-3">
                      <button id="issuing" type="submit" class="waves-effect waves dark btn btn-primary" disabled>
                        <?php echo e(__('locale.Issuing')); ?><i class="material-icons right">send</i>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </li>
          </ul>
		  </form>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('vendor-script'); ?>
<script src="<?php echo e(asset('vendors/materialize-stepper/materialize-stepper.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-script'); ?>
<script src="<?php echo e(asset('js/scripts/form-wizard.js')); ?>"></script>
<script src="<?php echo e(asset('js/scripts/advance-ui-modals.js')); ?>"></script>
<script src="<?php echo e(asset('js/policy.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.contentLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/dreamy-montalcini.74-208-200-19.plesk.page/htdocs/local/resources/views/pages/policy-new.blade.php ENDPATH**/ ?>