<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
    <title><?php echo e($cve); ?><?php echo e($pol); ?></title>
	<style>
		table {
			font-family: arial, sans-serif;
			border-collapse: collapse;
			width: 100%;
		}

		td, th {
			border: 1px solid #dddddd;
			text-align: left;
			padding: 8px;
		}
		.left{
			float: left;
		}
		
		.right{
			float: right;
		}
		
		.both{
			display: table;
			clear: both;
		}

	</style>
</head>
<body>
	<?php if($company == 'ABA'): ?>
	<img src="<?php echo e(public_path('ABA.svg')); ?>" style="width: 210px; height: 70px">
	<?php elseif($company == 'QUA'): ?>
	<img src="<?php echo e(public_path('Qual.svg')); ?>" style="width: 210px; height: 70px">
	<?php elseif($company == 'ANA'): ?>
	<img src="<?php echo e(public_path('ANA.svg')); ?>" style="width: 210px; height: 70px">
	<?php elseif($company == 'HDI'): ?>
	<img src="<?php echo e(public_path('HDI.png')); ?>" style="width: 210px; height: 70px">
	<?php elseif($company == 'AXA'): ?>
	<img src="<?php echo e(public_path('AXA.png')); ?>" style="width: 210px; height: 70px">
	<?php endif; ?>
	<table>
		<tr>
			<td style = "width:30%;"><h2>Póliza:&nbsp;<?php echo e($cve); ?><?php echo e($pol); ?></h2></td>
			<td style = "width:70%;">Vigencia:&nbsp;<?php echo e($start_date); ?> 12:00 horas al <?php echo e($end_date); ?> 12:00 horas</td>
		</tr>
		<tr>
			<td style = "width:50%;">Paquete:&nbsp;
				<?php if($paq == 1): ?>
					AMPLIA
				<?php elseif($paq == 2): ?>
					LIMITADA
				<?php elseif($paq == 3): ?>
					RC
				<?php else: ?>
					INTEGRAL
				<?php endif; ?>
			</td>
			<td style = "width:50%;">Forma de pago:&nbsp;
				<?php if($fp == 12): ?>
					Counted
				<?php elseif($fp == 28): ?>
					SEMESTRAL S / R PRSP
				<?php elseif($fp == 29): ?>
					QUARTERLY S / R DERP
				<?php elseif($fp == 27): ?>
					MONTHLY S / R DERP
				<?php elseif($fp == 31): ?>
					QUINCENAL S / R DERP
				<?php else: ?>
					QUINCENAL EXACT
				<?php endif; ?>
			</td>
		</tr>
	</table>
	<h3>Datos del asegurado y/o propietario</h3>
	<p>Asegurado:&nbsp;<?php echo e($insured); ?></p>
	<p>Propietario/Contratante:&nbsp;<?php echo e($insured); ?></p>
	<p>Domicilio: CONCORDIA EXT. 212, ESPERANZA, GUADALAJARA, JALISCO, MEXICO</p>
	<p>CP.:&nbsp;<?php echo e($cp); ?></p>
	<p>Teléfono:&nbsp;<?php echo e($telephone); ?></p>
	<p>R.F.C.:&nbsp;<?php echo e($rfc); ?></p>
	<h3>Descripción del vehículo</h3>
	<p>Descripción del vehículo*: <?php echo e($description); ?></p>
	<p>Marca: <?php echo e($marca); ?></p>
	<p>Model: <?php echo e($model); ?></p>
	<p>Capacidad: 5</p>
	<p>Servicio: PARTICULAR</p>
	<p>Uso: PRIVADO</p>
	<p>Serie: <?php echo e($serie); ?></p>
	<p>Motor: <?php echo e($motor); ?></p>
	<p>Placas: <?php echo e($plates); ?></p>
	<h3>Desglose de coberturas</h3>
	<p>Prima neta: $<?php echo e($pneta); ?>|MXN</p>
	<p>Gastos de expedición: $<?php echo e($DER); ?>|MXN</p>
	<p>I.V.A.: $<?php echo e($iva); ?>|MXN</p>
	<p>Prima total: $<?php echo e($ptotal); ?>|MXN</p>
</body>
</html><?php /**PATH /var/www/vhosts/dreamy-montalcini.74-208-200-19.plesk.page/htdocs/local/resources/views/PDF/policy.blade.php ENDPATH**/ ?>