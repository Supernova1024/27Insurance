<?php $__env->startSection('title','Clients List'); ?>


<?php $__env->startSection('vendor-style'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendors/data-tables/css/jquery.dataTables.min.css')); ?>">
<link rel="stylesheet" type="text/css"
  href="<?php echo e(asset('vendors/data-tables/extensions/responsive/css/responsive.dataTables.min.css')); ?>">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-style'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/pages/data-tables.css')); ?>">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<!-- users list start -->
<div class="section section-data-tables">
	<!-- Page Length Options -->
	<div class="row">
		<div class="col s12">
			<div class="card">
				<div class="card-content">
					<div class="row">
						<div class="col s12">
							<table id="page-length-option" class="display">
								<thead>
									<tr>
										<th><?php echo e(__('locale.Client')); ?></th>
										<th><?php echo e(__('locale.Full_name')); ?></th>
										<th><?php echo e(__('locale.Address')); ?></th>
										<th><?php echo e(__('locale.Phone')); ?></th>
										<th><?php echo e(__('locale.Telephone')); ?></th>
										<th><?php echo e(__('locale.Status')); ?></th>
										<th><?php echo e(__('locale.Email')); ?></th>
										<th><?php echo e(__('locale.Edit')); ?></th>
										<th><?php echo e(__('locale.View')); ?></th>
									</tr>
								</thead>
								<tbody>
									<?php $__currentLoopData = $data['clients']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td>
											<img src="<?php echo e(asset('images/user/' . $client['image'])); ?>" class="circle z-depth-2 responsive-img" width="40" height="40">
										</td>
										<td><a href="<?php echo e(route('client-view', $client['id'])); ?>">
											<span class="green-text"><?php echo e($client['firstname']); ?> <?php echo e($client['lastname']); ?> <?php echo e($client['paternal_surname']); ?> <?php echo e($client['maternal_surname']); ?></span></a>
										</td>
										<td><?php echo e($client['address']); ?></td>
										<td><?php echo e($client['phone']); ?></td>
										<td><?php echo e($client['telephone']); ?></td>
										<td><span class="chip green lighten-5">
											<span class="green-text">Active</span>
											</span>
										</td>
										<td><?php echo e($client['email']); ?></td>
										<td><a href="<?php echo e(route('client-edit', $client['id'])); ?>"><i class="material-icons">edit</i></a></td>
										<td><a href="<?php echo e(route('client-view', $client['id'])); ?>"><i class="material-icons">remove_red_eye</i></a></td>
									</tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</tbody>
								<tfoot>
									<tr>
										<th><?php echo e(__('locale.Client')); ?></th>
										<th><?php echo e(__('locale.Full_name')); ?></th>
										<th><?php echo e(__('locale.Address')); ?></th>
										<th><?php echo e(__('locale.Phone')); ?></th>
										<th><?php echo e(__('locale.Telephone')); ?></th>
										<th><?php echo e(__('locale.Status')); ?></th>
										<th><?php echo e(__('locale.Email')); ?></th>
										<th><?php echo e(__('locale.Edit')); ?></th>
										<th><?php echo e(__('locale.View')); ?></th>
									</tr>
								</tfoot>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- users list ends -->
<?php $__env->stopSection(); ?>


<?php $__env->startSection('vendor-script'); ?>
<script src="<?php echo e(asset('vendors/data-tables/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendors/data-tables/extensions/responsive/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendors/data-tables/js/dataTables.select.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-script'); ?>
<script src="<?php echo e(asset('js/scripts/data-tables.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.contentLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/dreamy-montalcini.74-208-200-19.plesk.page/htdocs/local/resources/views/pages/clients-list.blade.php ENDPATH**/ ?>