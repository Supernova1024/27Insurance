<?php $__env->startSection('title','Quotation List'); ?>


<?php $__env->startSection('vendor-style'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendors/flag-icon/css/flag-icon.min.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendors/data-tables/css/jquery.dataTables.min.css')); ?>">
<link rel="stylesheet" type="text/css"
  href="<?php echo e(asset('vendors/data-tables/extensions/responsive/css/responsive.dataTables.min.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendors/data-tables/css/select.dataTables.min.css')); ?>">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-style'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/pages/data-tables.css')); ?>">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="section section-data-tables">
  
  <!-- Page Length Options -->
  <div class="row">
    <div class="col s12">
      <div class="card">
        <div class="card-content">
          <div class="row">
            <div class="col s12">
              <table id="page-length-option" class="display">
                <thead>
                  <tr>
                    <th><?php echo e(__('locale.Start_date')); ?></th>
                    <th><?php echo e(__('locale.ID')); ?></th>
                    <th><?php echo e(__('locale.Brand')); ?></th>
                    <th><?php echo e(__('locale.Year')); ?></th>
                    <th><?php echo e(__('locale.Package')); ?></th>
                    <th><?php echo e(__('locale.Payment')); ?></th>
                    <th>Ptotal</th>
                    <th><?php echo e(__('locale.Description')); ?></th>
					<?php if($user->role != 'client'): ?>
                    <th><?php echo e(__('locale.Full_name')); ?></th>
                    <th><?php echo e(__('locale.Email')); ?></th>
                    <th><?php echo e(__('locale.Edit')); ?></th>
                    <th><?php echo e(__('locale.Issuing')); ?></th>
					<?php endif; ?>
                    <th>PDF</th>
                  </tr>
                </thead>
                <tbody id="quot-list">
				  <?php $__currentLoopData = $data['quotes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($quot['start_date']); ?></td>
						<td><?php echo e($quot['cot_id']); ?></td>
						<td><?php echo e($quot['marca']); ?></td>
						<td><?php echo e($quot['model']); ?></td>
						<?php if($quot['paq'] == 1): ?>
						<td><?php echo e(__('locale.Wide')); ?></td>
						<?php elseif($quot['paq'] == 2): ?>
						<td><?php echo e(__('locale.Limited')); ?></td>
						<?php elseif($quot['paq'] == 3): ?>
						<td><?php echo e(__('locale.RC')); ?></td>
						<?php else: ?>
						<td><?php echo e(__('locale.INTEGRAL')); ?></td>
						<?php endif; ?>
						<?php if($quot['fp'] == 12): ?>
						<td><?php echo e(__('locale.Annual')); ?></td>
						<?php elseif($quot['fp'] == 28): ?>
						<td><?php echo e(__('locale.Semi-annual')); ?></td>
						<?php elseif($quot['fp'] == 29): ?>
						<td><?php echo e(__('locale.Quarterly')); ?></td>
						<?php elseif($quot['fp'] == 27): ?>
						<td><?php echo e(__('locale.Monthly')); ?></td>
						<?php else: ?>
						<td><?php echo e(__('locale.Biweekly')); ?></td>
						<?php endif; ?>
						<td>$ <?php echo e($quot['ptotal']); ?> |MXN</td>
						<td><?php echo e($quot['description']); ?></td>
						<?php if($user->role != 'client'): ?>
						<td><span class="green-text"><?php echo e($quot['firstname']); ?> <?php echo e($quot['lastname']); ?> <?php echo e($quot['paternal_surname']); ?> <?php echo e($quot['maternal_surname']); ?></span></td>
						<td><a href="<?php echo e(route('client-view', $quot['user_id'])); ?>"><?php echo e($quot['email']); ?></a></td>
						<td>
							<?php if($quot['condition'] == 0): ?>
							<a href="<?php echo e(route('quot-edit', $quot['id'])); ?>"><i class="material-icons">mode_edit</i></a>
							<?php else: ?>
							<i class="material-icons">not_interested</i>
							<?php endif; ?>
						</td>
						<td>
							<?php if($quot['condition'] == 1): ?>
							<span class="badge green lighten-5 green-text text-accent-4"><?php echo e(__('locale.Issued')); ?></span>
							<?php else: ?>
							<a href="<?php echo e(route('policy-new', $quot['id'])); ?>"><i class="material-icons">note_add</i></a>
							<?php endif; ?>
						</td>
						<?php endif; ?>
						<td><a href="<?php echo e(route('quot-pdf', $quot['id'])); ?>" target="_blank"><i class="material-icons">picture_as_pdf</i></a></td>
					</tr>
				  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                  <tr>
                    <th><?php echo e(__('locale.Start_date')); ?></th>
                    <th><?php echo e(__('locale.ID')); ?></th>
                    <th><?php echo e(__('locale.Brand')); ?></th>
                    <th><?php echo e(__('locale.Year')); ?></th>
                    <th><?php echo e(__('locale.Package')); ?></th>
                    <th><?php echo e(__('locale.Payment')); ?></th>
                    <th>Ptotal</th>
                    <th><?php echo e(__('locale.Description')); ?></th>
					<?php if($user->role != 'client'): ?>
                    <th><?php echo e(__('locale.Full_name')); ?></th>
                    <th><?php echo e(__('locale.Email')); ?></th>
                    <th><?php echo e(__('locale.Edit')); ?></th>
                    <th><?php echo e(__('locale.Issuing')); ?></th>
					<?php endif; ?>
                    <th>PDF</th>
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('vendor-script'); ?>
<script src="<?php echo e(asset('vendors/data-tables/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendors/data-tables/extensions/responsive/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendors/data-tables/js/dataTables.select.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-script'); ?>
<script src="<?php echo e(asset('js/scripts/data-tables.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.contentLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/dreamy-montalcini.74-208-200-19.plesk.page/htdocs/local/resources/views/pages/quot-list.blade.php ENDPATH**/ ?>