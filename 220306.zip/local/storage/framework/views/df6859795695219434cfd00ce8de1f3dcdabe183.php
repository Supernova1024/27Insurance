<div style="bottom: 50px; right: 19px;" class="fixed-action-btn direction-top">
	<a class="btn-floating btn-large pulse gradient-45deg-light-blue-cyan gradient-shadow">
		<i class="material-icons">local_phone</i>
	</a>
    <ul>
        <li><a href="tel:8008343400" target="_blank" class="btn-floating green">ABA</a></li>
        <li><a href="tel:8009001292" target="_blank" class="btn-floating blue">AXA</a></li>
        <li><a href="tel:8009112627" target="_blank" class="btn-floating gray">ANA</a></li>
        <li><a href="tel:8000196000" target="_blank" class="btn-floating red">HDI</a></li>
        <li><a href="tel:8008002880" target="_blank" class="btn-floating purple">QUA</a></li>
    </ul>
</div><?php /**PATH /var/www/vhosts/dreamy-montalcini.74-208-200-19.plesk.page/htdocs/local/resources/views/pages/sidebar/fab-menu.blade.php ENDPATH**/ ?>