Hola <?php echo e($email_data['name']); ?>

<br><br>
Bienvenido a visitar nuestro sitio.
<br>
Estamos asombrados de que seas parte de nuestra familia.
<br>
Por favor confirmar.
<br>
<a href="<?php echo e(asset('verify?code=' . $email_data['verification_code'])); ?>">Click Here!</a>
<br><br>
¡Gracias!<?php /**PATH /var/www/vhosts/dreamy-montalcini.74-208-200-19.plesk.page/htdocs/local/resources/views/mail/signup-email.blade.php ENDPATH**/ ?>