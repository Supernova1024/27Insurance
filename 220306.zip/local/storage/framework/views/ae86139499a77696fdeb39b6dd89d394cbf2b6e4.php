<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row justify-content-center">
    <div class="col-md-8">
      <div class="card">
        <div class="card-content">
        <div class="card-title"><?php echo e(__('locale.Verify_txt1')); ?></div>
          <?php if(session('resent')): ?>
          <div class="card-alert card green lighten-5" role="alert">
              <div class="card-content green-text">
                <?php echo e(__('locale.Verify_txt2')); ?>

              </div>
          </div>
          <?php endif; ?>

          <?php echo e(__('locale.Verify_txt3')); ?>

          <?php echo e(__('locale.Verify_txt4')); ?>,
          <form class="d-inline" method="POST" action="<?php echo e(route('verification.resend')); ?>">
              <?php echo csrf_field(); ?>
              <button type="submit"
                  class="waves-effect waves-light btn"><?php echo e(__('locale.Verify_txt5')); ?></button>.
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.fullLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/dreamy-montalcini.74-208-200-19.plesk.page/htdocs/local/resources/views/auth/verify.blade.php ENDPATH**/ ?>