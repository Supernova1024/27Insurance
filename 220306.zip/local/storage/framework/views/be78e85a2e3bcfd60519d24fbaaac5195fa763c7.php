<?php $__env->startSection('title','Report'); ?>


<?php $__env->startSection('content'); ?>
<div class="seaction">
   <!--Line Chart-->
   <div id="chartjs-line-chart" class="card">
      <div class="card-content">
         <h4 class="card-title"><?php echo e(__('locale.Quotation')); ?></h4>
         <p class="caption">
         </p>
         <div class="row">
            <div class="col s12">
               <p class="mb-2">
               </p>
               <div class="sample-chart-wrapper"><canvas id="quot-chart" height="400"></canvas></div>
            </div>
         </div>
      </div>
   </div>
	
   <!--Line Chart-->
   <div id="chartjs-line-chart" class="card">
      <div class="card-content">
         <h4 class="card-title"><?php echo e(__('locale.Policy')); ?></h4>
         <p class="caption">
         </p>
         <div class="row">
            <div class="col s12">
               <p class="mb-2">
               </p>
               <div class="sample-chart-wrapper"><canvas id="line-chart" height="400"></canvas></div>
            </div>
         </div>
      </div>
   </div>
	
   <!--Bar Chart-->
   <div id="chartjs-bar-chart" class="card">
      <div class="card-content">
         <h4 class="card-title"><?php echo e(__('locale.Company')); ?></h4>
         <div class="row">
            <div class="col s12">
               <p class="mb-2">
               </p>
               <div class="sample-chart-wrapper"><canvas id="bar-chart" height="400"></canvas></div>
            </div>
         </div>
      </div>
   </div>
	
   <!--Line Chart-->
   <div id="chartjs-line-chart" class="card">
      <div class="card-content">
         <h4 class="card-title"><?php echo e(__('locale.Ptotal')); ?></h4>
         <p class="caption">
         </p>
         <div class="row">
            <div class="col s12">
               <p class="mb-2">
               </p>
               <div class="sample-chart-wrapper"><canvas id="ptotal-chart" height="400"></canvas></div>
            </div>
         </div>
      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('vendor-script'); ?>
<script src="<?php echo e(asset('vendors/chartjs/chart.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-script'); ?>
<script src="<?php echo e(asset('js/scripts/charts-chartjs.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.contentLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/dreamy-montalcini.74-208-200-19.plesk.page/htdocs/local/resources/views//pages/report.blade.php ENDPATH**/ ?>