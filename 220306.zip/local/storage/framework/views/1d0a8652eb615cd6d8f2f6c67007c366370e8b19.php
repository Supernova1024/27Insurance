<?php $__env->startSection('title','Chat'); ?>


<?php $__env->startSection('page-style'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/pages/app-chat.css')); ?>">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="chat-application">
  <div class="chat-content-head">
    <div class="header-details">
      <h5 class="m-0 sidebar-title"><i class="material-icons app-header-icon text-top">mail_outline</i> Chat</h5>
    </div>
  </div>
  <div class="app-chat">
    <div class="content-area content-right">
      <div class="app-wrapper">
        <!-- Sidebar menu for small screen -->
        <a data-target="chat-sidenav" class="sidenav-trigger hide-on-large-only">
          <i class="material-icons">menu</i>
        </a>
        <!--/ Sidebar menu for small screen -->

        <div class="card card card-default scrollspy border-radius-6 fixed-width">
          <div class="card-content chat-content p-0">
            <!-- Sidebar Area -->
            <div class="sidebar-left sidebar-fixed animate fadeUp animation-fast">
              <div class="sidebar animate fadeUp">
                <div class="sidebar-content">
                  <div id="sidebar-list" class="sidebar-menu chat-sidebar list-group position-relative">
                    <div class="sidebar-list-padding app-sidebar sidenav" id="chat-sidenav">
                      <!-- Sidebar Header -->
                      <div class="sidebar-header">
                        <div class="row valign-wrapper">
                          <div class="col s2 media-image pr-0">
                            <img src="<?php echo e(asset('images/user/'. $user->image)); ?>" alt="" class="circle z-depth-2 responsive-img">
                          </div>
                          <div class="col s10">
							<p class="user_id" id="<?php echo e($user->id); ?>" style="display:none;"></p>
							<p class="user_img" id="<?php echo e($user->image); ?>" style="display:none;"></p>
                            <p class="m-0 blue-grey-text text-darken-4 font-weight-700"><?php echo e($user->firstname); ?> <?php echo e($user->lastname); ?></p>
                            <p class="m-0 info-text"><?php echo e($user->role); ?></p>
                          </div>
                        </div>
                      </div>
                      <!--/ Sidebar Header -->

                      <!-- Sidebar Search -->
                      <div class="sidebar-search animate fadeUp">
                        <div class="search-area">
                          <i class="material-icons search-icon">search</i>
                          <input type="text" placeholder="<?php echo e(__('locale.Search')); ?>" class="app-filter">
                        </div>
                      </div>
                      <!--/ Sidebar Search -->

                      <!-- Sidebar Content List -->
                      <div class="sidebar-content sidebar-chat">
                        <div class="chat-list" id="chat-list">
						  <?php $__currentLoopData = $data['staffs']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						  <div class="chat-user animate fadeUp delay" id=<?php echo e($staff['email']); ?>>
                            <div class="user-section">
                              <div class="row valign-wrapper">
                                <div class="col s2 media-image online pr-0">
                                  <img src="<?php echo e(asset('images/user/'. $staff['image'])); ?>" alt="" class="circle z-depth-2 responsive-img">
                                </div>
                                <div class="col s10">
                                  <p class="m-0 blue-grey-text text-darken-4 font-weight-700"><?php echo e($staff['firstname']); ?> <?php echo e($staff['lastname']); ?></p>
								  <?php if(strlen($staff['message']) < 30): ?>
                                  <p class="m-0 info-text"><?php echo e($staff['message']); ?></p>
								  <?php else: ?>
								  <p class="m-0 info-text"><?php echo e(substr($staff['message'], 0, 30)); ?>...</p>
								  <?php endif; ?>
                                </div>
                              </div>
                            </div>
                            <div class="info-section">
                              <div class="star-timing">
                                <div class="time">
								  <?php if($staff['count'] != 0): ?>
								  <span id="count" class="badge badge pill red"><?php echo e($staff['count']); ?></span>
								  <?php endif; ?>
                                </div>
                              </div>
                              <!-- <span>2.38 pm</span> -->
                            </div>
                          </div>
					      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="no-data-found">
                          <h6 class="center">No Results Found</h6>
                        </div>
                      </div>
                      <!--/ Sidebar Content List -->
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!--/ Sidebar Area -->

            <!-- Content Area -->
            <div class="chat-content-area animate fadeUp">
              <!-- Chat header -->
              <div class="chat-header">
                <div class="row valign-wrapper" id="chat_header">
                  <div class="col media-image online pr-0">
                    <img src="<?php echo e(asset('images/user/'. $data['client']['image'])); ?>" alt="" class="circle z-depth-2 responsive-img">
					<p id="img" style="display:none;"><?php echo e(asset('images/user/'. $data['client']['image'])); ?></p>
                  </div>
                  <div class="col">
                    <p class="m-0 blue-grey-text text-darken-4 font-weight-700"><?php echo e($data['client']['firstname']); ?> <?php echo e($data['client']['lastname']); ?></p>
                    <p class="m-0 chat-text truncate"><?php echo e($data['client']['role']); ?></p>
					<p id="to_user" style="display:none;"><?php echo e($data['client']['id']); ?></p>
					<p id="to_email" style="display:none;"><?php echo e($data['client']['email']); ?></p>
                  </div>
                </div>
              </div>
              <!--/ Chat header -->

              <!-- Chat content area -->
              <div class="chat-area">
                <div class="chats">
					<div class="chats" id="chat_content">
						<?php $__currentLoopData = $data['messages']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						  <?php if($user->id != $message['recipient_id']): ?>
							<div class="chat chat-right">
							  <div class="chat-avatar">
								<a class="avatar">
								  <img src="<?php echo e(asset('images/user/'. $user->image)); ?>" class="circle" alt="avatar" />
								</a>
							  </div>
							  <div class="chat-body">
								<div class="chat-text">
								  <?php if($message['type'] != "Str"): ?>
									<div class="img-box grey lighten-4 border-radius-6">
										<div class="card-image">
											<img src="<?php echo e(asset('local/storage/attached/'. $message['message'])); ?>" class="responsive-img" data-xblocker="passed">
										</div>
										<div class="card-content">
											<span class="left"> <?php echo e($message['message']); ?></span>
											<a href="<?php echo e(asset('download/'. $message['message'])); ?>" class="Right">
												<i class="material-icons">file_download</i>
											</a>
										</div>
									</div>
								   <?php else: ?>
								  	<p><?php echo e($message['message']); ?></p>
								   <?php endif; ?>
								</div>
							  </div>
							</div>
						  <?php else: ?>
							<div class="chat">
							  <div class="chat-avatar">
								<a class="avatar">
								  <img src="<?php echo e(asset('images/user/'. $data['client']['image'])); ?>" class="circle" alt="avatar" />
								</a>
							  </div>
							  <div class="chat-body">
								<div class="chat-text">
									<?php if($message['type'] != "Str"): ?>
									<div class="img-box grey lighten-4 border-radius-6">
										<div class="card-image">
											<img src="<?php echo e(asset('local/storage/attached/'. $message['message'])); ?>" class="responsive-img" data-xblocker="passed"> 
										</div>
										<div class="card-content">
											<span class="left"> <?php echo e($message['message']); ?></span>
											<a href="<?php echo e(asset('download/'. $message['message'])); ?>" class="Right">
												<i class="material-icons">file_download</i>
											</a>
										</div>
									</div>
								   <?php else: ?>
								  	<p><?php echo e($message['message']); ?></p>
								   <?php endif; ?>
								</div>
							  </div>
							</div>
						  <?php endif; ?>
					    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
                </div>
              </div>
              <!--/ Chat content area -->

              <!-- Chat footer <-->
              <div class="chat-footer">
				<form id="chat_message" enctype="multipart/form-data">
				<?php echo e(csrf_field()); ?>

                <div class="chat-input">
				  <!--<i class="material-icons mr-2">face</i> -->
                  <i id="attach" class="material-icons mr-2">attachment</i>
				  <input type="text" id="to" name="to" value="<?php echo e($data['client']['id']); ?>" style="display:none">
				  <input type="file" id="attach" name="attach" style="display:none">
                  <input type="text" placeholder="Type message here.." class="message mb-0">
                  <a class="btn waves-effect waves-light send" id="submit"><?php echo e(__('locale.Send')); ?></a>
                </div>
				</form>
              </div>
              <!--/ Chat footer -->
            </div>
            <!--/ Content Area -->
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-script'); ?>
<script src="<?php echo e(asset('js/scripts/app-chat.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.contentLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/dreamy-montalcini.74-208-200-19.plesk.page/htdocs/local/resources/views/pages/app-chat.blade.php ENDPATH**/ ?>