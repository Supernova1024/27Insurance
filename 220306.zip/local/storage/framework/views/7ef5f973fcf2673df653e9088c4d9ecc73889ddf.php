<?php $__env->startSection('title','Client Edit'); ?>


<?php $__env->startSection('vendor-style'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendors/select2/select2.min.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendors/select2/select2-materialize.css')); ?>">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-style'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/pages/page-users.css')); ?>">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<!-- users edit start -->
<div class="section users-edit">
  <div class="card">
    <div class="card-content">
      <div class="row">
        <div class="col s12" id="account">
          <!-- users edit media object start -->
          <div class="media display-flex align-items-center mb-2">
            <a class="mr-2" href="#">
              <img src="<?php echo e(asset('images/user/'. $data['client']['image'])); ?>" alt="users avatar" class="z-depth-4 circle"
                height="64" width="64">
            </a>
          </div>
          <!-- users edit media object ends -->
          <!-- users edit account form start -->
          <form id="accountForm" action="<?php echo e(asset('client/'. $data['client']['id'])); ?>" method="POST">
			  <?php echo e(csrf_field()); ?>

            <div class="row">
				<div class="col s12 m6 l3 input-field">
					<input id="firstname" name="firstname" type="text" class="validate" value="<?php echo e($data['client']['firstname']); ?>"
						   data-error=".errorTxt1">
					<label for="firstname"><?php echo e(__('locale.Firstname')); ?></label>
					<small class="errorTxt1"></small>
				</div>
				<div class="col s12 m6 l3 input-field">
					<input id="lastname" name="lastname" type="text" class="validate" value="<?php echo e($data['client']['lastname']); ?>"
						   data-error=".errorTxt1">
					<label for="lastname"><?php echo e(__('locale.Lastname')); ?></label>
					<small class="errorTxt1"></small>
				</div>
				<div class="col s12 m6 l3 input-field">
					<input id="paternal" name="paternal" type="text" class="validate" value="<?php echo e($data['client']['paternal_surname']); ?>"
						   data-error=".errorTxt1">
					<label for="paternal"><?php echo e(__('locale.Paternal')); ?></label>
					<small class="errorTxt1"></small>
				</div>
				<div class="col s12 m6 l3 input-field">
					<input id="maternal" name="maternal" type="text" class="validate" value="<?php echo e($data['client']['maternal_surname']); ?>"
						   data-error=".errorTxt1">
					<label for="maternal"><?php echo e(__('locale.Maternal')); ?></label>
					<small class="errorTxt1"></small>
				</div>
				<div class="col s12 m6 input-field">
					<input id="email" name="email" type="email" class="validate" value="<?php echo e($data['client']['email']); ?>"
                      data-error=".errorTxt3">
                    <label for="email"><?php echo e(__('locale.Email')); ?></label>
                    <small class="errorTxt3"></small>
				</div>
				<div class="col s12 m6 input-field">
					<input id="datepicker" name="birthday" type="text"
                      value="<?php echo e($data['client']['birthday']); ?>" data-error=".errorTxt4">
                    <label for="datepicker"><?php echo e(__('locale.Birthday')); ?></label>
                    <small class="errorTxt4"></small>
				</div>
				<div class="col s12 m6 input-field">
					<select name="sex">
                      <option disabled <?php echo $data['client']['sex'] == null ? 'selected' : ''; ?>><?php echo e(__('locale.Select')); ?></option>
					  <option value="male" <?php echo $data['client']['sex'] == 'male' ? 'selected' : ''; ?>><?php echo e(__('locale.Male')); ?></option>
                      <option value="female" <?php echo $data['client']['sex'] == 'female' ? 'selected' : ''; ?>><?php echo e(__('locale.Female')); ?></option>
                    </select>
                    <label><?php echo e(__('locale.Sex')); ?></label>
				</div>
				<div class="col s12 m6 input-field">
					<select name="marital">
					  <option disabled <?php echo $data['client']['marital'] == null ? 'selected' : ''; ?>><?php echo e(__('locale.Select')); ?></option>
                      <option value="1" <?php echo $data['client']['marital'] == '1' ? 'selected' : ''; ?>><?php echo e(__('locale.Married')); ?></option>
                      <option value="2" <?php echo $data['client']['marital'] == '2' ? 'selected' : ''; ?>><?php echo e(__('locale.Single')); ?></option>
					  <option value="3" <?php echo $data['client']['marital'] == '3' ? 'selected' : ''; ?>><?php echo e(__('locale.Widower')); ?></option>
                      <option value="4" <?php echo $data['client']['marital'] == '4' ? 'selected' : ''; ?>><?php echo e(__('locale.Divorced')); ?></option>
                    </select>
                    <label><?php echo e(__('locale.Marital')); ?> <?php echo e(__('locale.Status')); ?></label>
				</div>
				<div class="col s12 input-field">
					<textarea id="address" name="address" class="materialize-textarea"><?php echo e($data['client']['address']); ?></textarea>
					<label for="addrss"><?php echo e(__('locale.Address')); ?></label>
				</div>
				<div class="col s12 m6 input-field">
					<input id="phone" name="phone" type="text" class="validate" value="<?php echo e($data['client']['phone']); ?>"
						   data-error=".errorTxt1">
					<label for="phone"><?php echo e(__('locale.Phone')); ?></label>
					<small class="errorTxt1"></small>
				</div>
				<div class="col s12 m6 input-field">
					<input id="telephone" name="telephone" type="text" class="validate" value="<?php echo e($data['client']['telephone']); ?>"
						   data-error=".errorTxt1">
					<label for="telephone"><?php echo e(__('locale.Telephone')); ?></label>
					<small class="errorTxt1"></small>
				</div>
              <div class="col s12">
                <button type="submit" class="btn indigo" id="submit" style="display: none;"></button>
				<a class="btn cyan waves-effect waves-light modal-trigger right" href="#modal1"><?php echo e(__('locale.Save')); ?></a>
				  <div id="modal1" class="modal">
					  <div class="modal-content">
						  <h4><?php echo e(__('locale.Confirm_title')); ?></h4>
						  <p><?php echo e(__('locale.Confirm')); ?></p>
					  </div>
					  <div class="modal-footer">
						  <a id="yes" class="modal-action modal-close btn cyan waves-effect waves-light"><?php echo e(__('locale.Yes')); ?></a>
						  <a class="modal-action modal-close btn waves-effect waves-light"><?php echo e(__('locale.No')); ?></a>
					  </div>
				  </div>
              </div>
            </div>
          </form>
          <!-- users edit account form ends -->
        </div>
      </div>
      <!-- </div> -->
    </div>
  </div>
</div>
<!-- users edit ends -->
<?php $__env->stopSection(); ?>


<?php $__env->startSection('vendor-script'); ?>
<script src="<?php echo e(asset('vendors/select2/select2.full.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendors/jquery-validation/jquery.validate.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-script'); ?>
<script src="<?php echo e(asset('js/scripts/page-users.js')); ?>"></script>
<script src="<?php echo e(asset('js/scripts/advance-ui-modals.js')); ?>"></script>
<script src="<?php echo e(asset('js/scripts/edit.js')); ?>"></script>
<script type="text/javascript">
	(function($insura, $) {
		$(document).ready(function() {
			$insura.helpers.listenForChats();
		});
	})(window.insura, window.jQuery);
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.contentLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/dreamy-montalcini.74-208-200-19.plesk.page/htdocs/local/resources/views/pages/client-edit.blade.php ENDPATH**/ ?>