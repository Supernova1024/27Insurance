<?php $__env->startSection('title','Policy List'); ?>


<?php $__env->startSection('vendor-style'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendors/flag-icon/css/flag-icon.min.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendors/data-tables/css/jquery.dataTables.min.css')); ?>">
<link rel="stylesheet" type="text/css"
  href="<?php echo e(asset('vendors/data-tables/extensions/responsive/css/responsive.dataTables.min.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendors/data-tables/css/select.dataTables.min.css')); ?>">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-style'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/pages/data-tables.css')); ?>">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="section section-data-tables">
  <!-- Page Length Options -->
  <div class="row">
    <div class="col s12">
      <div class="card">
        <div class="card-content">
          <div class="row">
            <div class="col s12">
              <table id="page-length-option" class="display">
                <thead>
                  <tr>
                    <th><?php echo e(__('locale.Start_date')); ?></th>
                    <th><?php echo e(__('locale.End_date')); ?></th>
                    <th><?php echo e(__('locale.ID')); ?></th>
                    <th><?php echo e(__('locale.Brand')); ?></th>
                    <th><?php echo e(__('locale.Year')); ?></th>
                    <th><?php echo e(__('locale.Package')); ?></th>
                    <th><?php echo e(__('locale.Payment')); ?></th>
                    <th>IVA</th>
                    <th>Pneta</th>
                    <th>Ptotal</th>
                    <th><?php echo e(__('locale.Description')); ?></th>
                    <th><?php echo e(__('locale.Serie')); ?></th>
                    <th><?php echo e(__('locale.Motor')); ?></th>
					<th><?php echo e(__('locale.Plates')); ?></th>
                    <th><?php echo e(__('locale.Reference')); ?></th>
					<th><?php echo e(__('locale.Status')); ?></th>
					<?php if($user->role != 'client'): ?>
                    <th><?php echo e(__('locale.Email')); ?></th>
                    <th><?php echo e(__('locale.Client')); ?></th>
					<th><?php echo e(__('locale.Edit')); ?></th>
					<?php endif; ?>
					<th>PDF</th>
                  </tr>
                </thead>
                <tbody>
				  <?php $__currentLoopData = $data['policies']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $policy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($policy['start_date']); ?></td>
						<?php if($policy['status'] == 1): ?>
							<?php if($policy['end_date'] > date('Y-m-d')): ?>
							<td><span class="task-cat cyan"><?php echo e($policy['end_date']); ?></span></td>
							<?php else: ?>
							<td><span class="task-cat deep-orange accent-2"><?php echo e($policy['end_date']); ?></span></td>
							<?php endif; ?>
						<?php else: ?>
							<td><span class="task-cat red accent-2"><?php echo e($policy['cancel_date']); ?></span></td>
						<?php endif; ?>
						<td><?php echo e($policy['cve']); ?><?php echo e($policy['pol']); ?></td>
						<td><?php echo e($policy['marca']); ?></td>
						<td><?php echo e($policy['model']); ?></td>
						<?php if($policy['paq'] == 1): ?>
						<td><?php echo e(__('locale.Wide')); ?></td>
						<?php elseif($policy['paq'] == 2): ?>
						<td><?php echo e(__('locale.Limited')); ?></td>
						<?php elseif($policy['paq'] == 3): ?>
						<td><?php echo e(__('locale.RC')); ?></td>
						<?php else: ?>
						<td><?php echo e(__('locale.INTEGRAL')); ?></td>
						<?php endif; ?>
						<?php if($policy['fp'] == 12): ?>
						<td><?php echo e(__('locale.Annual')); ?></td>
						<?php elseif($policy['fp'] == 28): ?>
						<td><?php echo e(__('locale.Semi-annual')); ?></td>
						<?php elseif($policy['fp'] == 29): ?>
						<td><?php echo e(__('locale.Quarterly')); ?></td>
						<?php elseif($policy['fp'] == 27): ?>
						<td><?php echo e(__('locale.Monthly')); ?></td>
						<?php else: ?>
						<td><?php echo e(__('locale.Biweekly')); ?></td>
						<?php endif; ?>
						<td>$ <?php echo e($policy['iva']); ?> |MXN</td>
						<td>$ <?php echo e($policy['pneta']); ?> |MXN</td>
						<td>$ <?php echo e($policy['ptotal']); ?> |MXN</td>
						<td><?php echo e($policy['description']); ?></td>
						<td><?php echo e($policy['serie']); ?></td>
						<td><?php echo e($policy['motor']); ?></td>
						<td><?php echo e($policy['plates']); ?></td>
						<td><?php echo e($policy['reference']); ?></td>
						<?php if($policy['status'] == 1): ?>
						<?php if($policy['end_date'] > date('Y-m-d')): ?>
						<td><span class="task-cat cyan"><?php echo e(__('locale.Valid')); ?></span></td>
						<?php else: ?>
						<td><span class="task-cat deep-orange accent-2"><?php echo e(__('locale.Expired')); ?></span></td>
						<?php endif; ?>
						<?php else: ?>
						<td><span class="task-cat red accent-2"><?php echo e(__('locale.Canceled')); ?></span></td>
						<?php endif; ?>
						<?php if($user->role != 'client'): ?>
						<td><?php echo e($policy['email']); ?></td>
						<td><?php echo e($policy['firstname']); ?> <?php echo e($policy['lastname']); ?> <?php echo e($policy['paternal_surname']); ?> <?php echo e($policy['maternal_surname']); ?></td>
						<td><a href="<?php echo e(route('policy-edit', $policy['id'])); ?>"><i class="material-icons">mode_edit</i></a></td>  
						<?php endif; ?>
						<td><a href="<?php echo e(route('policy-pdf', $policy['id'])); ?>" target="_blank"><i class="material-icons">picture_as_pdf</i></a></td>
					</tr>
				  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                  <tr>
                    <th><?php echo e(__('locale.Start_date')); ?></th>
                    <th><?php echo e(__('locale.End_date')); ?></th>
                    <th><?php echo e(__('locale.ID')); ?></th>
                    <th><?php echo e(__('locale.Brand')); ?></th>
                    <th><?php echo e(__('locale.Year')); ?></th>
                    <th><?php echo e(__('locale.Package')); ?></th>
                    <th><?php echo e(__('locale.Payment')); ?></th>
                    <th>IVA</th>
                    <th>Pneta</th>
                    <th>Ptotal</th>
                    <th><?php echo e(__('locale.Description')); ?></th>
                    <th><?php echo e(__('locale.Serie')); ?></th>
                    <th><?php echo e(__('locale.Motor')); ?></th>
					<th><?php echo e(__('locale.Plates')); ?></th>
                    <th><?php echo e(__('locale.Reference')); ?></th>
					<th><?php echo e(__('locale.Status')); ?></th>
					<?php if($user->role != 'client'): ?>
                    <th><?php echo e(__('locale.Email')); ?></th>
                    <th><?php echo e(__('locale.Client')); ?></th>
					<th><?php echo e(__('locale.Edit')); ?></th>
					<?php endif; ?>
					<th>PDF</th>
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('vendor-script'); ?>
<script src="<?php echo e(asset('vendors/data-tables/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendors/data-tables/extensions/responsive/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendors/data-tables/js/dataTables.select.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-script'); ?>
<script src="<?php echo e(asset('js/scripts/data-tables.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.contentLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/dreamy-montalcini.74-208-200-19.plesk.page/htdocs/local/resources/views/pages/policy-list.blade.php ENDPATH**/ ?>