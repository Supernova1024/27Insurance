<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePoliciesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('policies', function (Blueprint $table) {
            $table->id();
            $table->integer('quot_id')->unsigned();
            $table->string('cve', 8)->nullable()->default(null);
            $table->string('pol', 16)->unsigned();
			$table->string('owner', 100)->nullable()->default(null);
			$table->string('issuer', 32)->nullable()->default(null);
            $table->string('serie', 60)->nullable()->default(null);
            $table->string('motor', 60)->nullable()->default(null);
            $table->string('plates', 100)->nullable()->default(null);
            $table->string('reference', 32)->nullable()->default(null);
			$table->string('ASEGID', 12)->nullable()->default(null);
			$table->string('ASEGDIRID', 12)->nullable()->default(null);
			$table->string('PROPID', 12)->nullable()->default(null);
			$table->string('PROPDIRID', 12)->nullable()->default(null);
			$table->string('BENEFID', 12)->nullable()->default(null);
			$table->string('BENEFDIRID', 12)->nullable()->default(null);
            $table->enum('status', array('1', '0'));
            $table->date('cancel_date');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('policies');
    }
}
