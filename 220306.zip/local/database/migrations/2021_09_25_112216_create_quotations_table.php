<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateQuotationsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('quotations', function (Blueprint $table) {
            $table->id();
            $table->integer('cot_id')->unsigned();
            $table->integer('user_id')->unsigned();
			$table->integer('ver_id')->nullable()->default(null);
            $table->integer('cotinc_id')->nullable()->default(null);
            $table->integer('verinc_id')->nullable()->default(null);
            $table->string('colonia', 11)->nullable()->default(null);
            $table->string('municipality', 11)->nullable()->default(null);
            $table->string('cveveh', 20)->nullable()->default(null);
			$table->string('marca', 11)->nullable()->default(null);
            $table->string('model', 11)->nullable()->default(null);
            $table->string('description', 256)->nullable()->default(null);
            $table->enum('fp', array('31', '29', '28', '27', '25', '12'));
            $table->enum('paq', array('1', '2', '3', '460'));
            $table->enum('condition', array('1', '0'));
            $table->float('DER')->default(0);
			$table->float('REC')->default(0);
			$table->float('DES')->default(0);
			$table->float('BON')->default(0);
            $table->float('iva')->default(0);
            $table->float('pneta')->default(0);
            $table->float('ptotal')->default(0);
			$table->enum('company', array('ABA', 'AXA', 'QUA', 'BAN', 'HDI', 'MAP'));
			$table->date('start_date');
            $table->date('end_date');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('quotations');
    }
}
