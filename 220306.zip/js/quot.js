 (function($) {
	
	var mod, brand, brand_name, subBrand, subBrands, model_id, drive_mode, model_select, email, municipality, car_status, description, qualitas, descriptiones, qualitas_des, first_name, surname, paternal, maternal, post_code, RFC, birthdate, ver_id, cotinc_id, verinc_id, ABA, QUAL;
	var des, DER, REC, DES, BON, iva, pneta, ptotal, start_date, end_date, qual_DER, qual_REC, qual_iva, qual_pneta, qual_ptotal, select_cotid;
	var cveveh = 0,
		camis = 0,
		qual_cotid = 0,
		cot_id = 0, 
		currenturl = window.location.href,
		url_array = currenturl.split('/'),
		url = url_array[0] + '//' + url_array[2],
		manual = false,
		automatic = false,
		payment_method = '12',
		plan_type = '1',
		qual_flag = true,
		aba_flag = true,
		flag = 0;
	$('#datepicker').datepicker({"format":'yyyy-mm-dd', yearRange: 71} );
	function preloader(){
		$('div#preloader').css("display","");
		$('div#step').css("display","none");
	}
	function loader(){
		$('div#preloader').css("display","none");
		$('div#step').css("display","");
	}
	function getBrand(){
		preloader();
		$.ajaxSetup({ headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') }});
		$.ajax({ url:currenturl+"/subBrands", data:{ id: brand }, type:'post',
				success: function(result){
					if (result.length > 1 ){
						var as = "";
						result.forEach(function(item) {
							as += '<div class="input-field col s12" style="text-align:center;"><a id="' + item['ID'] + '" class="btn waves-effect waves-light cyan" style="width:100%"><p id="' + item['DESC'] + '">' + item['DESC'] + '</p></a></div>';
						});
						$("#subbrand").html(as);
						$('#modal2').modal('open');
					} else{
						$("#subBrand").html(result['DESC']);
						subBrand = result['ID'];
						$('#modal3').modal('open');
					}
					loader();
				},
				error: function(result){
					loader();
					alert("Selection Failed. Please try again!");
				}
		});
	}
	$('#select_brand').on('change', function (e) {
		var optionSelected = $("option:selected", this);
		brand = this.value;
		brand_name = $('#brand_' + brand).html();
		$('#brand').html(brand_name);
		$('#modal1').modal('close');
		getBrand();
	});
	$('div#brand_img').click(function(e){
		brand = $(this).children('img').attr('id');
		brand_name = $(this).children('p').html();
		$('#brand').html(brand_name);
		$('#modal1').modal('close');
		getBrand();
	});
	$('div#subbrand').on("click", "a.btn", function(event){
		subBrand = $(this).attr('id');
		var subBrand_name = $(this).children('p').attr('id');
		$('a#subBrand').html(subBrand_name);
		$('#modal2').modal('close');
		$('#modal3').modal('open');
	});
	function getYear(){
		preloader();
		$.ajaxSetup({ headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') }});
		$.ajax({ url:currenturl+"/models", data:{ date: mod, marca_id: brand, submarca_id: subBrand }, type:'post',
				success: function(result){
					console.log(result);
					if (result.length > 1 ){
						var as = "";
						result.forEach(function(item) {
							as += '<div class="input-field col s12" style="text-align:center;"><a id="' + item['ID'] + '" class="btn waves-effect waves-light cyan" style="width:100%"><p id="' + item['DESC'] + '">' + item['DESC'] + '</p></a></div>';
						});
						$("div#model").html(as);
						$('#modal4').modal('open');
					} else if(result.length == 1){
						model_id = result['ID'];
						$("a#model").html(result['DESC']);
					}
					loader();
				},
				error: function(result){
					loader();
					alert("Selection Failed. Please try again!");
				}
		});
	}
	$('#select_year').on('change', function (e) {
		var optionSelected = $("option:selected", this);
		mod = this.value;
		$('a#year').html(mod);
		$('#modal3').modal('close');
		getYear();
	});
	$('div#mod').children('a').click(function (e){
		mod = $(this).attr('id');
		$('a#year').html(mod);
		$('#modal3').modal('close');
		getYear();
	});
	$('div#model').on("click", "a.btn", function(event){
		model_id = $(this).attr('id');
		model_select = $(this).children('p').attr('id');
		$('a#model').html(model_select);
		$('#modal4').modal('close');
		preloader();
		$.ajaxSetup({ headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') }});
		$.ajax({ url:currenturl+"/description", data:{ date: mod, tipoveh: model_id, marca: brand_name, tipo: model_select}, type:'post',
				success: function(result){
					console.log(result);
					descriptiones = result['DESCRIPCION'];
					qualitas = result['Elemento'];
					if(typeof descriptiones !== "undefined"){
					if(descriptiones.length > 1){
						descriptiones.forEach(function(item) {
							if (item['DESC'].includes('STD')) {
								manual = true;
								$("div#manual").css("display","");
							} else {
								automatic = true;
								$("div#automatic").css("display","");
							}
						});
					} else if (descriptiones.length !== "undefined") {
						if (descriptiones['DESC'].includes('STD')) {
							manual = true;
							drive_mode = 'manual';
							$("div#manual").css("display","");
						} else {
							automatic = true;
							drive_mode = 'automatic';
							$("div#automatic").css("display","");
						}
					} 
					}
					if(typeof qualitas !== "undefined"){
					if(qualitas.length > 1){
						qualitas.forEach(function(item) {
							if (item['cVersion'].includes('STD')) {
								manual = true;
								$("div#manual").css("display","");
							} else {
								automatic = true;
								$("div#automatic").css("display","");
							}
						});
					} else if (qualitas.length !== "undefined") {
						if (qualitas['cVersion'].includes('STD')) {
							manual = true;
							drive_mode = 'manual';
							$("div#manual").css("display","");
						} else {
							automatic = true;
							drive_mode = 'automatic';
							$("div#automatic").css("display","");
						}
					}
					}
					if (manual == false & automatic == true) {
						$("input#manual").attr('checked', false);
						$("input#automatic").attr('checked', true);
						drive_mode = 'automatic';
						$("button#next1").attr('disabled', false);
					} else if (manual == true & automatic == false) {
						$("input#manual").attr('checked', true);
						$("input#automatic").attr('checked', false);
						drive_mode = 'manual';
						$("button#next1").attr('disabled', false);
					} else if (manual == true & automatic == true) {
						$("input#manual").attr('checked', true);
						$('input#manual').parent().click();
						$("input#automatic").attr('checked', false);
					} 
					loader();
				},
				error: function(result){
					loader();
					alert("Selection Failed. Please try again!");
				}
			   });
	});
	$('input#manual').parent().click(function (e){
		drive_mode = 'manual';
		$("button#next1").attr('disabled', false);
		car_status = 1;
	});
	$('input#automatic').parent().click(function (e){
		drive_mode = 'automatic';
		$("button#next1").attr('disabled', false);
		car_status = 0;
	});
	$('button#next1').click(function (e){
	  if(brand != null && mod != null && model_id != null && drive_mode != null){
		  var dec = '<h4 class="card-title">' + brand_name + '&nbsp;&nbsp;' + mod + '&nbsp;&nbsp;' + model_select + '&nbsp;&nbsp;' + drive_mode + '</h4>';
		  $('div#dec').html(dec);
		  ABA = url + "/images/logo/aba.png";
		  QUAL = url + "/images/logo/qualitas.png";
		  var as = '<img src="' + ABA + '" style="width:200px; height:50px;"><br>';
		  if(typeof descriptiones !== "undefined"){
			  if (descriptiones.length > 1 ){
				  descriptiones.forEach(function(item) {
					  if(drive_mode == 'automatic'){
						  if (!item['DESC'].includes('STD')) {
							  as += '<p class="mb-1"><label><input id="' + item['CVEVEH'] + '" name="group2" type="radio"><span id="' + item['DESC'] + '">' + item['DESC'] + ' </span></label></p>';
						  }
					  } else{
						  if (item['DESC'].includes('STD')) {
							  as += '<p class="mb-1"><label><input id="' + item['CVEVEH'] + '" name="group2" type="radio"><span id="' + item['DESC'] + '">' + item['DESC'] + ' </span></label></p>';
						  }
					  }
				  });
			  } else if (descriptiones.length !== "undefined" ){
				  if(drive_mode == 'automatic'){
					  if (!descriptiones['DESC'].includes('STD')) {
						  as += '<p class="mb-1"><label><input id="' + descriptiones['CVEVEH'] + '" name="group2" type="radio"><span id="' + descriptiones['DESC'] + '">' + descriptiones['DESC'] + ' </span></label></p>';
					  }
				  } else {
					  if (descriptiones['DESC'].includes('STD')) {
						  as += '<p class="mb-1"><label><input id="' + descriptiones['CVEVEH'] + '" name="group2" type="radio"><span id="' + descriptiones['DESC'] + '">' + descriptiones['DESC'] + ' </span></label></p>';
					  }
				  }
			  }
		  }
		  $('div#aba').html(as);
		  var qu = '<img src="' + QUAL +'" style="width:200px; height:50px;"><br>';
		  if (typeof qualitas !== "undefined"){
			  if (qualitas.length > 1){
				  qualitas.forEach(function(item) {
					  if(drive_mode == 'automatic'){
						  if (!item['cVersion'].includes('STD')) {
							  qu += '<p class="mb-1"><label><input id="' + item['CAMIS'] + '" name="group3" type="radio"><span id="' + item['cVersion'] + '">' + item['cVersion'] + ' </span></label></p>';
						  }
					  } else{
						  if (item['cVersion'].includes('STD')) {
							  qu += '<p class="mb-1"><label><input id="' + item['CAMIS'] + '" name="group3" type="radio"><span id="' + item['cVersion'] + '">' + item['cVersion'] + ' </span></label></p>';
						  }
					  }
				  });
			  } else if (qualitas.length !== "undefined"){
				  var qu = '<img src="' + QUAL +'" style="width:200px; height:50px;"><br>';
				  if(drive_mode == 'automatic'){
					  if (!qualitas['cVersion'].includes('STD')) {
						  qu += '<p class="mb-1"><label><input id="' + qualitas['CAMIS'] + '" name="group3" type="radio"><span id="' + qualitas['cVersion'] + '">' + qualitas['cVersion'] + ' </span></label></p>';
					  }
				  } else {
					  if (qualitas['cVersion'].includes('STD')) {
						  qu += '<p class="mb-1"><label><input id="' + qualitas['CAMIS'] + '" name="group3" type="radio"><span id="' + qualitas['cVersion'] + '">' + qualitas['cVersion'] + ' </span></label></p>';
					  }
				  }
			  }
		  }
	  }
	  $('div#qualitas').html(qu);
	});
	$('div#aba').on("click", "p", function(event){
		description = $(this).children('label').children('span').attr('id');
		cveveh = $(this).children('label').children('input').attr('id');
		$("button#next2").attr('disabled', false);
	});
	 
	$('div#qualitas').on("click", "p", function(event){
		qualitas_des = $(this).children('label').children('span').attr('id');
		camis = $(this).children('label').children('input').attr('id');
		$("button#next2").attr('disabled', false);
	});
	 
	$('p#checkbox').click(function (e){
		flag = flag + 1;
		makeRFC();
	});
	function makeRFC(){
		var res_name = /^[a-zA-Z]+$/;
		var res_mail = /^[A-Z0-9._%+-]+@([A-Z0-9-]+\.)+[A-Z]{2,4}$/i;
		var res_cp = /^\d{5}(?:[\s-]\d{4})?$/;
		if(res_name.test($('input#firstName').val())) { 
			first_name = $('input#firstName').val();
		} else{ first_name = null; $('input#firstName').val(first_name);}
		if(res_name.test($('input#lastName').val())) { 
			surname = $('input#lastName').val();
		} else{ surname = null; $('input#lastName').val(surname);}
		if(res_name.test($('input#paternalName').val())) { 
			paternal = $('input#paternalName').val();
		} else{ paternal = null; $('input#paternalName').val(paternal);}
		if(res_name.test($('input#maternalName').val())) { 
			maternal = $('input#maternalName').val();
		} else{ maternal = null; $('input#maternalName').val(maternal);}
		if(res_mail.test($('input#mail').val())) { 
			email = $('input#mail').val();
		} else{ email = null; $('input#mail').val(email);}
		if(res_cp.test($('input#cp').val())) { 
			post_code = $('input#cp').val();
		} else{ post_code = null; $('input#cp').val(post_code);}
		
		var date = $("input#datepicker").val();
		var day_array = date.split('-');
		var checked = flag % 4;
		if(first_name != null && surname != null && paternal != null && maternal != null && email != null && post_code != null && day_array[2] != undefined && checked == '2'){
			RFC = paternal.substring(0, 2).toUpperCase() + maternal.substring(0, 1).toUpperCase() + first_name.substring(0, 1).toUpperCase() + day_array[0].substring(2,4) + day_array[1] + day_array[2];
			$("button#next3").attr('disabled', false);
		} else{
			$("button#next3").attr('disabled', true);
		}
	}
	 
	$('input#firstName').change(function(e){ makeRFC();});
	$('input#lastName').change(function(e){ makeRFC();});
	$('input#paternalName').change(function(e){ makeRFC();});
	$('input#maternalName').change(function(e){ makeRFC();});
	$('input#mail').change(function(e){ makeRFC();});
	$('input#cp').change(function(e){ makeRFC();});
	$("input#datepicker").change(function(e) { makeRFC();});
	 
	function getQuot(){
		des = $('input#DES').val();
		preloader();
		$.ajaxSetup({ headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') }});
		$.ajax({ url:currenturl+"/quot", data:{ brand: brand_name, mod: mod, Cveveh: cveveh, postal_code: post_code, description: description, condition: car_status, fp: payment_method, paq: plan_type, camis: camis, qual: qualitas_des, DES: des}, type:'post',
				success: function(result){
					console.log(result);
					if(typeof result['aba'] !== "undefined"){
						console.log(result['aba']);
						cot_id = result['aba']['COTID'];
						ver_id = result['aba']['VERID'];
						cotinc_id = result['aba']['INCISOS']['INCISO']['COTINCID'];
						verinc_id = result['aba']['INCISOS']['INCISO']['VERINCID'];
						pneta = result['aba']['PNETA'];
						iva = result['aba']['IVA'];
						ptotal = result['PTOTAL'];
						DER = result['aba']['INCISOS']['INCISO']['DER'];
						REC = result['aba']['INCISOS']['INCISO']['REC'];
						DES = result['aba']['INCISOS']['INCISO']['DES'];
						BON = result['aba']['INCISOS']['INCISO']['BON'];
						var hire = $("p#hire").html();
						var val;
						if( (result['aba']['INCISOS']['INCISO']['RECIBOS']['RECIBO']).length > 1){
							val = result['aba']['INCISOS']['INCISO']['RECIBOS']['RECIBO']['0']['PTOTAL'];
						} else{
							val = result['aba']['INCISOS']['INCISO']['RECIBOS']['RECIBO']['PTOTAL'];
						}
						var ptotal_part = parseInt(val);
						var quot_item = result['aba']['INCISOS']['INCISO']['COBS']['COB'];
						var quot_html = '<tr><td></td><td><a id="hire" class="btn waves-effect waves-light cyan modal-trigger" href="#modal6" style="font-size: x-small;">'+ hire +'</a></td></tr>';
						quot_item.forEach(function(item) {
							if(item['SEL'] == "1"){
								if(item['SADESC'] == "AMPARADA"){
									item['SADESC'] = '<i class="material-icons dp48">check</i>';
								} else if(item['SADESC'] == "VALOR COMERCIAL"){
									item['SADESC'] = item['DEDESC'];
								}
								if( item['SADESC'].indexOf(",000.00") > 0){
									var aba_desc = item['SADESC'].replace(",000.00", "K");
								} else if( item['SADESC'].indexOf(".00") > 0){
									var aba_desc = item['SADESC'].replace(".00", "");
								} else{
									var aba_desc = item['SADESC'];
								}
								quot_html += '<tr><td>' + item['DESC'] + '</td><td>' + aba_desc + '</td></tr>';
							}
						});
						$("p#total").html("$" + ptotal_part + "|MXN");
						$("tbody#quotes").html(quot_html);
					}
					
					if(typeof result['qual'] !== "undefined"){
						console.log(result['qual']);
						qual_cotid = result['qual']['Movimiento']['@attributes']['NoCotizacion'];
						var qual_item = result['qual']['Movimiento']['DatosVehiculo']['Coberturas'];
						var qual_html = '<tr><td></td><td><a id="hire" class="btn waves-effect waves-light cyan modal-trigger" href="#modal6" style="font-size: x-small;">'+ hire +'</a></td></tr>';
						qual_item.forEach(function(item) {
							var key = item['@attributes']['NoCobertura'];
							var Item = result['Item'][key];
							if(key == 34){
							   return false;
							}
							if(parseInt(item['Deducible']) != 0){
								var value = parseInt(item['Deducible']);
								qual_html += '<tr><td>' + Item + '</td><td>' + value + '%</td></tr>';
							} else{
								var value = parseInt(item['SumaAsegurada']);
								qual_html += '<tr><td>' + Item + '</td><td>$' + value + '</td></tr>';
							}
						});
						if(Object.keys(result['qual']['Movimiento']['Recibos']).length != 9)
							qual_ptotal = result['qual']['Movimiento']['Recibos'][0]['PrimaTotal'];
						else
							qual_ptotal = result['qual']['Movimiento']['Recibos']['PrimaTotal'];
						$("p#qual_ptotal").html("$" + qual_ptotal + "|MXN");
						$("tbody#qual").html(qual_html);
					}
					loader();
				},
				error: function(e, status){
					loader();
					if (e.status == 500)
						alert("Can't find data. Please try again!");
				}
			   });
	}
	$("a#aba_view").click(function (e){
		aba_flag = !aba_flag;
		if(aba_flag == false){
			$("tbody#quotes").css("display","");
			$("a#aba_view").children('i').html('visibility_off');
		} else{
			$("tbody#quotes").css("display","none");
			$("a#aba_view").children('i').html('visibility');
		}
	});
	$("a#qual_view").click(function (e){
		qual_flag = !qual_flag;
		if(qual_flag == false){
			$("tbody#qual").css("display","");
			$("a#qual_view").children('i').html('visibility_off');
		} else{
			$("tbody#qual").css("display","none");
			$("a#qual_view").children('i').html('visibility');
		}
	});
	$("button#next3").click(function (e){
		$("input#send_email").val(email);
		var dec = '<h4 class="card-title">' + brand_name + '&nbsp;&nbsp;' + mod +'&nbsp;&nbsp;' + description + '</h4>';
		  $('div#detail_dec').html(dec);
		getQuot();
	});
	$('select#payment').on('change', function (e) {
		payment_method = $(this).val();
		getQuot();
	});
	$('select#plane').on('change', function (e) {
		plan_type = $(this).val();
		getQuot();
	});
	$('button#submit_quot').click(function(e){
		//select_cotid = cot_id;
		$('button#send_email').click();
	});
	$('button#submit_qual').click(function(e){
		//select_cotid = qual_cotid;
		$('button#send_email').click();
	});
	$('button#send_email').click(function(e){
		var send_email = $('input#send_email').val();
		var res = /^[A-Z0-9._%+-]+@([A-Z0-9-]+\.)+[A-Z]{2,4}$/i;
		if(!res.test(send_email)) { 
			send_email = null;
			$('input#send_email').val(send_email);
		} 
		console.log(send_email);
		if(send_email != null){
			var data = { 
				email: send_email, 
				cot_id: cot_id,
				qual_id: qual_cotid,
				description: brand_name + ' ' + mod + ' ' + model_select + ' ' + drive_mode, 
			};
			$('#modal7').modal('close');
			preloader();
			$.ajaxSetup({ headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') }});
			$.ajax({ url:currenturl+"/sendEmail", data:data, type:'post',
					success: function(result){
						console.log(result);
						var this_year = new Date().getFullYear();
						loader();
						window.location.replace("/quot-list/" + this_year);
					},
					error: function(e, status){
						loader();
						if (e.status == 500)
							alert("Email address is not correctly!");
					}
			});
		}
	});
})(window.jQuery);