(function($) {

	var currenturl = window.location.href,
		url_array = currenturl.split('/'),
		url = url_array[0] + '//' + url_array[2];
	var url, quot_id, serie, plates, reference, motor;
	var firstname, lastname, paternal, maternal, birthdate, rfc, ext_num;
	
	$('#datepicker').datepicker({"format":'yyyy-mm-dd', yearRange: 71} );
	function step1(){
		if(serie != null && plates != null && reference != null && motor != null){
			$('button#next1').attr('disabled', false);
		}
	}
	
	$('input#serie').change(function(e){
		var res = /^[a-zA-Z0-9_.-]*$/; // only letters and numbers
		var res_val = $(this).val();
		if(!res.test(res_val)) { 
			serie = null;
			$(this).val(serie);
		} else{
			serie = res_val;
			step1();
		}
	});

	$('input#plates').change(function(e){
		var res = /^[a-zA-Z0-9_.-]*$/;
		var res_val = $(this).val();
		if(!res.test(res_val)) { 
			plates = null;
			$(this).val(plates);
		} else{
			plates = res_val;
			step1();
		}
	});

	$('input#ref').change(function(e){
		var res = /^[a-zA-Z0-9_.-]*$/;
		var res_val = $(this).val();
		if(!res.test(res_val)) { 
			reference = null;
			$(this).val(reference);
		} else{
			reference = res_val;
			step1();
		}
	});

	$('input#motor').change(function(e){
		var res = /^[a-zA-Z0-9_.-]*$/;
		var res_val = $(this).val();
		if(!res.test(res_val)) { 
			motor = null;
			$(this).val(motor);
		} else{
			motor = res_val;
			step1();
		}
	});
	
	$('button#next2').click(function(e){
		firstname = $('input#firstname').val();
		paternal = $('input#paternal').val();
		maternal = $('input#maternal').val();
		birthdate = $("input#datepicker").val();
		var day_array = birthdate.split('-');
		if(firstname != null && paternal != null && maternal != null && day_array[2] != undefined){
			rfc = paternal.substring(0, 2).toUpperCase() + maternal.substring(0, 1).toUpperCase() + firstname.substring(0, 1).toUpperCase() + day_array[0].substring(2,4) + day_array[1] + day_array[2];
			$("input#rfc").val(rfc);
		}
	});
	
	function step2(){
		if(ext_num != null && rfc != null){
			$('button#issuing').attr('disabled', false);
		}
	}

	// Select ext_num
	$('input#ext_num').change(function(e){
		var res = /^[0-9-+]+$/;
		var test_val = $(this).val();
		if(!res.test(test_val)) { 
			ext_num = null;
			$(this).val(ext_num);
		} else{
			ext_num = test_val;
			step2();
		}
	});
	
})(window.jQuery);