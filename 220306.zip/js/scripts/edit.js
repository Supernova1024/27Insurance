$('#yes').click(function(e){
	$('button#submit').click();
});