(function($) {
	var currenturl = window.location.href,
		url_array = currenturl.split('/'),
		url = url_array[0] + '//' + url_array[2],
		year = new Date(),
		this_year = year.getFullYear();
	 
	$("div#quote").click(function (e){
		window.location = url +"/quot-list/"+ this_year;
	});
	$("div#policy").click(function (e){
		window.location = url +"/policy-list/"+ this_year;
	});
	$("div#report").click(function (e){
		window.location = url +"/report/"+ this_year;
	});
	
	$("div#client").click(function (e){
		window.location = url +"/client-list";
	});
})(window.jQuery);