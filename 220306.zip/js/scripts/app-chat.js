$(document).ready(function () {
   "use strict";

	var to_user = '',
		currenturl = window.location.href,
		url_array = currenturl.split('/'),
		url = url_array[0] + '//' + url_array[2],
		attach = $('input#attach');
   $(".chat-area").scrollTop($(".chat-area > .chats").height());
   // Sidenav
   if ($(window).width() > 900) {
      $("#chat-sidenav").removeClass("sidenav");
   }

   // Pefectscrollbar for sidebar and chat area
   if ($(".sidebar-chat").length > 0) {
      var ps_sidebar_chat = new PerfectScrollbar(".sidebar-chat", {
         theme: "dark"
      });
   }

   if ($(".chat-area").length > 0) {
      var ps_chat_area = new PerfectScrollbar(".chat-area", {
         theme: "dark"
      });
   }

   // attachment
   $('i#attach').click(function(e){
		attach.click();
	});
	
   attach[0].addEventListener('change', function() {
	   var label = $('input.message');
	  if(attach[0].files.length > 0){
		label.val(attach[0].files[0].name);
		label.prop('disabled', true);
	  }
	});
   // Close other sidenav on click of any sidenav
   $(".sidenav-trigger").on("click", function () {
      if ($(window).width() < 960) {
         $(".sidenav").sidenav("close");
         $(".app-sidebar").sidenav("close");
      }
   });

   // Toggle class of sidenav
   $("#chat-sidenav").sidenav({
      onOpenStart: function () {
         $("#sidebar-list").addClass("sidebar-show");
      },
      onCloseEnd: function () {
         $("#sidebar-list").removeClass("sidebar-show");
      }
   });

   // Favorite star click
   $(".favorite i").on("click", function () {
      $(this).toggleClass("amber-text");
   });

   // For chat sidebar on small screen
   if ($(window).width() < 900) {
      $(".app-chat .sidebar-left.sidebar-fixed").removeClass("animate fadeUp animation-fast");
      $(".app-chat .sidebar-left.sidebar-fixed .sidebar").removeClass("animate fadeUp");
   }

   // chat search filter
   $(".app-filter").keyup(function(event) {
	   if (event.which === 13) {
		   $('.chat-user').css('animation', 'none')
		   var value = $(this).val().toLowerCase();
		   $.ajaxSetup({ headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') }});
		   $.ajax({ url:url+"/filter", data:{ name: value}, type:'post',
				   success: function(result){
					   var as = '';
					   if(result.length != 0){
						   result.forEach(function(item) {
							   var image_url = url +'/images/user/'+ item[0]['image'];
							   if(item[1] == 'Null')
							   	   var last_message = "";
							   else
								   var last_message = item[1];
							   as += '<div class="chat-user animate fadeUp delay" id="'+ item[0]['email'] +'"><div class="user-section"><div class="row valign-wrapper"><div class="col s2 media-image online pr-0"><img src="'+ image_url +'" alt="" class="circle z-depth-2 responsive-img"></div><div class="col s10"><p class="m-0 blue-grey-text text-darken-4 font-weight-700">'+ item[0]['firstname'] +' '+ item[0]['lastname']+'</p><p class="m-0 info-text">'+ last_message +'</p></div></div></div><div class="info-section">';
							   if(item[2] != 0){
								   as +='<div class="star-timing"><div class="time"><span class="badge badge pill red">'+ item[2] +'</span></div></div></div></div>';
							   } else{
								   as += '<div class="star-timing"><div class="time"></div></div></div></div>';
							   }
						   });
					   }
					   $("div#chat-list").html(as);	
				   },
				   error: function(result){
					   console.log("failed");
				   }
				  });
        }
      
   });
	
   // select user 
   $("div.chat-list").on("click", "div.delay", function(event){
       to_user = $(this).attr('id');
	   var count = $("div.time span#count").html();
	   $(this).children("div.info-section").children("div.star-timing").html('');
	   $(this).parent().children("div.delay").removeClass("active");
	   $(this).addClass("active");
	   $.ajaxSetup({ headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') }});
	   $.ajax({ url:url+"/chat-content", data:{ email: to_user}, type:'post',
				success: function(result){
					var image = url +'/images/user/'+ result['to_user']['image'];
					var as = '<div class="col media-image online pr-0"><img src="'+ image +'" alt="" class="circle z-depth-2 responsive-img"><p id="img" style="display:none;">'+ image +'</p></div><div class="col"><p class="m-0 blue-grey-text text-darken-4 font-weight-700">'+ result['to_user']['firstname'] +' '+ result['to_user']['lastname'] +'</p><p class="m-0 chat-text truncate">'+ result['to_user']['role'] +'</p><p id="to_user" style="display:none;">'+ result['to_user']['id'] +'</p><p id="to_email" style="display:none;">'+ result['to_user']['email'] +'</p></div>';
					$("div#chat_header").html(as);
					var content = '';
					var userID = $("p.user_id").attr('id');
					var user_img = url +'/images/user/'+ $("p.user_img").attr('id');
					result['chat'].forEach(function(item) {
						if(item['recipient_id'] == userID){
							content += '<div class="chat"><div class="chat-avatar"><a class="avatar"><img src="'+ image +'" class="circle" alt="avatar" /></a></div><div class="chat-body"><div class="chat-text">';
							
						} else{
							content += '<div class="chat chat-right"><div class="chat-avatar"><a class="avatar"><img src="'+ user_img +'" class="circle" alt="avatar" /></a></div><div class="chat-body"><div class="chat-text">';
						}
						if(item['type'] == 'Str'){
							content += '<p>'+ item['message'] +'</p></div></div></div>';
						} else{
							content += '<div class="img-box grey lighten-4 border-radius-6"><div class="card-image"><img src="https://dreamy-montalcini.74-208-200-19.plesk.page/local/storage/attached/'+ item['message'] +'" class="responsive-img" data-xblocker="passed"></div><div class="card-content"><span class="left">'+ item['message'] +'</span><a href="'+ url +'/download/'+ item['message'] +'" class="Right"><i class="material-icons">file_download</i></a></div></div></div></div></div>';
						}
					});
					$("div#chat_content").html(content);
					$(".chat-area").scrollTop($(".chat-area > .chats").height());
				},
				error: function(result){
					console.log("failed");
				}
	    });
   });
	
   $(".message").keyup(function(event) {
        if (event.which === 13) {
            $("a#submit").click();
        }
    });
	
   $("a#submit").click(function(e){
	   var message = $(".message").val();
	   to_user = $("p#to_email").html();
	   var file_data = $('input#attach').prop('files')[0];
	   var form_data = new FormData();
	   form_data.append('file', file_data);
	   form_data.append('message', message);
	   form_data.append('to', to_user);
	   var newMessageAudio = new Audio(url +'/uploads/audio/message-sent.mp3');
	   if (message != "" && to_user !="") {
		   $.ajaxSetup({ headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') }});
		   $.ajax({ url:url+"/send_message", 
				   type:'POST', 
				   data:form_data,
    			   cache: false,
   				   processData: false,
  				   contentType: false,
				   success: function(result){
					   var user_img = url +'/images/user/'+ $("p.user_img").attr('id');
					   var html = '<div class="chat chat-right"><div class="chat-avatar"><a class="avatar"><img src="'+ user_img +'" class="circle" alt="avatar" /></a></div><div class="chat-body"><div class="chat-text">';
					   if(attach[0].files.length > 0){
						   html += '<div class="img-box grey lighten-4 border-radius-6"><div class="card-image"><img src="https://dreamy-montalcini.74-208-200-19.plesk.page/local/storage/attached/'+ message +'" class="responsive-img" data-xblocker="passed"></div><div class="card-content"><span class="left">'+ message +'</span><a href="'+ url +'/download/'+ message +'" class="Right"><i class="material-icons">file_download</i></a></div></div></div></div></div>';
					   } else{
						   html += '<p>'+ message +'</p></div></div></div>';
					   }
					   $("div#chat_content").append(html);
					   $(".message").val("");
					   $(".message").removeAttr('disabled');
					   $(".chat-area").scrollTop($(".chat-area > .chats").height());
				   },
				   error: function(result){
					   alert("Selection Failed. Please try again!");
				   }
		   });
		   newMessageAudio.play();
	   }
   });

   // for rtl
   if ($("html[data-textdirection='rtl']").length > 0) {
      // Toggle class of sidenav
      $("#chat-sidenav").sidenav({
         edge: "right",
         onOpenStart: function () {
            $("#sidebar-list").addClass("sidebar-show");
         },
         onCloseEnd: function () {
            $("#sidebar-list").removeClass("sidebar-show");
         }
      });
   }
});

$(window).on("resize", function () {
   if ($(window).width() > 899) {
      $("#chat-sidenav").removeClass("sidenav");
   }

   if ($(window).width() < 900) {
      $("#chat-sidenav").addClass("sidenav");
   }
});
