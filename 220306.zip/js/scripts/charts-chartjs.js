// /*
// * ChartJS - Chart
// */

// Line chart
// ------------------------------
$(window).on("load", function() {
	
	var currenturl = window.location.href;
	var this_year, last_year, count;
	var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
	var data = [];
	function getLine(){
		this_year = $('span.hide-on-small-onl').html();
		last_year = parseInt(this_year) - 1;
		var url_array = currenturl.split('/');
		var url = url_array[0] + '//' + url_array[2];
		
		$.ajaxSetup({ headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') }});
		$.ajax({ url:url + "/report/chart", data:{ year: this_year }, type:'post',
				success: function(result){
					console.log(result);
					count = parseInt(result['count']);
					var this_months = months.splice(0, count);
					//Get the context of the Chart canvas element we want to select
					var ctx = $("#quot-chart");

					// Chart Options
					var chartOptions = {
						responsive: true,
						maintainAspectRatio: false,
						legend: {
							position: "bottom"
						},
						hover: {
							mode: "label"
						},
						scales: {
							xAxes: [
								{
									display: true,
									gridLines: {
										color: "#f3f3f3",
										drawTicks: false
									},
									scaleLabel: {
										display: true,
										labelString: "Month"
									}
								}
							],
							yAxes: [
								{
									display: true,
									gridLines: {
										color: "#f3f3f3",
										drawTicks: false
									},
									scaleLabel: {
										display: true,
										labelString: "Quotation Count"
									}
								}
							]
						},
						title: {
							display: false,
							text: "Quotation"
						}
					};
					
					if(result['last_flag'] > 0){
						// Chart Data
						var chartData = {
							labels: this_months,
							datasets: [
								{
									label: this_year,
									data: result['quot_val'],
									fill: true,
									borderColor: "#e91e63",
									pointBorderColor: "#e91e63",
									pointBackgroundColor: "#FFF",
									pointBorderWidth: 2,
									pointHoverBorderWidth: 2,
									pointRadius: 4
								},
								{
									label: last_year,
									data: result['quot_last'],
									fill: false,
									borderColor: "#03a9f4",
									pointBorderColor: "#03a9f4",
									pointBackgroundColor: "#FFF",
									pointBorderWidth: 2,
									pointHoverBorderWidth: 2,
									pointRadius: 4
								}
							]
						};
					} else{
						// Chart Data
						var chartData = {
							labels: this_months,
							datasets: [
								{
									label: this_year,
									data: result['quot_val'],
									fill: true,
									borderColor: "#e91e63",
									pointBorderColor: "#e91e63",
									pointBackgroundColor: "#FFF",
									pointBorderWidth: 2,
									pointHoverBorderWidth: 2,
									pointRadius: 4
								}
							]
						};
					}

					var config = {
						type: "line",

						// Chart Options
						options: chartOptions,

						data: chartData
					};

					// Create the chart
					var quotChart = new Chart(ctx, config);
					
					//Get the context of the Chart canvas element we want to select
					var ctx = $("#line-chart");

					// Chart Options
					var chartOptions = {
						responsive: true,
						maintainAspectRatio: false,
						legend: {
							position: "bottom"
						},
						hover: {
							mode: "label"
						},
						scales: {
							xAxes: [
								{
									display: true,
									gridLines: {
										color: "#f3f3f3",
										drawTicks: false
									},
									scaleLabel: {
										display: true,
										labelString: "Month"
									}
								}
							],
							yAxes: [
								{
									display: true,
									gridLines: {
										color: "#f3f3f3",
										drawTicks: false
									},
									scaleLabel: {
										display: true,
										labelString: "Issued Policy Count"
									}
								}
							]
						},
						title: {
							display: false,
							text: "Issued Policy 2021"
						}
					};
					
					if(result['last_flag'] > 0){
						// Chart Data
						var chartData = {
							labels: this_months,
							datasets: [
								{
									label: this_year,
									data: result['val'],
									fill: true,
									borderColor: "#e91e63",
									pointBorderColor: "#e91e63",
									pointBackgroundColor: "#FFF",
									pointBorderWidth: 2,
									pointHoverBorderWidth: 2,
									pointRadius: 4
								},
								{
									label: last_year,
									data: result['last'],
									fill: false,
									borderColor: "#03a9f4",
									pointBorderColor: "#03a9f4",
									pointBackgroundColor: "#FFF",
									pointBorderWidth: 2,
									pointHoverBorderWidth: 2,
									pointRadius: 4
								}
							]
						};
					} else{
						// Chart Data
						var chartData = {
							labels: this_months,
							datasets: [
								{
									label: this_year,
									data: result['val'],
									fill: true,
									borderColor: "#e91e63",
									pointBorderColor: "#e91e63",
									pointBackgroundColor: "#FFF",
									pointBorderWidth: 2,
									pointHoverBorderWidth: 2,
									pointRadius: 4
								}
							]
						};
					}

					var config = {
						type: "line",

						// Chart Options
						options: chartOptions,

						data: chartData
					};

					// Create the chart
					var lineChart = new Chart(ctx, config);
					
					//Get the context of the Chart canvas element we want to select
					var ctx = $("#ptotal-chart");

					// Chart Options
					var chartOptions = {
						responsive: true,
						maintainAspectRatio: false,
						legend: {
							position: "bottom"
						},
						hover: {
							mode: "label"
						},
						scales: {
							xAxes: [
								{
									display: true,
									gridLines: {
										color: "#f3f3f3",
										drawTicks: false
									},
									scaleLabel: {
										display: true,
										labelString: "Month"
									}
								}
							],
							yAxes: [
								{
									display: true,
									gridLines: {
										color: "#f3f3f3",
										drawTicks: false
									},
									scaleLabel: {
										display: true,
										labelString: "Value"
									}
								}
							]
						},
						title: {
							display: false,
							text: "Issued Policy 2021"
						}
					};

					if(result['last_flag'] > 0){
						// Chart Data
						var chartData = {
							labels: this_months,
							datasets: [
								{
									label: this_year,
									data: result['this_ptotal'],
									fill: true,
									borderColor: "#e91e63",
									pointBorderColor: "#e91e63",
									pointBackgroundColor: "#FFF",
									pointBorderWidth: 2,
									pointHoverBorderWidth: 2,
									pointRadius: 4
								},
								{
									label: last_year,
									data: result['last_ptotal'],
									fill: false,
									borderColor: "#03a9f4",
									pointBorderColor: "#03a9f4",
									pointBackgroundColor: "#FFF",
									pointBorderWidth: 2,
									pointHoverBorderWidth: 2,
									pointRadius: 4
								}
							]
						};
					} else{
						// Chart Data
						var chartData = {
							labels: this_months,
							datasets: [
								{
									label: this_year,
									data: result['this_ptotal'],
									fill: true,
									borderColor: "#e91e63",
									pointBorderColor: "#e91e63",
									pointBackgroundColor: "#FFF",
									pointBorderWidth: 2,
									pointHoverBorderWidth: 2,
									pointRadius: 4
								}
							]
						};
					}

					var config = {
						type: "line",

						// Chart Options
						options: chartOptions,

						data: chartData
					};

					// Create the chart
					var ptotalChart = new Chart(ctx, config);

					// Bar chart
					// ------------

					//Get the context of the Chart canvas element we want to select
					var ctx = $("#bar-chart");

					// Chart Options
					var chartOptions = {
						// Elements options apply to all of the options unless overridden in a dataset
						// In this case, we are setting the border of each horizontal bar to be 2px wide and green
						elements: {
							rectangle: {
								borderWidth: 2,
								borderColor: "rgb(0, 255, 0)",
								borderSkipped: "left"
							}
						},
						responsive: true,
						maintainAspectRatio: false,
						responsiveAnimationDuration: 500,
						legend: {
							position: "top"
						},
						scales: {
							xAxes: [
								{
									display: true,
									gridLines: {
										color: "#f3f3f3",
										drawTicks: false
									},
									scaleLabel: {
										display: true
									}
								}
							],
							yAxes: [
								{
									display: true,
									gridLines: {
										color: "#f3f3f3",
										drawTicks: false
									},
									scaleLabel: {
										display: true
									}
								}
							]
						},
						title: {
							display: false,
							text: "Chart.js Horizontal Bar Chart"
						}
					};

					// Chart Data
					var chartData = {
						labels: ["ABA", "QUA", "AXA", "ANA", "BAN", "HDI", "MAP"],
						datasets: [
							{
								label: this_year,
								data: result['this_company'],
								backgroundColor: "#00bcd4",
								hoverBackgroundColor: "#00acc1",
								borderColor: "transparent"
							},
							{
								label: last_year,
								data: result['last_company'],
								backgroundColor: "#ffeb3b",
								hoverBackgroundColor: "#fdd835",
								borderColor: "transparent"
							}
						]
					};

					var config = {
						type: "horizontalBar",

						// Chart Options
						options: chartOptions,

						data: chartData
					};

					// Create the chart
					var barChart = new Chart(ctx, config);
					
				},
				error: function(result){
					alert("Failed. Please try again!");
				}
			   });
	}
	getLine();
 });
 