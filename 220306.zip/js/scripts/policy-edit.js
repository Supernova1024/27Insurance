$(document).ready(function () {

  var status;
  $('#start').datepicker({"format":'yyyy-mm-dd'});
  $('#end_date').datepicker({"format":'yyyy-mm-dd'});
  $('#cancel_date').datepicker({"format":'yyyy-mm-dd'});
  $('#status').on('change', function (e) {
	  var optionSelected = $("option:selected", this);
	  status = this.value;
	  console.log(status);
	  if(status == '1'){
		  $('#cancel_date').attr('disabled', true);
		  $('#end_date').attr('disabled', false);
	  } else{
		  $('#cancel_date').attr('disabled', false);
		  $('#end_date').attr('disabled', true);
	  }
  });
});
