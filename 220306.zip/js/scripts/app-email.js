$(document).ready(function () {
   "use strict";
	var currenturl = window.location.href,
	    url_array = currenturl.split('/'),
	    url = url_array[0] + '//' + url_array[2];
   // Close other sidenav on click of any sidenav
   if ($(window).width() > 900) {
      $("#email-sidenav").removeClass("sidenav");
   }
   // email Quill Editor
   // -------------------
   var composeMailEditor = new Quill(".snow-container .compose-editor", {
      modules: {
         toolbar: ".compose-quill-toolbar"
      },
      placeholder: "Write a Message... ",
      theme: "snow"
   });

   // Toggle class of sidenav
   $("#email-sidenav").sidenav({
      onOpenStart: function () {
         $("#sidebar-list").addClass("sidebar-show");
      },
      onCloseEnd: function () {
         $("#sidebar-list").removeClass("sidebar-show");
      }
   });

   //  Notifications & messages scrollable
   if ($("#sidebar-list").length > 0) {
      var ps_sidebar_list = new PerfectScrollbar("#sidebar-list", {
         theme: "dark",
         wheelPropagation: false
      });
   }
   if ($(".app-email .collection").length > 0) {
      var ps_email_collection = new PerfectScrollbar(".app-email .collection", {
         theme: "dark",
         wheelPropagation: false
      });
   }
   // active class chnage on click
   $(".email-list li").click(function () {
      var $this = $(this);
      if (!$this.hasClass("sidebar-title")) {
         $("li").removeClass("active");
         $this.addClass("active");
         var folder = $this.children('a').children('i').html();
         switch (folder) {
            case ' mail_outline ' :
               folder = 'inbox';
               break;
            case ' send ' :
               folder = 'sent';
               break;
            case ' description ' :
               folder = 'draft';
               break;
            case ' info_outline ' :
               folder = 'spam';
               break;
            case ' delete ' :
               folder = 'trash';
               break;
            case ' star_border ' :
               folder = 'starred';
               break;
            case ' label_outline ' :
               folder = 'important';
               break;
            case ' fiber_manual_record ' :
               var id = $this.attr('id');
               if (id == 'note') {
                  folder = 'note';
               }
               if (id == 'paypal') {
                  folder = 'paypal';
               }
               if (id == 'invoice') {
                  folder = 'invoice';
               }
               break;
         }

      }
      
      $('div.loading').show();
      get_all_mesages(folder);
      $('div.loading').hide();
   });

   // // active class chnage on click
   // $(".list-content").click(function () {
   //    var $this = $(this);
   //    var mesag_id = $(this).attr('id');
   //    $('div.loading').show();
   //    get_mesag_details(mesag_id);
   //    $('div.loading').hide();
   // });

   // Remove Row
   $('.app-email i[type="button"]').click(function (e) {
      $(this)
         .closest("tr")
         .remove();
   });

   // Favorite star click
   $(".app-email .favorite i").on("click", function (e) {
      e.preventDefault();
      $(this).toggleClass("amber-text");
   });

   // Important label click
   $(".app-email .email-label i").on("click", function (e) {
      e.preventDefault();
      $(this).toggleClass("amber-text");
      if ($(this).text() == "label_outline") $(this).text("label");
      else $(this).text("label_outline");
   });

   // To delete all mails
   $(".app-email .delete-mails").on("click", function () {
      var selected_id = [];
      $(".collection-item").find("input:checked").each(function() {
         selected_id.push($(this).closest(".collection-item").attr('id'));
      })
      del_mesag(selected_id);
         
   });

   // To delete Single mail
   $(".app-email .delete-task").on("click", function () {
      $(this)
         .closest(".collection-item")
         .remove();
   });

   // Sidenav
   $(".sidenav-trigger").on("click", function () {
      if ($(window).width() < 960) {
         $(".sidenav").sidenav("close");
         $(".app-sidebar").sidenav("close");
      }
   });
   // chat search filter
   $("#email_filter").on("keyup", function () {
      $('.email-brief-info').css('animation', 'none')
      var value = $(this).val().toLowerCase();
      if (value != "") {
         $(".email-collection .email-brief-info").filter(function () {
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1);
         });
         var tbl_row = $(".email-brief-info:visible").length; //here tbl_test is table name

         //Check if table has row or not
         if (tbl_row == 0) {
            if (!$(".no-data-found").hasClass('show')) {
               $(".no-data-found").addClass('show');
            }
         }
         else {
            $(".no-data-found").removeClass('show');
         }
      }
      else {
         // if search filter box is empty
         $(".email-collection .email-brief-info").show();
      }
   });

   // email-overlay and sidebar hide
   // --------------------------------------------
   $(".compose-email-trigger").on("click", function () {
      $(".email-overlay").addClass("show");
      $(".email-compose-sidebar").addClass("show");

   })
   $(
      ".email-compose-sidebar .cancel-email-item, .email-compose-sidebar .close-icon, .email-compose-sidebar .send-email-item, .email-overlay"
   ).on("click", function () {
      $(".email-overlay").removeClass("show");
      $(".email-compose-sidebar").removeClass("show");
      //$("input").val("");
      $(".compose-editor .ql-editor p").html("");
      //$("#edit-item-from").val("user@example.com");
   });

   if ($(".email-compose-sidebar").length > 0) {
      var ps_sidebar_compose = new PerfectScrollbar(".email-compose-sidebar", {
         theme: "dark",
         wheelPropagation: false
      });
   }

   // for rtl
   if ($("html[data-textdirection='rtl']").length > 0) {
      // Toggle class of sidenav
      $("#email-sidenav").sidenav({
         edge: "right",
         onOpenStart: function () {
            $("#sidebar-list").addClass("sidebar-show");
         },
         onCloseEnd: function () {
            $("#sidebar-list").removeClass("sidebar-show");
         }
      });
   }
   
   $("button.send-email-item").click(function(e){
	   var from = $("input#edit-item-from").val();
	   var to = $("input#edit-item-to").val();
	   var res = /^[A-Z0-9._%+-]+@([A-Z0-9-]+\.)+[A-Z]{2,4}$/i;
		if(!res.test(to)) { 
			to = '';
			$("input#edit-item-to").val(to);
		} 
	   var Sub = $("input#edit-item-subject").val();
	   var CC = $("input#edit-item-CC").val();
	   var BCC = $("input#edit-item-BCC").val();
	   var Message = $("textarea.materialize-textarea").val();
	   if(from.length > 0 && to.length > 0 && Sub.length > 0 && Message.length > 0){ 
		   $("form#mail").submit();
	   }
   });
});

// Checkbox
function toggle(source) {
   checkboxes = document.getElementsByName("foo");
   for (var i = 0, n = checkboxes.length; i < n; i++) {
      checkboxes[i].checked = source.checked;
   }
}

$(window).on("resize", function () {
   resizetable();
   $(".email-compose-sidebar").removeClass("show");
   $(".email-overlay").removeClass("show");
   //$("input").val("");
   $(".compose-editor .ql-editor p").html("");
   //$("#edit-item-from").val("user@example.com");
   if ($(window).width() > 899) {
      $("#email-sidenav").removeClass("sidenav");
   }

   if ($(window).width() < 900) {
      $("#email-sidenav").addClass("sidenav");
   }
});
function resizetable() {
   if ($(".vertical-layout").length > 0) {
      $(".app-email .collection").css({ maxHeight: $(window).height() - 350 + "px" });
   }
   else {
      $(".app-email .collection").css({ maxHeight: $(window).height() - 410 + "px" });
   }
}

function get_all_mesages(folder1){
   var currenturl = window.location.href;
   $.ajaxSetup({ headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') }});
   $.ajax({ url:currenturl, data:{ folder: folder1 }, type:'post',
         success: function(result){
         if (result['all_message_data'].length > 0 ){
            var as = "";
            if (result['folder_name'] == 'trash'){
               $("#header_trash").hide();
               $("#total_checkbox_span").hide();
               result['all_message_data'].forEach(function(item) {
                  as += '<div class="email-brief-info collection-item animate fadeUp delay" id="' + item["id"] + '&' + item["folder"] + '"><div class="list-left"></div><a class="list-content" href="app-email/content/' + item['id'] + '/' + item["folder"] + '" style="cursor: pointer"><div class="list-title-area"><div class="user-media"><img src="images/user/' + item['user_img'] + '"alt="" class="circle z-depth-2 responsive-img avtar"><div class="list-title">' + item['user_name'] + '</div></div><div class="title-right"></div></div><div class="list-desc">' + item["subject"] + '</div></a><div class="list-right"><div class="list-date">' + item['received_date'] + '</div></div></div>';
               });
               
            } else {
               $("#header_trash").show();
               $("#total_checkbox_span").show();
               result['all_message_data'].forEach(function(item) {
                  as += '<div class="email-brief-info collection-item animate fadeUp delay" id="' + item["id"] + '&' + item["folder"] + '"><div class="list-left"><label><input type="checkbox" name="foo" /><span></span></label></div><a class="list-content" href="app-email/content/' + item['id'] + '/' + item["folder"] + '" style="cursor: pointer"><div class="list-title-area"><div class="user-media"><img src="images/user/' + item['user_img'] + '"alt="" class="circle z-depth-2 responsive-img avtar"><div class="list-title">' + item['user_name'] + '</div></div><div class="title-right"></div></div><div class="list-desc">' + item["subject"] + '</div></a><div class="list-right"><div class="list-date">' + item['received_date'] + '</div></div></div>';
               });
            }
            $("div#collection-email-collection").html(as);
            $('#modal2').modal('open');
         } else {
            as = '<div class="collection-item"><h6 class="center-align font-weight-500">No Results Found</h6></div>';
            $("div#collection-email-collection").html(as);
            $('#modal2').modal('open');
         }
      },
      error: function(result){
         alert("Selection Failed. Please try again!");
      }
   });
}

function del_mesag(del_mesag_ids){
   var currenturl = window.location.href;
   $.ajaxSetup({ headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') }});
   $.ajax({ url:currenturl + "/delete", data:{ del_mesag_ids: del_mesag_ids }, type:'post',
         success: function(result){
         if (result['status'] == 'delete') {
            $(".collection-item")
               .find("input:checked")
               .closest(".collection-item")
               .remove();
         } else {
         } 
      },
      error: function(result){
         alert("Selection Failed. Please try again!");
      }
   });
}

resizetable();