(function($) {

	var currenturl = window.location.href;
	var year = new Date().getFullYear()
	var month_val = new Date().getMonth();
	const month = new Array();
		month[0] = "01";
		month[1] = "02";
		month[2] = "03";
		month[3] = "04";
		month[4] = "05";
		month[5] = "06";
		month[6] = "07";
		month[7] = "08";
		month[8] = "09";
		month[9] = "10";
		month[10] = "11";
		month[11] = "12";
	console.log(year);
	console.log(month[month_val]);
	var status = 2;
	function selectList(){
		$.ajaxSetup({ headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') }});
		$.ajax({ url:currenturl+"/select", data:{ year: year, month: '01', status: status }, type:'post',
                success: function(result){
					if (result.length > 1 ){
						console.log(result);
						var as = "";
						result.forEach(function(item) {
						as += '<tr><td>' + item['cot_id'] + '</td><td>' + item['start_date'] + '</td><td><span class="task-cat cyan">' + item['end_date'] + '</span></td><td>' + item['marca'] + '</td><td>' + item['model'] + '</td><td>' + item['description'] + '</td><td>' + item['paq'] + '</td><td>' + item['fp'] + '</td><td>$ ' + item['iva'] + '</td><td>$ ' + item['pneta'] + '</td><td>$ ' + item['ptotal'] + '</td><td><span class="green-text">' + item['company'] + '</span></td><td>img</td><td>' + item['email'] + '</td><td><a><i class="material-icons">picture_as_pdf</i></a></td><td><a><i class="material-icons">note_add</i></a></td></tr>';
						});
						
					} else if(result.length == 1){
						console.log(result[0]);
						as = '<tr><td>' + result[0]['cot_id'] + '</td><td>' + result[0]['start_date'] + '</td><td><span class="task-cat cyan">' + result[0]['end_date'] + '</span></td><td>' + result[0]['marca'] + '</td><td>' + result[0]['model'] + '</td><td>' + result[0]['description'] + '</td><td>' + result[0]['paq'] + '</td><td>' + result[0]['fp'] + '</td><td>$ ' + result[0]['iva'] + '</td><td>$ ' + result[0]['pneta'] + '</td><td>$ ' + result[0]['ptotal'] + '</td><td><span class="green-text">' + result[0]['company'] + '</span></td><td>img</td><td>' + result[0]['email'] + '</td><td><a><i class="material-icons">picture_as_pdf</i></a></td><td><a><i class="material-icons">note_add</i></a></td></tr>';
					} else{
						as = '';
					}
					$("tbody#select-list").html(as);
				},
				error: function(result){
					alert("Failed. Please try again!");
				}
        });
	}
	selectList();
	$('select#year').on('change', function (e) {
		var optionSelected = $("option:selected", this);
		year = this.value;
	});
	$('select#month').on('change', function (e) {
		var optionSelected = $("option:selected", this);
		month = this.value;
	});
	$('select#status').on('change', function (e) {
		var optionSelected = $("option:selected", this);
		status = this.value;
	});
	$('a#filter').click(function (e) {
		selectList();
	});
})(window.jQuery);